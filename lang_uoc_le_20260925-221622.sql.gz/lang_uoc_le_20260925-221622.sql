--
-- PostgreSQL database dump
--

\restrict pDdIlPPWYPaESBu1PMHg9iV9Qn2Lcg1cinOc7sHRYzJS3Xuhj8ZcHdpqEbte9lx

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: craft_products; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.craft_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    village_id uuid NOT NULL,
    name text NOT NULL,
    product_group text,
    start_period text,
    is_traditional boolean,
    cultural_link_level text,
    materials text,
    product_story text,
    process_description text,
    process_media_ids uuid[],
    gift_suitability text,
    has_experience_activity boolean,
    experience_duration text,
    has_demo_space boolean,
    has_display_area boolean,
    has_guide_staff boolean,
    sales_channels text[],
    main_market text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.craft_products OWNER TO admin;

--
-- Name: craft_products_internal; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.craft_products_internal (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    average_output_per_year text,
    average_revenue_per_year text,
    current_difficulties text,
    support_needs text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.craft_products_internal OWNER TO admin;

--
-- Name: decorative_art_items; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.decorative_art_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    building_id uuid NOT NULL,
    theme_group text NOT NULL,
    subject_name text NOT NULL,
    era_estimate text,
    description text,
    media_ids uuid[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT decorative_art_items_theme_group_check CHECK ((theme_group = ANY (ARRAY['tin_nguong_ton_giao'::text, 'doi_song_sinh_hoat'::text, 'phong_thuy_cat_tuong'::text, 'hien_vat_co'::text])))
);


ALTER TABLE public.decorative_art_items OWNER TO admin;

--
-- Name: heritage_building_technical_details; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.heritage_building_technical_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    building_id uuid NOT NULL,
    roof_layers text,
    roof_shape text,
    roof_material text,
    roof_color text,
    facade_material text,
    facade_condition text,
    floor_material text,
    floor_pattern text,
    structure_material text,
    structure_condition text,
    column_height_cm numeric,
    column_diameter_cm numeric,
    pedestal_material text,
    pedestal_size text,
    pedestal_type text,
    floor_plan_drawing_media_id uuid,
    section_drawing_media_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.heritage_building_technical_details OWNER TO admin;

--
-- Name: heritage_buildings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.heritage_buildings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    address text,
    function text,
    ownership text,
    land_area_m2 numeric,
    floor_area_m2 numeric,
    heritage_rank text,
    heritage_rank_year integer,
    heritage_style_type text,
    managing_unit text,
    overall_structure_description text,
    cultural_historical_value text,
    built_period text,
    restoration_note text,
    gallery_media_ids uuid[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    village_id uuid
);


ALTER TABLE public.heritage_buildings OWNER TO admin;

--
-- Name: history_stories; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.history_stories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    village_id uuid NOT NULL,
    site_id uuid,
    type text NOT NULL,
    title text NOT NULL,
    body_text text,
    media_ids uuid[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT history_stories_type_check CHECK ((type = ANY (ARRAY['lich_su'::text, 'su_kien'::text, 'phong_tuc'::text, 'truyen_thuyet'::text])))
);


ALTER TABLE public.history_stories OWNER TO admin;

--
-- Name: intangible_heritage_items; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.intangible_heritage_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    village_id uuid NOT NULL,
    name text NOT NULL,
    recognition_level text,
    uniqueness_description text,
    participation_scope text,
    generations_transmitted text,
    tourist_experience_level text,
    event_timing text,
    capacity_note text,
    media_ids uuid[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT intangible_heritage_items_participation_scope_check CHECK ((participation_scope = ANY (ARRAY['mot_nhom_hoi'::text, 'nhieu_nhom_hoi'::text, 'toan_the_cong_dong'::text]))),
    CONSTRAINT intangible_heritage_items_recognition_level_check CHECK ((recognition_level = ANY (ARRAY['unesco'::text, 'quoc_gia'::text, 'tinh'::text]))),
    CONSTRAINT intangible_heritage_items_tourist_experience_level_check CHECK ((tourist_experience_level = ANY (ARRAY['chi_xem'::text, 'trai_nghiem_mot_phan'::text, 'trai_nghiem_toan_bo'::text])))
);


ALTER TABLE public.intangible_heritage_items OWNER TO admin;

--
-- Name: media; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    url text NOT NULL,
    kind text NOT NULL,
    attribution text,
    caption text,
    owner_entity_type text NOT NULL,
    owner_entity_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT media_kind_check CHECK ((kind = ANY (ARRAY['anh'::text, 'ban_ve'::text, 'panorama'::text, 'video'::text]))),
    CONSTRAINT media_owner_entity_type_check CHECK ((owner_entity_type = ANY (ARRAY['villages'::text, 'sites'::text, 'heritage_buildings'::text, 'history_stories'::text, 'decorative_art_items'::text, 'intangible_heritage_items'::text, 'craft_products'::text])))
);


ALTER TABLE public.media OWNER TO admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.schema_migrations (
    filename text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: public; Owner: admin
--

COMMENT ON TABLE public.schema_migrations IS 'Tên file trong migrations/ đã được áp dụng. Do scripts/migrate.sh ghi.';


--
-- Name: sites; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.sites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    village_id uuid NOT NULL,
    kind text NOT NULL,
    position_lat double precision NOT NULL,
    position_lng double precision NOT NULL,
    boundary jsonb,
    name text NOT NULL,
    category text NOT NULL,
    sub_category text,
    short_description text,
    light_count_25m integer,
    history_culture_note text,
    cover_media_id uuid,
    panorama_media_id uuid,
    heritage_building_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    boundary_source text,
    boundary_updated_at timestamp with time zone,
    CONSTRAINT chk_sites_boundary_source CHECK (((boundary_source IS NULL) OR (boundary_source = ANY (ARRAY['seed'::text, 'kml'::text, 'admin'::text])))),
    CONSTRAINT chk_sites_geometry CHECK (((kind = 'area'::text) = (boundary IS NOT NULL))),
    CONSTRAINT sites_kind_check CHECK ((kind = ANY (ARRAY['point'::text, 'area'::text])))
);


ALTER TABLE public.sites OWNER TO admin;

--
-- Name: villages; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.villages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    aliases text[],
    admin_location text,
    google_maps_link text,
    founded_period text,
    brand_identity text,
    name_meaning text,
    main_occupations text[],
    natural_features text,
    site_selection_history text,
    morphology_description text,
    morphology_diagram_media_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug text NOT NULL,
    cover_media_id uuid
);


ALTER TABLE public.villages OWNER TO admin;

--
-- Data for Name: craft_products; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.craft_products (id, village_id, name, product_group, start_period, is_traditional, cultural_link_level, materials, product_story, process_description, process_media_ids, gift_suitability, has_experience_activity, experience_duration, has_demo_space, has_display_area, has_guide_staff, sales_channels, main_market, created_at, updated_at) FROM stdin;
d7b4ad1e-464b-4f45-9abd-83d211020568	01000000-0000-0000-0000-000000000001	Miến	Chế biến nông sản thực phẩm	1986	t	Rất cao	bột dong	\N	Đầu tiên phải lọc bột dong, cho nước vào đánh lên, các phần cặn ở giữa, tạp chất ở trên thì bỏ, chỉ lấy bột ở giữa. Sau đó đánh bột dùng máy đánh. Sau khi đánh xong cho vào lò nhiệt hấp chín, sau đó nhả bánh ra phên rồi đem phơi, tùy thời tiết, nếu trời nắng thì 3-4 tiếng, phơi tái rồi thu vào. Sau đó đem về xắt miếng (có máy) cho vừa máy cắt sợi, xắt thành các miếng 20cm. Sau đó cho vào máy cắt thành sợi, tiếp tục vắt ra phên mang ra phơi khô. Sau khi khô thì quấn thành thành phẩm.\nCả quy trình khoảng 1-2 ngày	\N	Phù hợp	f	không	t	f	f	{"Đại lý","đến lấy tại xưởng","giao cửa hàng quen"}	Trong và ngoài tỉnh	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
56f955bc-6786-4afe-b19d-607c21417a1f	01000000-0000-0000-0000-000000000001	Tương	Sản phẩm chế biến	khoảng 1920	t	rất cao	gạo nếp, đậu tương	\N	Có 2 bước chính:\nĐồ xôi làm mốc: gạo ngâm khoảng 12 tiếng (qua đêm), cho vào đồ ở nồi hơi, rồi tãi ra nong, khoảng 3 ngày, ngày nào cũng phải bóp nhỏ ra để lên men vi sinh tự nhiên. Khoảng 3 ngày cho vào chiêu (vo gạo, đã) phần lông mốc đi (lông mốc tơ, nấm không đúng). Rồi cho vào ủ mật, chuyển từ tinh bột sang đường Gluco. Khoảng 7-8 ngày sẽ ra mật, ngọt. Cho vào trộn với muối và nước sạch, đánh lên sánh như chè bà cốt. Nước khoan ở độ sâu 76m, bơm lên bể phơi rồi qua bể lọc mới được sử dụng làm tương. \nNước đậu: chọn đậu đều hạt, cho vào rang (máy), chín vàng, để nguội rồi nghiền vỡ, xong cho vào luộc, cho ra thùng nhôm cho nguội, rồi đổ vào chum, ngày nào cũng phải khoắng lên, cho chuyển hóa. Để 10-15 ngày cho chuyển vị ngọt ngọt. \nSau đó trộn đậu với phần làm mốc, với tỷ lệ vừa phải, được tương chưa xay. Sau đó xay nhuyễn, cho vào chum phơi. Không được để nước vào. \nVị của mốc và nước đậu do kinh nghiệm biết lúc nào đạt.	\N	Phù hợp	t	30'	t	f	t	{"Có Đại lý","khách đến tận nơi"}	Cả nước	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
cee1b1d2-6f30-44ff-9862-e8c6a0cffe90	fdd98e46-3b65-490d-aadc-dbb90eab321d	- Tranh sơn mài\n - Các vật dụng trang trí: Lọ hoa, đĩa trưng bày	Sản phẩm thủ công mỹ nghệ (Nhóm gốm sứ và thủy tinh; Nhóm thêu và dệt; Nhóm mây tre lá; Nhóm đá gỗ mỹ nghệ sơn mài khảm trai; Nhóm khác (sừng, kim khó, hoa, tranh,…)	2003	t	Sản phẩm mang đậm giá trị văn hóa nghề truyền thống lâu đời của làng	Vỏ trứng vịt ấp nở, vỏ chai, tre, lứa, gỗ, bột màu,\n sơn phủ, bột son, sơn ta, sơn hạt điều, gốm sứ	\N	Sản phẩm nếu làm bằng Sơn ta sẽ mất 3 - 6 tháng,\n còn làm bằng Sơn điều mất 1,5 tháng (vì đây là sơn hóa chất)\n 1. Chuẩn bị chất liệu nền (Phôi): Sản phẩm sơn mài không chỉ làm trên một chất liệu cố định mà được thực hiện trên nhiều loại bề mặt nền khác nhau: Tre, gỗ và gốm sứ\n \n 2. Chuẩn bị nguyên liệu phủ và tạo màu:\n - Sơn đang được sử dụng 2 loại chính là Sơn ta và Sơn hạt điều.\n - Để tạo nên các mảng màu và họa tiết, người thợ kết hợp sử dụng bột son, bột màu, cùng với các chất liệu quý như vàng, bạc.\n - Đối với vỏ trứng (Khảm trứng): Đây là một khâu chế biến nguyên liệu rất đặc biệt. Thay vì dùng vỏ trứng thông thường, người thợ sử dụng vỏ trứng vịt đã nở (nguồn cung chủ yếu nhập từ Trung Quốc hoặc Singapore). Trước khi khảm lên bề mặt, vỏ trứng sẽ được đem đi nướng để tạo ra các dải màu sắc đậm nhạt khác nhau theo ý đồ của bức tranh.\n \n 3. Thời gian hoàn thiện: Thời gian để hoàn thành một quy trình sản xuất phụ thuộc hoàn toàn vào loại sơn được sử dụng ban đầu: Sơn ta từ 3-6 tháng; Sơn hạt điều rút ngắn đnags kể thời gian, chỉ mất 1.5 tháng để hoàn thành sản phẩm vì Sơn hạt điều có sự can thiệp của các hóa chất giúp bề mặt sơn khô nhanh hơn	\N	Rất phù hợp	t	~30 phút	f	t	\N	{"Từ 2021","khách sẽ tự đến xem hàng\n và đặt mua tại cơ sở"}	Chủ yếu là trong Hà Nội, ít khi có đơn ở các tỉnh	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
e6e001cc-263b-416c-84b9-3303d54a8097	fdd98e46-3b65-490d-aadc-dbb90eab321d	- Tranh sơn mài\n - Các vật dụng trang trí: Lọ hoa, đĩa trưng bày\n - Vận dụng gia đình	Sản phẩm thủ công mỹ nghệ (Nhóm mây tre lá; Nhóm đá gỗ mỹ nghệ sơn mài khảm trai)	Anh Cường bắt đầu làm từ năm 2008	t	0.5	Vỏ trứng vịt ấp nở, vỏ chai, tre, lứa, gỗ, bột màu,\n sơn phủ, bột son, sơn ta, sơn hạt điều, gốm sứ	\N	Bước 1: Mộc gỗ\n Bước 2: Thảo sơn\n Bước 3: Đánh vải\n Bước 4: Bó bước 1\n Bước 5: Mài bó\n Bước 6: Hom sơn 1 / Khảm trai\n Bước 7: Kẹt sơn tràn\n Bước 8: Mài hom\n Bước 9: Lót sơn\n Bước 10: Kẹt lót\n Bước 11: Mài kẹt lót\n Bước 12: Thí sơn 1 / Khảm trứng\n Bước 13: Mài thí 1\n Bước 14: Kẹt lỗi\n Bước 15: Mài kẹt\n Bước 16: Thí sơn 2\n Bước 17: Mài thí 2\n Bước 18: Kẹt lỗi\n Bước 19: Mài kẹt lỗi\n Bước 20: Phun màu 1\n Bước 21: Mài màu 1\n Bước 22: Kẹt lỗi\n Bước 23: Mài kẹt lỗi\n Bước 24: Phun màu 2\n Bước 25: Mài màu 2\n Bước 26: Vẽ tay\n Bước 27: Mạ Thép vàng/thép bạc\n Bước 28: Toát bóng\n Bước 29: Đánh bóng	\N	Rất phù hợp	t	~40 phút	t	t	t	{"Sản phẩm chủ yếu được xuất sang Pháp (đối tác từ năm 2015)",Đức,"Mỹ. Khách nước ngoài thường phải đặt hàng trước từ 2 tháng (đi máy bay) đến 4-6 tháng (đi tàu biển)."}	Sản phẩm chủ yếu được xuất sang Pháp (đối tác từ năm 2015), Đức, Mỹ. Khách nước ngoài thường phải đặt hàng trước từ 2 tháng (đi máy bay) đến 4-6 tháng (đi tàu biển).	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
1b45e114-a6ce-4379-a897-26169e410a95	09ee09b0-41f2-429c-a515-0cd2592edc44	Mây tre nón lá — Cơ sở sản xuất kinh doanh nón lá Lê Văn Tuy	Nhóm  mây tre nón lá	1975	t	Rất cao	Vòng, cạp, vòng cữ, lá cọ non, lá cọ già, mo, cước khâu	Không	Rẽ lá, là lá- bứt vòng-quay nón-khâu(thắt nón)-nức cạp-luồn nhôi-hoàn thiện	\N	Rất phù hợp	t	30-60 phút	f	t	t	{"Tại cơ sở","Khách du lịch"}	Ngoài tỉnh, thành phố	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
5f329317-32e8-4051-8957-fc6e3ad01e31	09ee09b0-41f2-429c-a515-0cd2592edc44	Mây tre nón lá — Hợp tác xã mây tre nón lá Thu Hương	Mây tre nón lá	1986	t	Rất cao	Vòng tre, mo, lá lụi, lá cọ, cước	Không	Rẽ lá-Là-bứt vòng-quay non- khâu(thắt)-lồng nhôi nón	\N	Rất phù hợp	t	Trên 60 phút	t	t	t	{"Tại cơ sở","Đại lý","siêu thị","Sàn thương mại điện tử","Xuất khẩu","khách du lịch","trạm dừng chân"}	Ngoài tỉnh, thành phố, quốc tế	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
53c85b12-e2af-4d24-a6a4-6f41a57a371a	c33319de-4845-41bf-94c1-3fa501e5e867	Complet - Veston — Hùng Luyến Comple Veston	Quần áo Vest	1990	t	Rất cao	Vải, mếch, mùng, cảng quần, dũi	Nguồn lao động thông minh sáng tạo	Trước hết thợ sẽ lấy số đo cẩn thận rồi vẽ rập theo từng người. Sau đó chọn vải, cắt vải, ép keo tạo dáng và may ráp từng bộ phận của áo, quần. Khi may xong sẽ là định hình, đính cúc, làm khuy, kiểm tra lại từng đường kim mũi chỉ rồi sẽ ra thành thành phẩm	\N	Rất phù hợp	t	Trên 60 phút	t	t	t	{"Tại cơ sở"}	Trong tỉnh, thành phố	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
726a0782-41bc-4d11-bd84-36b5d042b15e	c33319de-4845-41bf-94c1-3fa501e5e867	Complet - Veston — Doanh nghiệp may Complet veston D&T	Quần áo comple	2009	t	Cao	Vải, mùng, lót, dựng, mếch, kem, bông	Bắt nguồn từ làng truyền thống	Trước hết thợ sẽ lấy số đo cẩn thận rồi vẽ rập theo từng người. Sau đó chọn vải, cắt vải, ép keo tạo dáng và may ráp từng bộ phận của áo, quần. Khi may xong sẽ là định hình, đính cúc, làm khuy, kiểm tra lại từng đường kim mũi chỉ rồi sẽ ra thành thành phẩm	\N	Rất phù hợp	t	Tùy vào nhu cầu khách muốn trải nghiệm (thông thường khoảng 30 phút)	f	t	t	{"Tại cơ sở","đại lý","siêu thị","khách du lịch"}	Ngoài tỉnh, thành phố	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
1bb19045-ea18-4f64-9235-021d72a313a8	8216fe86-f66d-4b19-904b-cbdee0bf1eba	Mây tre đan	Mây, tre, lá, cỏ	1973 / 1991 (Công ty)	t	Rất cao	Mây, tre, lá, cỏ	\N	Giáo trình thực hiện	\N	Rất phù hợp	t	Ít nhất 4 tiếng	t	t	t	{"Tại cơ sở","Xuất khẩu"}	Quốc tế	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
7149b013-e68d-4f69-9a0c-7a141d92b38a	00000000-0000-0000-0000-000000000001	Giò chả	Sản phẩm chế biến thực phẩm	2021	t	Cao	Thịt lợn	\N	Làm từ thịt lợn tươi, còn nóng, với các khâu lọc, xay, gói. Gói giò bằng lá chuối, để giò thơm ngon, dậy mùi. Lá chuối cũng phải chọn kỹ, lá nõn lần trong, lá bánh tẻ lần giữa, lá già lần ngoài. Giò gói xong đem thả ngay vào nồi nước sôi và luộc, tùy theo cỡ giò mà có thời gian vớt thích hợp.	\N	Phù hợp làm quà lưu niệm, nhất là các du khách muốn trải nghiệm đặc sản địa phương	t	Dưới 30'	t	f	t	{"Đại lý",Chợ,"khách quen đến mua"}	Trong xã	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
\.


--
-- Data for Name: craft_products_internal; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.craft_products_internal (id, product_id, average_output_per_year, average_revenue_per_year, current_difficulties, support_needs, created_at, updated_at) FROM stdin;
d018bb67-9605-4a57-b892-3c308364f1be	d7b4ad1e-464b-4f45-9abd-83d211020568	\N	2400000000	Thu nhập thấp, vất vả nên không muốn phát triển nghề	Không có	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
25d8c86e-c157-46fc-8bca-0707004d09e6	56f955bc-6786-4afe-b19d-607c21417a1f	\N	500000000	Mẫu mã chưa hấp dẫn	Kết nối tour du lịch	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
3893058d-a0a1-47eb-b422-bd9dfc7e25bd	cee1b1d2-6f30-44ff-9862-e8c6a0cffe90	10.000 sản phẩm / năm	1 tỷ / năm	Khó khăn trong đầu ra sản phẩm khi gặp đơn hàng nhiều và thiếu nhân lực	Cần hỗ trợ đào tạo kỹ năng đón khách và các kỹ năng liên quan đến chuyển đổi số	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
b02264a8-813c-40a6-8b8c-6f5a31275119	e6e001cc-263b-416c-84b9-3303d54a8097	~10.000 sản phẩm/năm	1-2 tỷ/năm	Giao thông tiếp cận khó khăn\n Chưa có giá cả niêm yết giữa các nhà\n Việc tìm kiếm thế hệ trẻ tiếp nối nghề rất khó khăn vì kỹ thuật làm sơn mài phức tạp, mất nhiều thời gian, giới trẻ thường không đủ kiên nhẫn để theo đuổi.	Cần hỗ trợ về truyền thông và xúc tiến thương mại\n ngoài ra còn có nhu cầu kết nối tuor tuyến du lịch	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
fe63aec9-f406-4674-b310-5096dbe4d7e5	1b45e114-a6ce-4379-a897-26169e410a95	180,000 sản phẩm	Không	Thiếu liên kết du lịch	Kết nối tour du lịch, Đào tạo kỹ năng đón khách	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
b32969b9-7165-45dc-982f-dc153cca6f76	5f329317-32e8-4051-8957-fc6e3ad01e31	Khoảng 1,000-2,000 sản phẩm	Khoảng 1,000,000,000vnd	Không	Thiết kế mẫu mã, Bao bì, nhãn mác, Xúc tiến thương mại. kết nối tuyến du lịch, đào tạo kỹ năng đón khách	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
04034760-dc26-453c-93e3-6a4a5b16810e	53c85b12-e2af-4d24-a6a4-6f41a57a371a	10	Khoảng 200,000,000vnd	Khả năng không bảo tồn được nghề	Bao bì, nhãn mác	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
489bd2f8-d965-4342-9181-0ccc13541bfd	726a0782-41bc-4d11-bd84-36b5d042b15e	Khoảng 4,000	Khoảng 300,000,000vnd	Thiếu đầu ra của sản phẩm	Chuyển đổi số, xúc tiến thương mại, kết nối tour tuyến du lịch, đào tạo kỹ năng đón khách	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
691270c5-bd90-44ad-b2be-8131ade4610f	1bb19045-ea18-4f64-9235-021d72a313a8	\N	7 - 8 tỷ / năm	Năng lực quản lý của doanh nghiệp; Quy mô chưa đủ tầm	Chuyển đổi số	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
8c3d26f7-5810-40c0-b4a2-53e43f8fcb1f	7149b013-e68d-4f69-9a0c-7a141d92b38a	khoảng 29.000 kg	360 triệu/ năm	Thiếu liên kết du lịch, rất muốn sử dụng facebook để quảng bá nhưng không biết làm, hạn chế tiếp cận lượng khách quy mô lớn	Áp dụng TMĐT, sử dụng facebook đưa thông tin	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
\.


--
-- Data for Name: decorative_art_items; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.decorative_art_items (id, building_id, theme_group, subject_name, era_estimate, description, media_ids, created_at, updated_at) FROM stdin;
b56dcb41-f10d-4ab9-805d-9efcb01079ff	98dbb779-b90c-469b-bc18-8179a8158231	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	Vì nách hoạ tiết rồng\n\nVì nách gỗ chạm khắc hình rồng trong mây, kết hợp với vân mây, thuỷ ba thể hiện ý nghĩa cát tường và bảo hộ . Cùng với đó là nghệ thuật chạm khắc tinh xảo của kiến trúc gỗ truyền thống\n\nLá hoá rồng\n\nVì nách chạm lá hóa rồng, với đầu rồng cách điệu kết hợp các dải lá và dây cuốn mềm mại. Họa tiết mang ý nghĩa cát tường, bảo hộ	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
ee362050-0e08-471c-8b7a-595749815888	98dbb779-b90c-469b-bc18-8179a8158231	tin_nguong_ton_giao	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	Con nghê ở đỉnh cột\n\nNghê đá đặt trên đỉnh cột trụ biểu trong tư thế ngồi chầu, mang ý nghĩa trấn giữ, bảo hộ không gian thờ tự, xua đuổi tà khí và cầu mong bình an, cát tường.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
48fbd63b-11fa-44f1-945a-bb3e128d02ec	98dbb779-b90c-469b-bc18-8179a8158231	phong_thuy_cat_tuong	Lưỡng long chầu nhật	\N	Lưỡng long ở đỉnh mái\n\nBờ nóc mái đắp nổi hình lưỡng long chầu nhật. Hai rồng đối xứng chầu vào mặt nhật ở trung tâm, thân uốn lượn theo mái, mang ý nghĩa cát tường, quyền uy và cầu mong quốc thái dân an.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
44715bfb-72f0-40bb-a9a8-286544d594de	98dbb779-b90c-469b-bc18-8179a8158231	phong_thuy_cat_tuong	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán)	\N	Tượng Hộ pháp đắp nổi hình võ tướng mặc giáp, tay cầm binh khí, mang ý nghĩa canh giữ, trấn trạch và bảo vệ sự linh thiêng của công trình thờ tự.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
5af94691-44e4-4647-9e78-089b4b12cee8	98dbb779-b90c-469b-bc18-8179a8158231	doi_song_sinh_hoat	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	Cuốn thư	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
e7700e21-0a29-4bb2-8382-0d0472723e85	98dbb779-b90c-469b-bc18-8179a8158231	doi_song_sinh_hoat	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	bát hương	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
6f910e60-0347-4268-942a-388ab37598bc	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	Biểu tượng thiêng: không gian chùa giếng\n Biểu tượng Tôn giáo: các tượng thờ Phật giáo	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
5f395108-0961-4d4e-962c-6cd053b4fbb9	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	Lá hoá long\n\nVì nách chạm lộng họa tiết lá hóa long, kết hợp đầu rồng cách điệu với các dải lá và dây cuốn mềm mại. Họa tiết mang ý nghĩa cát tường, bảo hộ	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
8683e6bc-502f-403f-b994-99d76e4c5cce	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	tin_nguong_ton_giao	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	Rồng ở đỉnh mái\n\nLong (Rồng): Linh vật biểu tượng cho quyền uy, sức mạnh và thịnh vượng. Tạo hình thân dài uốn lượn mềm mại, được chạm nổi hoặc chạm lộng tinh xảo với các chi tiết vảy, râu, bờm đặc sắc, thể hiện giá trị nghệ thuật và văn hóa truyền thống Việt Nam.\n\nNghê ở trước hiên\n\nTượng nghê đá có dáng ngồi chầu, đầu ngẩng cao, mắt tròn lồi, miệng há, bờm xoắn và đuôi cong. Tượng được đặt trước bậc thềm công trình, mang ý nghĩa trấn giữ, bảo hộ và thể hiện sự uy nghiêm của không gian thờ tự.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
e0929f69-0ea6-454a-8447-b112c95878a3	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	doi_song_sinh_hoat	Tiên	\N	Tiên: Hình tượng tiên gắn với đời sống tín ngưỡng dân gian, biểu trưng cho sự thanh cao, an lành và ước vọng về cuộc sống hạnh phúc, tốt đẹp.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
b86cdb24-cd1a-4cd9-9a97-f2b75e79a885	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	Hoa quả: Hình tượng mẫu đơn, hoa hồng, hoa cúc, hoa đào, quả lựu được thể hiện với đường nét mềm mại, giàu tính trang trí, tượng trưng cho phú quý, trường thọ, hạnh phúc, may mắn và sự sinh sôi, sung túc trong đời sống văn hóa truyền thống.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
68f79baf-1f0e-4722-b720-ca74a5478748	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	doi_song_sinh_hoat	Mây	\N	Mây: Họa tiết mây được thể hiện bằng các đường nét uyển chuyển, mềm mại, tượng trưng cho sự giao hòa giữa trời và đất, mang ý nghĩa cát tường, thanh cao và tạo vẻ đẹp linh thiêng cho kiến trúc truyền thống.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
58333609-f92c-4c17-8306-fa1f4559b873	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	hien_vat_co	Tượng phật giáo (trong chùa)	\N	Tượng Phật\n\nBan tượng Đức ông + 2 vị hậu cần\n\nLà các tượng thể hiện các đức Phật, Bồ Tát, La Hán, Kim Cương, Hộ Pháp và các nhân vật thuộc hệ thống tín ngưỡng Phật giáo. Tượng được thờ trong các chùa nhằm phục vụ nhu cầu tín ngưỡng, tu tập và giáo hóa Phật pháp.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
ef4c41da-336e-4377-9952-3b0a7fe5ecd0	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	hien_vat_co	Tượng Tổ (trong chùa)	\N	tượng sư tổ\n\ntượng Tổ	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
49a757b7-1fb0-46ba-ab5f-039fbb1f410b	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	Tượng thờ mẫu	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
590fe53a-b778-453f-b37d-b6e6ba6cdc5f	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	hoành phi\n\nhoành phi2\n\nĐồ trang trí thờ tự gắn trên bộ khung kiến trúc: Là các hiện vật trang trí và thờ tự được gắn, treo trên hệ thống cột, xà, kèo, cửa trong công trình tín ngưỡng, tôn giáo, nhằm tôn vinh đối tượng thờ cúng và tăng tính trang nghiêm, mỹ thuật cho không gian thờ tự. Bao gồm: hoành phi, câu đối, cuốn thư, cửa võng, thiều châu, y môn,...	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
91b30cb6-9a23-48eb-8033-0c303ebf01ce	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	bát hương, mâm bồng\n\nHệ thống đồ tế khí được bố trí theo nguyên tắc đối xứng truyền thống. Chính giữa là bát hương và khám thờ sơn son thếp vàng, hai bên có hạc thờ, chân nến và bình hoa tạo nên không gian trang nghiêm. Nổi bật nhất là đôi hạc chầu hai bên án thờ, biểu tượng cho sự thanh khiết, trường tồn và ước vọng hướng tới cõi thiêng. Các đồ thờ chủ yếu mang phong cách truyền thống Bắc Bộ với chất liệu gỗ sơn son thếp vàng, đồng và gốm sứ.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
365483cc-e9db-4cf8-9651-4b05777c6cba	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	khám thờ\n\nhương án\n\nbài vị\n\nĐồ tự khí là nhóm hiện vật phục vụ trực tiếp cho hoạt động thờ tự trong các cơ sở tín ngưỡng, tôn giáo, dùng để tôn trí đối tượng thờ cúng và tạo không gian thờ tự trang nghiêm. Nhóm này bao gồm các loại hình tiêu biểu như hương án, khám thờ, ngai thờ, bài vị, giữ vai trò quan trọng trong nghi lễ, tín ngưỡng và giá trị văn hóa của di tích.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
eefd5277-aa1f-4507-b2b4-4fbe2174a6a7	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	Bát bửu đạo giáo\n\nCốn mê chạm nổi mô típ pháp bảo (Bát bửu) kết hợp vân mây, mang ý nghĩa trấn trạch, bảo hộ và cầu mong bình an, cát tường.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
01659d8d-8e45-40dc-a5d9-90db7dca3e2e	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	Vân hoá long\n\nCốn mê chạm nổi họa tiết mây hóa rồng (vân hóa long), với đầu rồng hòa quyện trong các dải vân mây cách điệu. Họa tiết mang ý nghĩa cát tường, linh thiêng và cầu mong mưa thuận gió hòa.\n\nLá hoá long\n\nVì nách chạm lộng họa tiết lá hóa long, kết hợp đầu rồng cách điệu với các dải lá và dây cuốn mềm mại. Họa tiết mang ý nghĩa cát tường, bảo hộ	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
19826bca-07d4-47e5-ac35-5263406d4084	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	Hoành phi\n\nHoành phi được treo ở vị trí trung tâm gian thờ, nền sơn son thếp vàng. Hoành phi không chỉ xác định tên gọi của không gian thờ tự mà còn thể hiện sự tôn kính đối với tổ tiên, góp phần tạo nên vẻ trang nghiêm và bề thế cho nội thất.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
d474c8c4-7e3a-4f4a-8e15-13db1453ac6b	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	Bát hương	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
0ff87038-f4d1-4bde-89cf-5f1a8b6b1242	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	Hương án	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
fe86923e-b8ed-4b2a-8e5a-b0b7a35ef5dc	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	doi_song_sinh_hoat	Bát tiên	\N	Cửa sổ gỗ đỏ trầm trang trí các ô gốm hình Bát Tiên xen kẽ hoa văn chạm thủng dây lá, vừa tăng giá trị thẩm mỹ vừa thể hiện ý nghĩa trường thọ, cát tường và ảnh hưởng của Đạo giáo trong nghệ thuật kiến trúc truyền thống.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
9480a1e4-f49f-498f-ad50-f9dc919a715a	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	Cửa sổ trang trí các ô gốm hình Tùng – Cúc – Trúc – Mai biểu trưng cho bốn mùa và những phẩm chất cao đẹp như trường thọ, thanh cao, chính trực và sức sống bền bỉ	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
14d8c02c-2e8f-4b4a-9060-a0ec7f1fffa9	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	Hoành phi, câu đối\n\nHoành phi và câu đối được làm bằng gỗ, chạm khắc hoa văn và sơn thếp vàng, tạo vẻ trang nghiêm, cổ kính. Đây là những thành phần quan trọng trong không gian thờ cúng, thể hiện sự tôn kính tổ tiên, giáo dục đạo hiếu và gìn giữ truyền thống tốt đẹp của gia đình, dòng họ.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
b202144b-01cb-48ae-af6c-23253bf34387	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	Hương án	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
d56e89d8-654f-43ca-bdd9-42e7e66b5da4	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	tin_nguong_ton_giao	Linh vật: Rồng	\N	Các đầu dư được chạm lộng hình rồng với các bờm, râu, tóc vuốt nhọn như hình mũi kiếm hay lưỡi thương rất đặc trưng của nghệ thuật thế kỷ 18 (chưa thay thế từ thời điểm khởi dựng năm 1780.).\n\nRồng vờn mây nước được chạm ở vì nách, Các thanh rường được trang trí, chạm nổi, chạm lộng các hoa văn hình các con rồng dày đặc, các bờm tóc vuốt nhọn như hình mũi kiếm hay lưỡi thương rất đặc trưng của nghệ thuật thế kỷ 18.	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
ed67fa2e-ccbf-4d40-82e4-bbd2d309ce50	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	tin_nguong_ton_giao	Linh vật: Phượng	\N	Phượng được trang trí đắp nổi ở tường đầu hồi ngoài nhà và hình vẽ trên tường hậu cung.	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
1427d07c-9f70-4284-a467-95cc49f822d3	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	doi_song_sinh_hoat	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc.	\N	Được trang trí bằng nhiều hình rồng, rồng vờn mây nước, mặt rồng kết hợp cây hoa lá. Nhiều bức trang trí mang phong cách nghệ thuật thế kỷ 18. Các hình tiêu biểu như Cuốn Thư, Hoành Phi, Trang trí gian chính giữa đại đình	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
e29b62b5-afff-467e-95ba-69968914723b	5b72fa35-638b-44c6-ab02-3947ba5a6102	phong_thuy_cat_tuong	Vì nóc gian biên:	\N	Sự kết hợp hài hòa giữa chạm khắc hoa văn nghệ thuật và chữ viết phong thủy: Chữ Phúc (福) ở chính giữa vì nóc, ngay bên dưới thanh đỡ thượng lương là một ô chữ Thọ cách điệu hình vuông. Tạo thành "Phúc - Thọ" (Hạnh phúc & Trường thọ). Xung quanh hai trụ ngắn và các rường cụt, câu đầu mép dưới/trên được chạm khắc hoa sen như đế đỡ cùng các dải mây cuộn và cánh hoa lá lật uốn lượn mềm mại. Đặc trưng cho phong cách trang trí thời  Nguyễn cuối thế kỷ 19.	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
07bfd70f-6712-4999-9706-663f10b700b7	5b72fa35-638b-44c6-ab02-3947ba5a6102	phong_thuy_cat_tuong	Trang trí thanh Câu đầu và Thượng lương, Quá giang	\N	Trang trí nhẹ nhàng, điểm xuyết cho các thanh chị lực này. Trên câu đầu bên cạnh các hoa văn hoa lá nhỏ, có thêm 2 chữ Thọ ở 2 đầu.	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
e0032a1a-7e70-4a83-bf40-b9b211da13cc	5b72fa35-638b-44c6-ab02-3947ba5a6102	doi_song_sinh_hoat	Cửa Võng, Hoành phi : Vị trí: Gian thờ chính giữa nhà.	\N	Cửa Võng: phân tách không gian linh thiêng bên trong với không gian sinh hoạt bên ngoài. * Chất liệu & Kỹ thuật: gỗ chạm nổi nhiều lớp, sơn son thếp vàng rực rỡ.\n* Họa tiết: Dây hoa mai, hoa cúc, kết hợp các hình tượng chim hoa uốn lượn mềm mại quanh viền cửa.                                                                                                                                                                       * Bên trên cùng là Hoành phi "Hội Nguyên Thống Tông" (會元統宗), sơn son thếp vàng nổi bật trên nền sơn then(đen bóng). Ý nghĩa: Quy tụ về một nguồn cội, nối tiếp dòng giống tổ tiên. Đây là thông điệp nhắc nhở con cháu về đạo lý Uống nước nhớ nguồn. * Vị trí: Gian thờ chính giữa nhà.                                                                                                                                                                                 * Dự đoán phong cách: Theo trang trí đồ thờ cúng cuối thời Nguyễn.	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
df87cd2a-f9c6-48f9-adcc-5859bd058d53	e92783f4-ea38-4375-9555-6751b3ac9129	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	ảnh ngựa được chmja khắc trên tường\n\nvoi, ngựa: Ở Đình Làng Chuông, các hình chạm voi và ngựa không chỉ là yếu tố trang trí mà còn góp phần tạo nên vẻ uy nghi của cổng đình.	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
1ed161d5-1072-4320-ae6e-214b50455c2d	e92783f4-ea38-4375-9555-6751b3ac9129	tin_nguong_ton_giao	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	rồng,phượng	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
bff2bb80-a9ff-4149-a32b-0b1995744c96	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Tiên	\N	Thờ thành hoàng, Đức Phùng Vương	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
78b47e7d-cdb1-4d77-baff-216e7d0dfa58	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
b28d221f-cbdc-4cd6-8917-2d69332a302d	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
23b4d47b-ddc2-404d-82ad-4f1600f4b985	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Tích xưa	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
56350bf7-8bc7-46b6-a926-63e9d3cadfdd	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Phồn thực	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
6bbcb36e-2be4-4531-a469-21ea1e801c83	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
4918923c-945e-4453-8e4f-d4dca285b42c	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
af5bbb84-7d6f-4a18-a986-515ee10b505c	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
6cbe0eb7-3065-4664-8572-80ee2c6a87f9	e92783f4-ea38-4375-9555-6751b3ac9129	doi_song_sinh_hoat	Mây	\N	ảnh chụp điêu khắc mây\n\nCó đi theo rồng	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
af8027b9-4256-4ad0-890c-1fec140fb6f7	e92783f4-ea38-4375-9555-6751b3ac9129	phong_thuy_cat_tuong	Long quấn thủy	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
bc84df67-a6b6-4f93-add5-385f3086ae09	e92783f4-ea38-4375-9555-6751b3ac9129	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
bcfa8cd5-189a-44b4-987d-e21003d37665	e92783f4-ea38-4375-9555-6751b3ac9129	phong_thuy_cat_tuong	Vật báu	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
92d59c45-a677-41c5-8632-1e49543523ae	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Tượng phật giáo (trong chùa)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
f16da89e-309c-4267-a8e7-f6e0e8290975	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
28296529-a6e4-4ce5-87d8-d08c77b824a9	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Tượng Hậu Phật (trong chùa)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
30f780b5-adcb-4e58-9444-d0aaa1d1f0a0	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Tượng Tổ (trong chùa)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
7b6e2772-2ff4-4980-b802-b2d893e73b06	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
d2eeaf0f-5b2a-4870-822f-e55e15692493	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	ảnh chụp cửa võng\n\nhoành phi, câu đối, cửa võng, thiều châu, y môn,…	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
3dab05b2-743b-44f0-8dc7-34135c7eb0ba	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
af053486-f75b-4e71-ad1e-2c99e65a1b8a	e92783f4-ea38-4375-9555-6751b3ac9129	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	ảnh chụp bài vị\n\nKhông có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
4c99d071-feda-47b5-8507-b1f3ca79b4da	28dc7a86-a741-4fd7-9407-454b6af79bb4	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	tứ linh	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
18c41fcb-b3dc-43ba-affe-23e9220e82e0	28dc7a86-a741-4fd7-9407-454b6af79bb4	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	hóa rồng	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
cc7b8b83-06cd-481c-8156-e641b684f363	28dc7a86-a741-4fd7-9407-454b6af79bb4	tin_nguong_ton_giao	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	ảnh rồng được điêu khắc trên hương án\n\nrồng	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
79981ef6-bb2f-42cb-b9a2-d80c8565d856	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Tiên	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
95de0fb7-2ef1-45b5-993e-9db3bfe3617b	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
b86827bb-8c3d-4b16-8c5c-7b3493193a00	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
30733a6c-6de0-4f20-94d3-3209feda00b7	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Tích xưa	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
a56dd1ca-6bdf-4d8f-adf3-41e24d93ffd7	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Phồn thực	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
8d798c13-b85c-41e9-9e12-c674bfb7cab6	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
7d5af557-0d5b-4e39-9f84-1d0de0407251	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
deedde9a-d4ac-41f3-8040-1f4502f13c4a	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	ảnh ngũ quả được điêu khắc ở vì kèo hiên\n\nngủ quả	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
e555dfb3-0fde-433d-b566-71b3b2d5a5cd	28dc7a86-a741-4fd7-9407-454b6af79bb4	doi_song_sinh_hoat	Mây	\N	ảnh mây điêu khắc trên gỗ\n\nmây	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
977a9207-cba0-42b8-8c6e-0f87ef9c7cb2	28dc7a86-a741-4fd7-9407-454b6af79bb4	phong_thuy_cat_tuong	Long quấn thủy	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
c2d0a1eb-7de1-4705-801a-52cc30243fd6	28dc7a86-a741-4fd7-9407-454b6af79bb4	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
38e5915c-7c4f-4295-801a-27a8d3890792	28dc7a86-a741-4fd7-9407-454b6af79bb4	phong_thuy_cat_tuong	Vật báu	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
790cbb1c-867d-44ac-9fe7-0d2a61ebf60b	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Tượng phật giáo (trong chùa)	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
dc96538a-4db6-4565-82f9-760d3f43045c	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
2bc9f524-ebc7-44ca-a21d-4be4f7f52b0e	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Tượng Hậu Phật (trong chùa)	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
0c626934-7eff-4f9e-a2e2-b1542146287c	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Tượng Tổ (trong chùa)	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
f0feca49-f403-4458-a5f6-2a6d1401788c	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
4f9f8d25-8325-4f8f-9871-7f50be582d9c	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	ảnh chụp hoành phi\n\nhoành phi,câu đối,của võng	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
91e0ec46-b80e-4734-ba6f-c8b041ca9a69	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	ảnh chụp tổng thể đồ thờ tự\n\nbát hương,đài	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
a4664fee-2c27-46b8-9289-e296cff2c855	28dc7a86-a741-4fd7-9407-454b6af79bb4	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	ảnh chụp hương án\n\nbài vị có ngai,kiếm	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
96179b07-2001-435d-8f03-1aacea2dc381	821ce853-ea6d-4a82-a68f-c9f22e4a2014	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	ảnh bà voi\n\nảnh ông voi\n\nông voi bà voi	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
4a6709b2-6c32-4859-90ec-c8a0af7ba2ca	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Tiên	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
33817625-daa0-41bb-9820-0f7720bbe69b	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
9d07cd6f-3d76-4688-b987-fab55742376b	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
1c4952e5-4cf0-4d3f-b22a-d72f0e5c222c	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Tích xưa	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
d41cc389-6e6e-426b-8a3f-e7bb5d7c8b9e	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Phồn thực	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
ac774557-ebf4-409e-995c-81208ee98251	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	Có voi ông voi bà	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
e759aa28-9938-4a2a-9f72-e6f5258c4221	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
90f6335b-5731-478a-b892-0f65c10cb3f6	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
0a438f42-1343-4849-97a1-08c7979d6750	821ce853-ea6d-4a82-a68f-c9f22e4a2014	doi_song_sinh_hoat	Mây	\N	ảnh mây được khắc họa trên tường\n\nCó uốn lượn theo rồng	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
fc9f005f-2db3-4129-adc7-f2c6bfb6d0fc	821ce853-ea6d-4a82-a68f-c9f22e4a2014	phong_thuy_cat_tuong	Long quấn thủy	\N	ảnh rồng quấn mây\n\nKhông có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
d9be6f83-3a86-4c10-94ad-ff8f22275af2	821ce853-ea6d-4a82-a68f-c9f22e4a2014	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
094d6f04-ff6e-4150-8f56-fce2bc7b6a2b	821ce853-ea6d-4a82-a68f-c9f22e4a2014	phong_thuy_cat_tuong	Vật báu	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
cd13c644-737f-4d35-85f5-aef7f1f1768e	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Tượng phật giáo (trong chùa)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
475ca16b-a4f8-4c4b-8794-cce4083fc5ff	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
e4b77892-1b97-452f-9192-eb07e21de7cc	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Tượng Hậu Phật (trong chùa)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
a21915a2-3222-4ce4-854c-48c6c2f0c037	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Tượng Tổ (trong chùa)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
3f309b6e-d37c-4995-92b7-0d412b471d0d	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	Không có	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
9d234bb9-2630-41ee-86c8-9333a7cd607f	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	ảnh câu đối\n\nCó câu đối	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
46ff5e4e-f05a-4eb6-96c9-d782fbbe4064	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	ảnh bát hương, đài\n\nBát hương, đỉnh, mâm bồng, ...	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
c50d1f17-2cb0-41ab-bfaa-05e1a318b909	821ce853-ea6d-4a82-a68f-c9f22e4a2014	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	ảnh hương án\n\nảnh bài vị\n\nCó ngai	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
723c07fe-561d-4126-b295-0372f5e71cce	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
58260599-4fa5-4dcd-b6cc-44fc01437f4c	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	hoa văn cây cỏ trên mặt bình cổ đặt cạnh bàn thờ tổ	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
b00692f2-d744-49bc-91e1-114d79fe4443	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
8751d16c-9f1c-45ec-82e9-cfeffc1e4366	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
2f84e586-4bc3-4d1f-b71a-ee3fbdbaf2c3	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Tích xưa	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
23d2187d-29ec-411d-a96d-ddb0ee54fd56	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Phồn thực	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
f4fed6e7-b3bd-4f5c-9df7-c5b4ba440087	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	cây tre trúc ở đầu đao	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
f24a989c-63d5-4d3c-b7e0-135064750def	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	hình tượng rộng cưỡi mây chầu nhật	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
a60091ee-6881-4bfb-8704-300ad3403d06	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Mây	\N	các vị thần tiên cưỡi mây	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
abf9e7a0-cb24-4518-8ee5-601823d7e86c	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	doi_song_sinh_hoat	Khác	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
f005b73c-6597-4adc-8693-ee208fac8513	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	phong_thuy_cat_tuong	Long quấn thủy	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
c1ead5ba-7b21-499f-a97f-3f9e971145cc	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
b6ca402f-9450-49be-b25f-2e8e2482fcfc	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	phong_thuy_cat_tuong	Vật báu	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
bb41b261-19c8-4843-84e7-9d5e68606cbc	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Tượng phật giáo (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
dfa107f0-2747-4439-9294-ddebb081f65e	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
5253d96a-a9a1-4066-9e99-c744bc0ece14	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Tượng Hậu Phật (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
1af4e49c-1970-4aa3-bfd8-bb97745f39c4	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Tượng Tổ (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
ae12c31a-fca1-4a46-8b26-b9598c7df3ff	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
c2eaf001-5794-4df4-b227-814c2500138f	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	ảnh hoành phi\n\nảnh cửa võng\n\nảnh y môn\n\nảnh câu đối\n\ntừ lúc xây dựng nhà\n\ncó câu đối và hoành phi và các vật trang trí khác	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
1428d990-d9c6-46d7-a77e-5ee37fbfef52	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	ảnh y môn\n\nảnh đỉnh đồng\n\nảnh chân nến\n\nảnh hạc chầu\n\ntừ lúc xây dựng nhà\n\ncó	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
285658bf-bcb3-4a1d-a28a-c10c6d166bb5	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	ảnh ngai\n\nảnh đầy đủ đồ thờ tụng\n\ncó	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
71618b5a-f3b6-48ef-b3dc-4f2544967fec	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
1c346b78-68a0-45a4-aca0-53a5e76e1f62	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
cae665ca-3c88-4952-9476-f360032beed8	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	tin_nguong_ton_giao	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	ảnh thờ tự có các linh vật\n\nbức họa sau bàn thờ chính và mựt trước của bàn thờ	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
6aa18ef8-e574-46d6-b1b8-e0fd8120a434	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Tiên	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
bb40e228-d224-44fc-bafc-389b1d5ac477	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
61025efe-d79f-406e-bd1d-a2415664ec47	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
c577b810-9816-4ec6-b686-5aacb49903b8	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Tích xưa	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
fcf88438-320c-4e0d-853a-8db716837f71	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Phồn thực	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
964a44fb-e94c-4d42-bc94-69f7577a20a1	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
07ec5b69-8c4d-4dd1-8c82-e6945203333e	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	có tre trúc , tùng	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
cfe82ca7-81b7-4e00-8d89-123674fd3157	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	https://drive.google.com/file/d/1MOE1u5R_TBm8fkfyf0Xm4-LutUL3eWJY/view?usp=sharing	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
3577938d-cc41-4cbf-b344-63c13c38d009	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Mây	\N	https://drive.google.com/file/d/1eSSJfynlQtkjeCxoIO_H3_Q4CmlCXDZx/view?usp=sharing\n\ncó mây ở mặt trước bàn thờ	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
755605e5-7abb-40e1-b1c9-bed575b994da	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	doi_song_sinh_hoat	Khác	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
ee2eeb99-facd-4275-a3b8-cfecd7083fb4	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	phong_thuy_cat_tuong	Long quấn thủy	\N	có ở mặt trước bàn thờ	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
b5983105-d757-4aae-85b7-ea9dd739fab5	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
e6cf003f-8e0e-4b66-9151-e2b22e8d51a1	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	phong_thuy_cat_tuong	Vật báu	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
f046aff9-c385-44ee-8e8e-23a2f354e6cd	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	hien_vat_co	Tượng phật giáo (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
72d3c1ee-6381-45be-ad87-8bec972e5786	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
8802897f-d100-4b6d-893c-583553e5f959	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	hien_vat_co	Tượng Hậu Phật (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
a68872fd-ac70-47a6-85d4-c85467338588	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	hien_vat_co	Tượng Tổ (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
0f971134-f136-4635-bb10-4aa198998147	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
d03c3996-63cb-4251-ac63-59d23d5aba9f	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
ba4ef400-e8fd-4f2a-a8da-46c113731540	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	kkhông có\n\nkhông có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
f4872c30-f539-426f-ad9e-63aa436decee	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	tin_nguong_ton_giao	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	ảnh chi tiết bàn thờ tự có các linh vật\n\nMảng chạm có bố cục cân đối, đối xứng, nổi bật với hoa sen, chim muông, hoa lá và hình tượng rồng. Kỹ thuật chạm nổi nhiều lớp khá tinh xảo, tạo chiều sâu và vẻ bề thế. Tổng thể mang đậm giá trị mỹ thuật và ý nghĩa phong thủy, thờ tự truyền thống, thể hiện sự trang nghiêm, sung túc và phúc lộc.	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
5f8ebf40-de0c-4903-9e71-c49c84a8632a	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Tiên	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
9ec6af5a-ebaa-4212-98bd-eaeb8b454b1c	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
116b5022-197a-47bf-baab-488176f5f4e0	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
067d90ad-4fb7-4b0b-a7a9-b8594f8324f6	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Tích xưa	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
df653264-351f-49df-8bf3-d069f3cbe567	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Phồn thực	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
1968baa8-1e7c-4806-aa81-518e8f556382	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
a2681832-476c-42e9-b2d9-0f6285ebf80a	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
df18dcdb-5f56-428b-9510-7e1468e66ba2	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	ảnh chụp chi tiét cổng chính ( cây mai)\n\nảnh hoa sen trên bàn thờ tự\n\nảnh hoa hồng ở sạp cúng bái\n\nảnh đầy đủ của bàn thờ có các chi tiết cây	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
88b5ec3a-1ec3-45c8-8b8d-c50bfed20a5c	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	doi_song_sinh_hoat	Mây	\N	ảnh chi tiết mây quấn rồng\n\ncó mây ở mặt trước bàn thờ	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
7bdbadc0-154f-4fdb-a4da-0c071f16cf04	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	phong_thuy_cat_tuong	Long quấn thủy	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
58bc1477-303e-4d51-a3f8-b85501547a79	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
da881283-622a-4130-b719-ad4d689c1beb	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	phong_thuy_cat_tuong	Vật báu	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
78f37674-dffa-4386-aad8-492643fe136e	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	phong_thuy_cat_tuong	Khác	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
f06718ea-89ed-4325-bc13-1ed2541483dd	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	hien_vat_co	Tượng phật giáo (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
85e7699c-e9a6-42b0-8be0-67b1be8d02f7	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
a433036e-0372-4308-95a4-ddc6544ea734	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	hien_vat_co	Tượng Hậu Phật (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
72c75328-4e7b-42c1-b37e-223e411e2072	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	hien_vat_co	Tượng Tổ (trong chùa)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
e3656917-8baa-4779-87b3-3032c78feccc	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	không có	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
8a369ac0-fa49-4280-8041-8a90bde57eb8	7929cf67-5bc1-425f-b66e-1200ff174b80	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	https://drive.google.com/file/d/1KFvX6PbmSBJwh3smivHNiDbPAN5C_ifH/view?usp=sharing\n\nLưỡng long chầu nguyệt trên đỉnh của Quán Phú Vinh	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
4d5f257c-05b9-46ce-b9c0-549a9ccc940e	7929cf67-5bc1-425f-b66e-1200ff174b80	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	https://drive.google.com/file/d/1TOoy9dOzqpqCgegESzq8kuK5fWojN5lD/view?usp=sharing\n\nKhông rõ thời điểm	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
b19aba5a-2eb8-4fce-8eb8-1d0b20680c03	7929cf67-5bc1-425f-b66e-1200ff174b80	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	https://drive.google.com/file/d/13P30onRzwpjKz5ZroiJDzhS_BL7PJ6EX/view?usp=sharing\n\nKhông rõ\n\nHoành phi trên đỉnh ban thờ	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
79c561bb-5836-47d8-93c6-78b66e5c27f2	7929cf67-5bc1-425f-b66e-1200ff174b80	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	https://drive.google.com/file/d/19Mu7L-_OokrP4FZ5uXih_kBopm4SMAxM/view?usp=sharing\n\nKhông rõ thời điểm\n\nKiệu thờ đặt tại gian chính, nguyên bản tuy nhiên không rõ niên đại	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
e6d50393-3c4d-4355-ad5e-5bca06e1a083	7929cf67-5bc1-425f-b66e-1200ff174b80	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	https://drive.google.com/file/d/1CpOWrWlV_MdqQlq41K6Lzzo5fqJTXHfE/view?usp=sharing\n\nKhông rõ thời điểm\n\nBan thờ ở gian thờ chính	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
73aa0396-7312-46ec-aacc-6dcd3c3fcac0	f5cc6df5-789e-4e33-a718-02219cf0c184	hien_vat_co	Đồ trang trí thờ tự gắn trên bộ khung kiến trúc (hoành phi, cuốn thư, câu đối, cửa võng, thiều châu, y môn,…)	\N	https://drive.google.com/file/d/1iiixBOetAX6S0PwcUPtVX29Es2q-HfZb/view?usp=sharing	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
b04f6782-3d82-40cb-9c31-289d10e5de16	f5cc6df5-789e-4e33-a718-02219cf0c184	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	https://drive.google.com/file/d/1rkqcTwv26fsTDcaWBj2iFnzDnLJtvIwC/view?usp=drive_link	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
a47ac85e-9d9f-4c61-9384-b6377eb9965c	f5cc6df5-789e-4e33-a718-02219cf0c184	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	https://drive.google.com/file/d/1DpZcsTTOMh1wNeXVQHPlyF4qA0a5tYE1/view?usp=sharing\n\nKhông rõ niên đại\n\nMũ thờ 3 thành hoàng, hiện đang để trong nhà kho	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
1eebe63f-2dd8-4f71-8611-d1d9b632f75c	44000000-0000-0000-0000-000000000001	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	Biểu tượng thiêng: không gian chùa giếng\n Biểu tượng Tôn giáo: các tượng thờ Phật giáo	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
f7d979d7-458a-4529-90d2-209b63805be0	44000000-0000-0000-0000-000000000001	tin_nguong_ton_giao	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	https://drive.google.com/file/d/1f48fnNzd2nmIK2qwN5aTuKbmpA1IODiL/view?usp=drive_link\n\nHình tượng cá hóa rồng trên mái Chùa Sổ được thể hiện bằng các linh vật uốn lượn dọc bờ nóc, kết hợp đặc điểm của cá chép và rồng. Biểu tượng này thể hiện ý chí vượt khó, sự thăng hoa và khát vọng đạt tới cảnh giới cao đẹp trong tín ngưỡng dân gian và Phật giáo Việt Nam.\n\nLong (Rồng): Linh vật biểu tượng cho quyền uy, sức mạnh và thịnh vượng. Tạo hình thân dài uốn lượn mềm mại, được chạm nổi hoặc chạm lộng tinh xảo với các chi tiết vảy, râu, bờm đặc sắc, thể hiện giá trị nghệ thuật và văn hóa truyền thống Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
04abce26-a879-4f6f-b8d8-6c6c5cc7de0e	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Tiên	\N	Tiên: Hình tượng tiên gắn với đời sống tín ngưỡng dân gian, biểu trưng cho sự thanh cao, an lành và ước vọng về cuộc sống hạnh phúc, tốt đẹp.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
967a68af-bb59-462c-bb86-577856923a2f	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	Lễ hội, rước: Hoạt cảnh con người tham gia lễ hội, rước kiệu trong không khí trang nghiêm và nhộn nhịp, phản ánh đời sống văn hóa cộng đồng, tín ngưỡng và truyền thống dân gian.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
296a9c11-70b8-404f-bb6e-a6486b3c1ec2	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	Trò chơi dân gian: Hoạt cảnh đánh cờ, đấu vật, đá cầu, chọi gà tái hiện sinh động đời sống văn hóa, vui chơi giải trí của người dân xưa. Hình tượng này phản ánh tinh thần gắn kết cộng đồng, đề cao sức khỏe, trí tuệ và nét đẹp truyền thống trong sinh hoạt dân gian Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
82d8dd2d-c17f-48f7-a409-eefe2b228b18	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Tích xưa	\N	https://drive.google.com/file/d/1f5pPXxCSydI0vtlwdJnisHno_FvwP8eD/view?usp=drive_link\n\nTích xưa: Các hình tượng, hoạt cảnh tái hiện những câu chuyện và điển tích dân gian, lịch sử hoặc tôn giáo quen thuộc, góp phần truyền tải bài học đạo đức, triết lý nhân sinh và các giá trị văn hóa truyền thống của dân tộc.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
d2fd0372-4df2-4312-be02-a0b6ef3828c1	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Phồn thực	\N	Phồn thực: Hình tượng biểu trưng cho sự sinh sôi, nảy nở và ước vọng về cuộc sống no đủ, con cháu đông đúc. Đây là đề tài phổ biến trong tín ngưỡng dân gian, thể hiện khát vọng về sự phát triển và thịnh vượng của cộng đồng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
ef52648a-b1e6-4162-ac48-594ed38483a1	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	Động vật: Hình tượng voi, hổ, ngựa, lợn, gà, chó, mèo... được thể hiện gần gũi, sinh động, phản ánh đời sống lao động, sản xuất và sinh hoạt thường ngày của người dân. Các hình tượng này vừa mang giá trị trang trí, vừa gửi gắm những ước vọng về sức mạnh, sự sung túc, may mắn và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
ddf191a6-5054-4346-bc9f-3f7d9df95d25	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	https://drive.google.com/file/d/1DrAchVmGf-OL98vods5Y8cmuD6k3L4Qg/view?usp=sharing\n\nCây cối: Hình tượng tre, trúc, tùng được sử dụng phổ biến trong trang trí kiến trúc truyền thống, biểu trưng cho sự bền bỉ, ngay thẳng, thanh cao và sức sống trường tồn. Đề tài này thể hiện quan niệm sống hài hòa với thiên nhiên và những phẩm chất tốt đẹp mà con người hướng tới.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
1112f8e6-b0d9-48a1-966e-1ec7b2123e33	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	Hoa quả: Hình tượng mẫu đơn, hoa hồng, hoa cúc, hoa đào, quả lựu được thể hiện với đường nét mềm mại, giàu tính trang trí, tượng trưng cho phú quý, trường thọ, hạnh phúc, may mắn và sự sinh sôi, sung túc trong đời sống văn hóa truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
8a41295d-3c64-424c-86d5-70b4fb71470d	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Mây	\N	https://drive.google.com/file/d/14eckJm0Mgt1B47uIZvmG9yIDdBhTZmVK/view?usp=drive_link\n\nMây: Họa tiết mây được thể hiện bằng các đường nét uyển chuyển, mềm mại, tượng trưng cho sự giao hòa giữa trời và đất, mang ý nghĩa cát tường, thanh cao và tạo vẻ đẹp linh thiêng cho kiến trúc truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
53937ea3-c850-499d-b605-26ca082ad427	44000000-0000-0000-0000-000000000001	phong_thuy_cat_tuong	Long quấn thủy	\N	Long quấn thủy: Hình tượng rồng uốn lượn trong sóng nước, biểu trưng cho sự hòa hợp giữa trời và đất, sức mạnh, tài lộc và nguồn sinh khí dồi dào. Đề tài mang ý nghĩa cát tường, cầu mong mưa thuận gió hòa, cuộc sống thịnh vượng và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
bc10c0f6-2a8f-4176-a47b-1f229fb75f65	44000000-0000-0000-0000-000000000001	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	Mả táng hàm rồng: Hình tượng kiến trúc mộ táng có tạo hình đầu hoặc hàm rồng bao bọc, thể hiện quan niệm phong thủy về sự che chở, bảo hộ linh hồn người đã khuất. Đề tài mang ý nghĩa cát tường, cầu mong sự trường tồn, bình an và phúc đức cho con cháu đời sau.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
2480dd0d-751e-461f-b1b8-b576cc95c08f	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Vật báu	\N	Vật báu: Hình tượng các vật báu trong tín ngưỡng và mỹ thuật truyền thống, tượng trưng cho tài lộc, phúc lành, sự cao quý và thịnh vượng. Đề tài mang ý nghĩa cát tường, cầu mong cuộc sống ấm no, hạnh phúc và may mắn.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
fb3c20ec-c748-4df1-b043-58ef4d82eb1a	44000000-0000-0000-0000-000000000001	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	7\n\nHệ thống đồ tế khí được bố trí theo nguyên tắc đối xứng truyền thống. Chính giữa là bát hương và khám thờ sơn son thếp vàng, hai bên có hạc thờ, chân nến và bình hoa tạo nên không gian trang nghiêm. Nổi bật nhất là đôi hạc chầu hai bên án thờ, biểu tượng cho sự thanh khiết, trường tồn và ước vọng hướng tới cõi thiêng. Các đồ thờ chủ yếu mang phong cách truyền thống Bắc Bộ với chất liệu gỗ sơn son thếp vàng, đồng và gốm sứ.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
dc1f0a7e-19ca-4dff-82cf-5aa22fe101d5	44000000-0000-0000-0000-000000000001	doi_song_sinh_hoat	Đồ tự khí: hương án, khám, ngai, bài vị	\N	Niên đại ước đoán: cuối thế kỷ XIX - đầu thế kỷ XX.\n\nHương án được đặt ở vị trí trung tâm phía trước ban thờ, dạng hình chữ nhật, mặt án rộng để bày lễ vật và đồ thờ. Phía sau là khám thờ bằng gỗ sơn son thếp vàng, trang trí hoa văn chạm khắc công phu. Bên trong khám đặt ngai thờ và bài vị, thể hiện sự tôn nghiêm của đối tượng được thờ phụng. Tổng thể đồ tự khí có màu son thếp vàng nổi bật, được bố trí cân đối, tạo nên không gian thờ tự trang nghiêm và linh thiêng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
63061bab-ad50-4a37-ab55-e67e46cf7f29	44000000-0000-0000-0000-000000000002	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	Biểu tượng thiêng: không gian chùa giếng\n Biểu tượng Tôn giáo: các tượng thờ Phật giáo	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
3d43be04-62da-4c8c-8ba8-eed1fe0458dd	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	Long (Rồng): Linh vật biểu tượng cho quyền uy, sức mạnh và thịnh vượng. Tạo hình thân dài uốn lượn mềm mại, được chạm nổi hoặc chạm lộng tinh xảo với các chi tiết vảy, râu, bờm đặc sắc, thể hiện giá trị nghệ thuật và văn hóa truyền thống Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
3a5bed33-98dd-4aa1-8854-fea212ac95b7	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Tiên	\N	Tiên: Hình tượng tiên gắn với đời sống tín ngưỡng dân gian, biểu trưng cho sự thanh cao, an lành và ước vọng về cuộc sống hạnh phúc, tốt đẹp.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
a82cdcba-8bda-4eb1-8c77-d9d96c251a3c	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	Lễ hội, rước: Hoạt cảnh con người tham gia lễ hội, rước kiệu trong không khí trang nghiêm và nhộn nhịp, phản ánh đời sống văn hóa cộng đồng, tín ngưỡng và truyền thống dân gian.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
837b7717-ffa5-46b9-8f57-89e47d88eaae	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	Trò chơi dân gian: Hoạt cảnh đánh cờ, đấu vật, đá cầu, chọi gà tái hiện sinh động đời sống văn hóa, vui chơi giải trí của người dân xưa. Hình tượng này phản ánh tinh thần gắn kết cộng đồng, đề cao sức khỏe, trí tuệ và nét đẹp truyền thống trong sinh hoạt dân gian Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
4e6e8a4a-03e2-473e-a26b-b81c5a18f5fd	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Tích xưa	\N	Tích xưa: Các hình tượng, hoạt cảnh tái hiện những câu chuyện và điển tích dân gian, lịch sử hoặc tôn giáo quen thuộc, góp phần truyền tải bài học đạo đức, triết lý nhân sinh và các giá trị văn hóa truyền thống của dân tộc.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
cbc422fe-44c6-4e9d-8b2d-646861be492b	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Phồn thực	\N	Phồn thực: Hình tượng biểu trưng cho sự sinh sôi, nảy nở và ước vọng về cuộc sống no đủ, con cháu đông đúc. Đây là đề tài phổ biến trong tín ngưỡng dân gian, thể hiện khát vọng về sự phát triển và thịnh vượng của cộng đồng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
37f0d912-dcc9-497e-a0e0-e0de134b7c5c	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	Động vật: Hình tượng voi, hổ, ngựa, lợn, gà, chó, mèo... được thể hiện gần gũi, sinh động, phản ánh đời sống lao động, sản xuất và sinh hoạt thường ngày của người dân. Các hình tượng này vừa mang giá trị trang trí, vừa gửi gắm những ước vọng về sức mạnh, sự sung túc, may mắn và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
183c9439-0509-4a4a-a7a4-4feffffc47cd	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	Cây cối: Hình tượng tre, trúc, tùng được sử dụng phổ biến trong trang trí kiến trúc truyền thống, biểu trưng cho sự bền bỉ, ngay thẳng, thanh cao và sức sống trường tồn. Đề tài này thể hiện quan niệm sống hài hòa với thiên nhiên và những phẩm chất tốt đẹp mà con người hướng tới.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
b3269867-8313-4102-b78c-af309cf26bcd	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	Hoa quả: Hình tượng mẫu đơn, hoa hồng, hoa cúc, hoa đào, quả lựu được thể hiện với đường nét mềm mại, giàu tính trang trí, tượng trưng cho phú quý, trường thọ, hạnh phúc, may mắn và sự sinh sôi, sung túc trong đời sống văn hóa truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
f2a3a854-7e7a-421a-ac12-cdaf54bbf1c1	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Mây	\N	Mây: Họa tiết mây được thể hiện bằng các đường nét uyển chuyển, mềm mại, tượng trưng cho sự giao hòa giữa trời và đất, mang ý nghĩa cát tường, thanh cao và tạo vẻ đẹp linh thiêng cho kiến trúc truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
f41420f4-3a10-49b7-89ee-5f4393d0d686	44000000-0000-0000-0000-000000000002	phong_thuy_cat_tuong	Long quấn thủy	\N	Long quấn thủy: Hình tượng rồng uốn lượn trong sóng nước, biểu trưng cho sự hòa hợp giữa trời và đất, sức mạnh, tài lộc và nguồn sinh khí dồi dào. Đề tài mang ý nghĩa cát tường, cầu mong mưa thuận gió hòa, cuộc sống thịnh vượng và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
4b4c1ca4-da06-447e-a695-e4d1ce33c6f2	44000000-0000-0000-0000-000000000002	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	Mả táng hàm rồng: Hình tượng kiến trúc mộ táng có tạo hình đầu hoặc hàm rồng bao bọc, thể hiện quan niệm phong thủy về sự che chở, bảo hộ linh hồn người đã khuất. Đề tài mang ý nghĩa cát tường, cầu mong sự trường tồn, bình an và phúc đức cho con cháu đời sau.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
2290ac72-52b5-4a79-939a-f0be55e22330	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Vật báu	\N	Vật báu: Hình tượng các vật báu trong tín ngưỡng và mỹ thuật truyền thống, tượng trưng cho tài lộc, phúc lành, sự cao quý và thịnh vượng. Đề tài mang ý nghĩa cát tường, cầu mong cuộc sống ấm no, hạnh phúc và may mắn.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
46991fe5-1059-4f84-b05f-f93ad1907c5b	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	Hệ thống đồ tế khí được bố trí theo nguyên tắc đối xứng truyền thống. Chính giữa là bát hương và khám thờ sơn son thếp vàng, hai bên có hạc thờ, chân nến và bình hoa tạo nên không gian trang nghiêm. Nổi bật nhất là đôi hạc chầu hai bên án thờ, biểu tượng cho sự thanh khiết, trường tồn và ước vọng hướng tới cõi thiêng. Các đồ thờ chủ yếu mang phong cách truyền thống Bắc Bộ với chất liệu gỗ sơn son thếp vàng, đồng và gốm sứ.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
5ebdc6e7-5a0c-4c56-8b45-62b405fdc07f	44000000-0000-0000-0000-000000000002	doi_song_sinh_hoat	Đồ tự khí: hương án, khám, ngai, bài vị	\N	Niên đại ước đoán: cuối thế kỷ XIX - đầu thế kỷ XX.\n\nHương án được đặt ở vị trí trung tâm phía trước ban thờ, dạng hình chữ nhật, mặt án rộng để bày lễ vật và đồ thờ. Phía sau là khám thờ bằng gỗ sơn son thếp vàng, trang trí hoa văn chạm khắc công phu. Bên trong khám đặt ngai thờ và bài vị, thể hiện sự tôn nghiêm của đối tượng được thờ phụng. Tổng thể đồ tự khí có màu son thếp vàng nổi bật, được bố trí cân đối, tạo nên không gian thờ tự trang nghiêm và linh thiêng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
eee8b1b0-96d1-4694-af86-698e20d7a2d7	44000000-0000-0000-0000-000000000004	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	Biểu tượng thiêng: không gian chùa giếng\n Biểu tượng Tôn giáo: các tượng thờ Phật giáo	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
5d975d3a-b23b-4870-be82-cd94024a2345	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	Long (Rồng): Linh vật biểu tượng cho quyền uy, sức mạnh và thịnh vượng. Tạo hình thân dài uốn lượn mềm mại, được chạm nổi hoặc chạm lộng tinh xảo với các chi tiết vảy, râu, bờm đặc sắc, thể hiện giá trị nghệ thuật và văn hóa truyền thống Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
5eab490d-0941-4031-a420-068da11a04da	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Tiên	\N	Tiên: Hình tượng tiên gắn với đời sống tín ngưỡng dân gian, biểu trưng cho sự thanh cao, an lành và ước vọng về cuộc sống hạnh phúc, tốt đẹp.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
d1291261-c50b-4761-8601-bef361446d63	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	Lễ hội, rước: Hoạt cảnh con người tham gia lễ hội, rước kiệu trong không khí trang nghiêm và nhộn nhịp, phản ánh đời sống văn hóa cộng đồng, tín ngưỡng và truyền thống dân gian.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
7ceb47d1-eb32-4d3b-95c6-5020b3b49612	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	Trò chơi dân gian: Hoạt cảnh đánh cờ, đấu vật, đá cầu, chọi gà tái hiện sinh động đời sống văn hóa, vui chơi giải trí của người dân xưa. Hình tượng này phản ánh tinh thần gắn kết cộng đồng, đề cao sức khỏe, trí tuệ và nét đẹp truyền thống trong sinh hoạt dân gian Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
33a75d1f-0f3e-4ff3-aab3-cd95cabd7e63	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Tích xưa	\N	Tích xưa: Các hình tượng, hoạt cảnh tái hiện những câu chuyện và điển tích dân gian, lịch sử hoặc tôn giáo quen thuộc, góp phần truyền tải bài học đạo đức, triết lý nhân sinh và các giá trị văn hóa truyền thống của dân tộc.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
96df3544-5876-4a1f-a87d-9726ae7f12ed	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Phồn thực	\N	Phồn thực: Hình tượng biểu trưng cho sự sinh sôi, nảy nở và ước vọng về cuộc sống no đủ, con cháu đông đúc. Đây là đề tài phổ biến trong tín ngưỡng dân gian, thể hiện khát vọng về sự phát triển và thịnh vượng của cộng đồng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
ffdc13bc-6596-401b-aa46-b9e777b5e126	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	Động vật: Hình tượng voi, hổ, ngựa, lợn, gà, chó, mèo... được thể hiện gần gũi, sinh động, phản ánh đời sống lao động, sản xuất và sinh hoạt thường ngày của người dân. Các hình tượng này vừa mang giá trị trang trí, vừa gửi gắm những ước vọng về sức mạnh, sự sung túc, may mắn và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
a8c578dd-f0ef-4b3a-a5cb-6a129a90cbd9	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	Cây cối: Hình tượng tre, trúc, tùng được sử dụng phổ biến trong trang trí kiến trúc truyền thống, biểu trưng cho sự bền bỉ, ngay thẳng, thanh cao và sức sống trường tồn. Đề tài này thể hiện quan niệm sống hài hòa với thiên nhiên và những phẩm chất tốt đẹp mà con người hướng tới.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
1c7b5837-d4df-4946-ab4d-e8871823fa49	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	Hoa quả: Hình tượng mẫu đơn, hoa hồng, hoa cúc, hoa đào, quả lựu được thể hiện với đường nét mềm mại, giàu tính trang trí, tượng trưng cho phú quý, trường thọ, hạnh phúc, may mắn và sự sinh sôi, sung túc trong đời sống văn hóa truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
f1debfe3-9e3d-485d-9433-70f7fc47effb	44000000-0000-0000-0000-000000000004	doi_song_sinh_hoat	Mây	\N	Mây: Họa tiết mây được thể hiện bằng các đường nét uyển chuyển, mềm mại, tượng trưng cho sự giao hòa giữa trời và đất, mang ý nghĩa cát tường, thanh cao và tạo vẻ đẹp linh thiêng cho kiến trúc truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
4832b38b-1aa0-450b-bdb2-e69895ffeaba	44000000-0000-0000-0000-000000000004	phong_thuy_cat_tuong	Long quấn thủy	\N	Long quấn thủy: Hình tượng rồng uốn lượn trong sóng nước, biểu trưng cho sự hòa hợp giữa trời và đất, sức mạnh, tài lộc và nguồn sinh khí dồi dào. Đề tài mang ý nghĩa cát tường, cầu mong mưa thuận gió hòa, cuộc sống thịnh vượng và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
5e0d8c57-43c6-4c21-a2e9-1ee1413440dd	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Vật báu	\N	Vật báu: Hình tượng các vật báu trong tín ngưỡng và mỹ thuật truyền thống, tượng trưng cho tài lộc, phúc lành, sự cao quý và thịnh vượng. Đề tài mang ý nghĩa cát tường, cầu mong cuộc sống ấm no, hạnh phúc và may mắn.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
0e809246-f231-447f-bed7-52d2753c96ae	44000000-0000-0000-0000-000000000004	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	Mả táng hàm rồng: Hình tượng kiến trúc mộ táng có tạo hình đầu hoặc hàm rồng bao bọc, thể hiện quan niệm phong thủy về sự che chở, bảo hộ linh hồn người đã khuất. Đề tài mang ý nghĩa cát tường, cầu mong sự trường tồn, bình an và phúc đức cho con cháu đời sau.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
c243fc18-be12-4464-ab3b-631d92518244	44000000-0000-0000-0000-000000000004	phong_thuy_cat_tuong	Vật báu	\N	Vật báu: Hình tượng các vật báu trong tín ngưỡng và mỹ thuật truyền thống, tượng trưng cho tài lộc, phúc lành, sự cao quý và thịnh vượng. Đề tài mang ý nghĩa cát tường, cầu mong cuộc sống ấm no, hạnh phúc và may mắn.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
4233575b-103e-42d0-9a91-0426047dc035	44000000-0000-0000-0000-000000000004	hien_vat_co	Tượng phật giáo (trong chùa)	\N	Tượng Phật giáo (trong chùa) thường được đặt tại chính điện hoặc các ban thờ, với dáng ngồi thiền, đứng hoặc nằm trang nghiêm. Tượng có khuôn mặt từ bi, thanh tịnh, biểu tượng cho trí tuệ, lòng nhân ái và sự giác ngộ theo giáo lý Phật giáo.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
e9a30b3d-575d-46f2-a134-d44d7fcde044	44000000-0000-0000-0000-000000000004	hien_vat_co	Tượng thánh, thần (trong đền, miếu, Đạo quán, Hội quán	\N	Tượng thánh, thần trong đền, miếu, đạo quán, hội quán thường được đặt ở vị trí trung tâm thờ tự, thể hiện các vị thần linh hoặc nhân vật được tôn kính. Tượng có dáng vẻ uy nghiêm, trang phục cầu kỳ, nét mặt trang trọng, biểu tượng cho quyền năng, sự che chở và niềm tin tâm linh của cộng đồng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
d3f3c318-d0c5-4959-ae80-c77792b86941	44000000-0000-0000-0000-000000000004	hien_vat_co	Tượng Hậu Phật (trong chùa)	\N	Tượng Hậu Phật được đặt phía sau ban thờ chính trong chùa, thường có dáng ngồi thiền trên tòa sen, khuôn mặt hiền từ và trang nghiêm. Tượng tượng trưng cho lòng từ bi, trí tuệ và sự giác ngộ của Đức Phật.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
bfa8bac9-b058-4e87-9bfb-8247a516580a	44000000-0000-0000-0000-000000000004	hien_vat_co	Tượng Tổ (trong chùa)	\N	Tượng Tổ (trong chùa) thường thờ các vị Tổ sư có công sáng lập hoặc truyền bá Phật giáo. Tượng thường được thể hiện trong tư thế ngồi, khuôn mặt đôn hậu, trang nghiêm, khoác áo cà sa, biểu tượng cho trí tuệ, đạo hạnh và sự kế thừa dòng truyền thừa Phật pháp.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
7e997816-8c49-4860-a7cc-3e332b07ae56	44000000-0000-0000-0000-000000000004	hien_vat_co	Tượng Mẫu (trong đền, phủ)	\N	Tượng Mẫu (trong đền, phủ) thường thờ các vị Thánh Mẫu trong tín ngưỡng thờ Mẫu của người Việt. Tượng được thể hiện với vẻ đẹp uy nghiêm, phúc hậu, trang phục lộng lẫy, tượng trưng cho quyền năng, lòng nhân từ và sự che chở đối với con người.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
0c641747-889e-4133-9651-71866ce9c6bf	44000000-0000-0000-0000-000000000004	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	7\n\nHệ thống đồ tế khí được bố trí theo nguyên tắc đối xứng truyền thống. Chính giữa là bát hương và khám thờ sơn son thếp vàng, hai bên có hạc thờ, chân nến và bình hoa tạo nên không gian trang nghiêm. Nổi bật nhất là đôi hạc chầu hai bên án thờ, biểu tượng cho sự thanh khiết, trường tồn và ước vọng hướng tới cõi thiêng. Các đồ thờ chủ yếu mang phong cách truyền thống Bắc Bộ với chất liệu gỗ sơn son thếp vàng, đồng và gốm sứ.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
8ae20d17-ab04-4fc4-bd72-c163a7cdd7aa	44000000-0000-0000-0000-000000000004	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	Hương án được đặt ở vị trí trung tâm phía trước ban thờ, dạng hình chữ nhật, mặt án rộng để bày lễ vật và đồ thờ. Phía sau là khám thờ bằng gỗ sơn son thếp vàng, trang trí hoa văn chạm khắc công phu. Bên trong khám đặt ngai thờ và bài vị, thể hiện sự tôn nghiêm của đối tượng được thờ phụng. Tổng thể đồ tự khí có màu son thếp vàng nổi bật, được bố trí cân đối, tạo nên không gian thờ tự trang nghiêm và linh thiêng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
3abda186-8632-4a32-96c6-8933537ee59c	44000000-0000-0000-0000-000000000003	tin_nguong_ton_giao	Biểu tượng thiêng và Biểu tượng tôn giáo	\N	Biểu tượng thiêng: không gian chùa giếng\n Biểu tượng Tôn giáo: các tượng thờ Phật giáo	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
5ecaa944-c833-4061-b8f6-790b5c63c5aa	44000000-0000-0000-0000-000000000003	tin_nguong_ton_giao	Các hình tượng linh hóa: Cá hóa rồng, cây cỏ hóa rồng,…	\N	Hình tượng cá hóa rồng trên mái  được thể hiện bằng các linh vật uốn lượn dọc bờ nóc, kết hợp đặc điểm của cá chép và rồng. Biểu tượng này thể hiện ý chí vượt khó, sự thăng hoa và khát vọng đạt tới cảnh giới cao đẹp trong tín ngưỡng dân gian và Phật giáo Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
bb21510b-5816-4357-b985-3032c6bcab33	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	\N	Long (Rồng): Linh vật biểu tượng cho quyền uy, sức mạnh và thịnh vượng. Tạo hình thân dài uốn lượn mềm mại, được chạm nổi hoặc chạm lộng tinh xảo với các chi tiết vảy, râu, bờm đặc sắc, thể hiện giá trị nghệ thuật và văn hóa truyền thống Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
1382d213-9607-47ec-a168-7e6d479f1376	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Tiên	\N	Tiên: Hình tượng tiên gắn với đời sống tín ngưỡng dân gian, biểu trưng cho sự thanh cao, an lành và ước vọng về cuộc sống hạnh phúc, tốt đẹp.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
42946ea3-cb50-45f7-bf68-1d6b07043142	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Hoạt cảnh con người: Lễ hội, rước	\N	Lễ hội, rước: Hoạt cảnh con người tham gia lễ hội, rước kiệu trong không khí trang nghiêm và nhộn nhịp, phản ánh đời sống văn hóa cộng đồng, tín ngưỡng và truyền thống dân gian.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
0c2d8069-ece6-4bd5-91cd-ab8cd1120952	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Trò chơi dân gian: Đánh cờ, đấu vật, đá cầu, chọi gà	\N	Trò chơi dân gian: Hoạt cảnh đánh cờ, đấu vật, đá cầu, chọi gà tái hiện sinh động đời sống văn hóa, vui chơi giải trí của người dân xưa. Hình tượng này phản ánh tinh thần gắn kết cộng đồng, đề cao sức khỏe, trí tuệ và nét đẹp truyền thống trong sinh hoạt dân gian Việt Nam.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
c4cedae8-f295-4611-ad23-c89826bba47d	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Tích xưa	\N	Tích xưa: Các hình tượng, hoạt cảnh tái hiện những câu chuyện và điển tích dân gian, lịch sử hoặc tôn giáo quen thuộc, góp phần truyền tải bài học đạo đức, triết lý nhân sinh và các giá trị văn hóa truyền thống của dân tộc.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
78e8233e-d36f-42a8-8b48-eed9aae5470c	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Phồn thực	\N	Phồn thực: Hình tượng biểu trưng cho sự sinh sôi, nảy nở và ước vọng về cuộc sống no đủ, con cháu đông đúc. Đây là đề tài phổ biến trong tín ngưỡng dân gian, thể hiện khát vọng về sự phát triển và thịnh vượng của cộng đồng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
7a1bb904-811f-49a4-9973-8d37b64e27a1	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Đề tài động vật: Voi, hổ, ngựa,, lợn, gà, chó mèo,…	\N	Động vật: Hình tượng voi, hổ, ngựa, lợn, gà, chó, mèo... được thể hiện gần gũi, sinh động, phản ánh đời sống lao động, sản xuất và sinh hoạt thường ngày của người dân. Các hình tượng này vừa mang giá trị trang trí, vừa gửi gắm những ước vọng về sức mạnh, sự sung túc, may mắn và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
54ec8a04-09c8-4ce7-b9ce-01e35af00d03	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Đề tài cây cối: tre, trúc, tùng	\N	Cây cối: Hình tượng tre, trúc, tùng được sử dụng phổ biến trong trang trí kiến trúc truyền thống, biểu trưng cho sự bền bỉ, ngay thẳng, thanh cao và sức sống trường tồn. Đề tài này thể hiện quan niệm sống hài hòa với thiên nhiên và những phẩm chất tốt đẹp mà con người hướng tới.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
a7052e4a-2405-4109-9a16-47d64406e478	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Đề tài hoa quả: Mẫu đơn, hồng, cúc, đào, lựu	\N	Hoa quả: Hình tượng mẫu đơn, hoa hồng, hoa cúc, hoa đào, quả lựu được thể hiện với đường nét mềm mại, giàu tính trang trí, tượng trưng cho phú quý, trường thọ, hạnh phúc, may mắn và sự sinh sôi, sung túc trong đời sống văn hóa truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
02ccdc1c-1fa5-4d58-99b6-868e88dba5d1	44000000-0000-0000-0000-000000000003	doi_song_sinh_hoat	Mây	\N	Mây: Họa tiết mây được thể hiện bằng các đường nét uyển chuyển, mềm mại, tượng trưng cho sự giao hòa giữa trời và đất, mang ý nghĩa cát tường, thanh cao và tạo vẻ đẹp linh thiêng cho kiến trúc truyền thống.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
af931ecf-a8aa-4f21-96af-1d1998091c1d	44000000-0000-0000-0000-000000000003	phong_thuy_cat_tuong	Long quấn thủy	\N	Long quấn thủy: Hình tượng rồng uốn lượn trong sóng nước, biểu trưng cho sự hòa hợp giữa trời và đất, sức mạnh, tài lộc và nguồn sinh khí dồi dào. Đề tài mang ý nghĩa cát tường, cầu mong mưa thuận gió hòa, cuộc sống thịnh vượng và bình an.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
cc28086d-b9d6-4265-8a78-6777f635b551	44000000-0000-0000-0000-000000000003	phong_thuy_cat_tuong	Mả táng hàm rồng	\N	Mả táng hàm rồng: Hình tượng kiến trúc mộ táng có tạo hình đầu hoặc hàm rồng bao bọc, thể hiện quan niệm phong thủy về sự che chở, bảo hộ linh hồn người đã khuất. Đề tài mang ý nghĩa cát tường, cầu mong sự trường tồn, bình an và phúc đức cho con cháu đời sau.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
3606daf2-d896-4053-bd68-4782d5ff868e	44000000-0000-0000-0000-000000000003	hien_vat_co	Tượng phật giáo (trong chùa)	\N	Tượng Phật giáo (trong chùa) thường được đặt tại chính điện hoặc các ban thờ, với dáng ngồi thiền, đứng hoặc nằm trang nghiêm. Tượng có khuôn mặt từ bi, thanh tịnh, biểu tượng cho trí tuệ, lòng nhân ái và sự giác ngộ theo giáo lý Phật giáo.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
43c94546-69a7-4017-a9aa-70dfecba7b67	44000000-0000-0000-0000-000000000003	hien_vat_co	Đồ tế khí: Bát hương, đỉnh, mâm bồng, đài, đồ chấp kích, lỗ bộ, lạc chầu, phỗng chầu,…	\N	7\n\nHệ thống đồ tế khí được bố trí theo nguyên tắc đối xứng truyền thống. Chính giữa là bát hương và khám thờ sơn son thếp vàng, hai bên có hạc thờ, chân nến và bình hoa tạo nên không gian trang nghiêm. Nổi bật nhất là đôi hạc chầu hai bên án thờ, biểu tượng cho sự thanh khiết, trường tồn và ước vọng hướng tới cõi thiêng. Các đồ thờ chủ yếu mang phong cách truyền thống Bắc Bộ với chất liệu gỗ sơn son thếp vàng, đồng và gốm sứ.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
ec1dbb59-18c1-4055-b7a8-576794f369ca	44000000-0000-0000-0000-000000000003	hien_vat_co	Đồ tự khí: hương án, khám, ngai, bài vị	\N	Niên đại ước đoán: cuối thế kỷ XIX - đầu thế kỷ XX.\n\nHương án được đặt ở vị trí trung tâm phía trước ban thờ, dạng hình chữ nhật, mặt án rộng để bày lễ vật và đồ thờ. Phía sau là khám thờ bằng gỗ sơn son thếp vàng, trang trí hoa văn chạm khắc công phu. Bên trong khám đặt ngai thờ và bài vị, thể hiện sự tôn nghiêm của đối tượng được thờ phụng. Tổng thể đồ tự khí có màu son thếp vàng nổi bật, được bố trí cân đối, tạo nên không gian thờ tự trang nghiêm và linh thiêng.	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.876842+00
\.


--
-- Data for Name: heritage_building_technical_details; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.heritage_building_technical_details (id, building_id, roof_layers, roof_shape, roof_material, roof_color, facade_material, facade_condition, floor_material, floor_pattern, structure_material, structure_condition, column_height_cm, column_diameter_cm, pedestal_material, pedestal_size, pedestal_type, floor_plan_drawing_media_id, section_drawing_media_id, created_at, updated_at) FROM stdin;
45000000-0000-0000-0000-000000000001	44000000-0000-0000-0000-000000000001	2 tầng mái	2 mái	ngói vảy rồng	màu đỏ gạch nung	gỗ	nguyên bản	lát gạch chỉ đỏ	lát theo kiểu xương cá	gỗ	nguyên bản	\N	\N	đá xanh	\N	tảng bồng	\N	\N	2026-09-21 02:54:19.503314+00	2026-09-21 07:18:35.222331+00
45000000-0000-0000-0000-000000000002	44000000-0000-0000-0000-000000000002	1 tầng mái	4 mái bít đốc	ngói vảy rồng	màu đỏ gạch đất nung	Gạch đá	\N	gạch lát	lát vuông	hỗn hợp	\N	\N	\N	Vật liệu đá	\N	tảng bẹt	\N	\N	2026-09-21 02:54:19.503314+00	2026-09-21 07:18:35.222331+00
45000000-0000-0000-0000-000000000004	44000000-0000-0000-0000-000000000004	1 tầng mái	2 mái	ngói đất nung truyền thống	mái màu đỏ	trát vữa	nguyên bản	gạch đất nung	lát mạch thẳng	khung gỗ	nguyên bản	\N	\N	đá xanh	400 x 400mm	tảng bẹt	\N	\N	2026-09-21 02:54:19.503314+00	2026-09-21 07:18:35.222331+00
d1050fd3-522a-4dc3-8e7e-2f39afad2644	98dbb779-b90c-469b-bc18-8179a8158231	1	2 mái	ngói mũi hài	màu đỏ	Hỗn hợp	nguyên bản	Nền trong đình là là đá phiến nhám mịn\nNgoài sân là gạch đỏ	lát ô vuông	tường bao gạch	Nguyên bản	\N	\N	Đá xanh	Chân tảng; 500*500mm, chân tảng nhỏ: 280*280mm	Tảng bồng	\N	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
356b0aa5-aba0-4a9b-bb71-0e544bfaf3ce	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	1tầng mái	2mái	mái vảy rồng	màu đỏ đất nung	hỗn hợp	nguyên bản	gạch chỉ	lát vuông	hỗn hợp	nguyên bản	\N	\N	Vật liệu đá xanh	\N	Tảng bồng	\N	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
81aff0df-93c5-4f80-a637-8a490f296358	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	1 tầng mái	hai mái	mái vảy rồng	màu đỏ gạch đất nung	gạch	nguyên bản	Nhà chính: lát gạch chỉ trong nhà và lát đá xanh ngoài hiên \nNhà phụ: lát gạch hiện đại trong nhà \nNgoài sân lát đá ong	Trong nhà lát vuông\nNgoài hiên lát xương cá \nNgoài sân lát vuông	hỗn hợp	nguyên bản	\N	\N	đá xanh	300 x 300 mm	Nhà chính: chân tảng tảng bồng ngoài cột hiên, tảng bẹt với cột nhà \nNhà phụ: chân tảng bồng	\N	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
9ed98927-6a42-4c2f-8cd4-903bf009dc37	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	1 tầng mái	2 mái	mái ngói không rõ chất liệu	Không rõ màu sắc	gạch	Nguyên bản	gạch chỉ	lát vuông	gạch	Nguyên bản	\N	\N	bê tông	trụ tảng 40*40	Trụ tảng	\N	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
569020a2-7f85-4de1-bf36-9104a212b862	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	Một tầng mái, gian Ống muống 2 tầng mái nhỏ	Mái dốc thẳng, chủ yếu là dạng 2 mái.	Lợp ngói lót bên dưới và ngói vẩy rồng bên trên	Màu đỏ nâu, gạch nung.	Gạch xây, trát vữa	Lớp vữa đã qua thay thế.	\N	\N	Kết cấu chính là hệ khung gỗ Lim chịu lực, xung quanh tường xây gạch và trát vữa. Cách đây khoảng 10 năm thì sơn son và vẽ hoa văn nét vàng cho các cột gỗ.	Thay thế vật liệu gian ống muống năm 1994, cột gỗ thay bằng cột gạch, tường gạch lỗ.	\N	\N	Một số cột gian giữa có chân đá tảng bằng đá xanh	5cmx50cm	Loại Tảng bẹt	\N	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
fea8bc7f-5eab-4e73-8857-4df7be5aa086	5b72fa35-638b-44c6-ab02-3947ba5a6102	1 tầng mái	Hai mái dốc với đầu hồi bít đốc	\N	\N	Xây gạch, trát vữa, quét sơn, mái ngói.	Thay thế	Nền hiên, nền sân lát gạch đỏ 30x30cm. Nền trong nhà lát gạch giả gỗ 15x60cm.	Nền hiên lát so le, Nền sân lát chéo mạch, Nền trong nhà lát so le.	Bộ khung kết cấu chiu lực gỗ Xoan, tường xây gạch trát vữa, mái lợp ngói.	Gần như nguyên bản, có thay thế hoành luồng thành gỗ.	\N	\N	Đá xanh	20x20cm (cột hiên)	Tảng bẹt	\N	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
6504a406-7fb2-47a8-8edf-70e183f3026e	e92783f4-ea38-4375-9555-6751b3ac9129	1	\N	Ngói ri (đã trùng tu)	Mái từ 1894, màu đỏ sẫm, đã được trùng tu	gạch	\N	Gạch đã trùng tu	Lát công	Tất cả đều sử dụng gỗ Lim	Có thay thế nhưng không đáng kể	\N	\N	Đá xẻ	60cm	tảng bẹt	\N	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
cebb8d0e-255e-4c1a-83ec-281dd9c6396c	28dc7a86-a741-4fd7-9407-454b6af79bb4	1 tầng	2 mái	mái ngói đã được tu sửa	đỏ đất	gỗ	nguyên bản	đã được tu bổ gạch hoa	lát vuông	gỗ lim	nguyên bản	\N	\N	đá xanh	50x50	tảng bẹt	\N	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
131b87a4-e61f-4cad-868e-3688fbc65863	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2 tầng mái	2 mái	Ngói hiện đại	Màu đỏ đất	Đã được tu tạo (trát vữa, hỗn hợp)	Thay thế	Gạch giếng đáy	Lát vuông	Gỗ	Nguyên Bản (có sơn lại)	\N	\N	xi măng	45cm	tảng bồng	\N	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
2dac2088-d31e-4d06-a76f-c6f103ae2571	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	1 tầng	ngói mũi hài	\N	màu đỏ đất	gạch trát vữa	nguyên bản	gạch lát hiện đại( đã trùng tu )	lát vuông	hỗn hợp	nguyên bản	\N	\N	40cm , đá xanh	50 cm( hình bình có chân)	tảng bồng	\N	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
f5923336-e90e-4ddb-ba1c-0d2d114f2227	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	1 tầng mái	hai mái	mái âm dương	đỏ đất đã có dấu hiệu xanh rêu qua thời gian	gạch trát vữa	nguyên bản có tu sửa	gạch bát , gạch giếng đáy	lát vuông	hỗn hợp	nguyên bản có trùng tu một ít	\N	\N	đá xanh	30cm	tảng bẹt	\N	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
7949a0f2-3f59-446f-ad7c-b7aa45170287	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	1 tầng mái	2 mái	ngói mũi hài	đỏ đất đã có dấu hiệu xanh rêu qua thời gian	gạch	nguyên bản có tu sửa	gạch đất nung	lát chéo	hỗn hợp	nguyên bản có tu sửa	\N	\N	không có	không có	không có	\N	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
0430c5ed-54d2-4c1e-b590-8330dd345777	7929cf67-5bc1-425f-b66e-1200ff174b80	1	Hai mái trước sau	https://drive.google.com/file/d/1hezL08xIIZ6HfVBLaauWkMsq9yPyIsxh/view?usp=sharing	\N	Gạch	Nguyên bản	https://drive.google.com/file/d/1eRnoJeeA5cNUTGUSqMpncTQTnn84iWes/view?usp=sharing	https://drive.google.com/file/d/1eRnoJeeA5cNUTGUSqMpncTQTnn84iWes/view?usp=sharing	Khung vì kèo gỗ	Nguyên bản	\N	\N	\N	\N	\N	\N	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
006a9110-a375-412d-89ce-77e62389d791	f5cc6df5-789e-4e33-a718-02219cf0c184	1	Bốn mái, bít đốc	\N	Màu nâu của ngói	Gạch và gỗ	Xây mới hoàn toàn	Gạch 40x40cm	Lát công	Cột bê tông cốt thép	Đại đình xây dựng mới trên nền công trình cũ năm 2019	\N	\N	Bê tông	44	Tảng bẹt	\N	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
8969a117-0655-43f4-a24f-ec0f128d0c57	32db5b3c-354d-4b2f-a87c-e04fe72228c2	1	Hai mái	https://drive.google.com/file/d/1cqfwSbhIFmYrwltDAufxjaByjI6v4evB/view?usp=sharing	Nâu	Gỗ và gạch	Nguyên bản	Gạch 30x30	Lát công	https://drive.google.com/file/d/1qR9PdQthAcaz387u7gMQQA3jv6qsF8sJ/view?usp=sharing	\N	\N	\N	Đá	30x30cm	Tảng bẹt bằng đá	\N	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
df646c1e-0921-49a3-a509-093dfbfd3586	b0cc3513-c04e-423c-912b-b5653534ffdf	1	Hai mái	https://drive.google.com/file/d/15_m2l75LBXz-7GXUEC0Nps9go_fdZhxD/view?usp=sharing	Nâu	Gỗ nguyên bản cho 3 gian giữa và gạch cho 2 gian hồi	Nguyên bản	Gạch 30x30cm	Lát công	Gỗ	Nguyên bản	\N	\N	Đá	22	Tảng bẹt	\N	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
38dda503-2e07-41bc-91f0-a1df3180e8a5	309af77b-1057-4d24-90ea-c37e69be4979	1	https://drive.google.com/file/d/1Khio265pbFL9a5MFfQiztasJVYXq28EN/view?usp=sharing	https://drive.google.com/file/d/1ItESrYcC8uWwL2b3nT37R9ntSoC6d6fa/view?usp=sharing	\N	Gạch xây cải tạo	Xây bổ sung năm 1974	Gạch hoa mới cải tạo thay thế	Lát vuông	Cột gỗ, tường bao gạch, cột hiên xây bằng gạch	Nguyên bản	\N	\N	Đá	30	Tảng bồng	\N	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
609b8d8a-91c5-4cda-8028-0a8cbcf8726b	44000000-0000-0000-0000-000000000003	1	2 mái	ngói đất nung truyền thống	màu đỏ gạch nung	gạch	nguyên bản	Nền lát gạch đất nung	Lát gạch theo hàng thẳng, mạch song song với trục công trình	kết cấu vật liệu gỗ	nguyên bản	\N	\N	đá xanh	355 x 355 mm	tảng bồng	\N	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:33:19.884793+00
\.


--
-- Data for Name: heritage_buildings; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.heritage_buildings (id, name, address, function, ownership, land_area_m2, floor_area_m2, heritage_rank, heritage_rank_year, heritage_style_type, managing_unit, overall_structure_description, cultural_historical_value, built_period, restoration_note, gallery_media_ids, created_at, updated_at, village_id) FROM stdin;
44000000-0000-0000-0000-000000000003	Nhà cụ Khả (3)	làng Ước Lễ, xã Dân Hòa, Hà Nội	nhà thờ họ	nhà cụ Khả	415.5	137.26	\N	\N	Kiến trúc nghệ thuật	\N	Nhà 5 gian	Ngôi nhà truyền thống vùng đồng bằng Bắc Bộ với 5 gian gồm nhà chính phục vụ thờ cúng, tiếp khách; nhà phụ phục vụ sinh hoạt gia đình; khu bếp phục vụ nấu nướng; sân là không gian sinh hoạt chung; bể nước đảm bảo nhu cầu sử dụng nước và tiểu cảnh góp phần nâng cao giá trị cảnh quan.	\N	\N	\N	2026-09-21 02:54:19.499+00	2026-09-23 15:44:23.291717+00	00000000-0000-0000-0000-000000000001
44000000-0000-0000-0000-000000000004	Nhà bà Bào (4)	Làng Ước Lễ, xã Dân Hòa, Hà Nội	Nhà ở	Nhà bà Bào	489.25	243.14	\N	\N	Kiến trúc	\N	Nhà 5 gian	Ngôi nhà 5 gian truyền thống vùng đồng bằng Bắc Bộ còn giữ được các nét kiến trúc bản địa	1988	\N	\N	2026-09-21 02:54:19.499+00	2026-09-23 15:44:23.291717+00	00000000-0000-0000-0000-000000000001
44000000-0000-0000-0000-000000000001	Đình làng Ước Lễ	làng Ước Lễ, xã Dân Hòa, Hà Nội	Đình làng	\N	2500	\N	di tích cấp quốc gia	2008	Kiến trúc nghệ thuật	\N	Đình làng là tổ hợp kiến trúc bao gồm Nghi môn, Tiền tế, Đại bái, Phương đình, Hậu cung và Tả hữu mạc. Trước 2 bên cửa Hậu cung là ngựa tế đỏ bên trái và ngựa tế trắng bên phải	Đình Ước Lễ thờ Tể tướng Lữ Gia làm thành hoàng làng, vị anh hùng trong cuộc chiến tranh chống quân Nam Hán xâm lược, với sự tích khi ngài chống quân Nam Hán đã bị chém đầu vẫn phi ngựa chạy về đến trước cổng làng Ước Lễ thì hóa. Tể tướng Lữ gia hy sinh ngày 12/9 âm lịch năm Canh ngọ (111 TCN). Hiện có trên 70 làng tôn Ngài là Đức Thành Hoàng làng (theo Tóm tắt lịch sử Việt Nam)	TK 17	\N	\N	2026-09-21 02:54:19.499+00	2026-09-23 15:44:23.291717+00	00000000-0000-0000-0000-000000000001
821ce853-ea6d-4a82-a68f-c9f22e4a2014	Đền Thượng	Thôn Tân Quang, xã Thanh Oai, thành phố Hà Nội	Đền thờ cúng đức thánh Phùng Hưng	của nhân dân	\N	\N	Cấp quốc gia	1989	di tích lịch sử	\N	Chùa được xây dựng theo hình Đinh, 8 mái, tiền đường 5 gian, hậu cung 2 gian, nhà tổ có nhiều pho tượng cổ, sân chùa có cây đa cổ thụ hơn 100 tuổi.	\N	năm 1894	\N	\N	2026-09-21 07:18:32.871+00	2026-09-23 15:44:23.291717+00	09ee09b0-41f2-429c-a515-0cd2592edc44
8ee6fb23-a886-441f-8cd0-ea80804b6e9a	Nhà Tây	số 02, ngõ 15, xóm cả, thôn Cựu	Nhà ở	không rõ	490	200	không có	\N	không có	\N	3 gian, 2 chái	\N	không rõ	\N	\N	2026-09-21 07:18:33.53+00	2026-09-23 15:44:23.291717+00	c33319de-4845-41bf-94c1-3fa501e5e867
909dd7d6-0c65-4f11-bedf-c6fecd4f9198	Nhà thờ họ Trần	Số  11 thôn Cựu	Nhà thờ họ	Dòng họ Trần - Làng Cựu	135	50	Không có	\N	Không có	Họ trần	Gian thờ chính có 3 gian theo nếp cổ, có nhà phụ phía sau và bể nước ở sân	là nơi thờ cúng của cư dân họ trần nói riêng dân làng nói chung	1926	\N	\N	2026-09-21 07:18:33.53+00	2026-09-23 15:44:23.291717+00	c33319de-4845-41bf-94c1-3fa501e5e867
d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	Nhà bác Tứ	59 làng cựu	nhà ở	bác Tứ	326	200	không có	\N	không có	cụ tứ	3 gian	nhà cổ trăm năm	1909	\N	\N	2026-09-21 07:18:33.53+00	2026-09-23 15:44:23.291717+00	c33319de-4845-41bf-94c1-3fa501e5e867
3ee3bd85-6227-4c96-ba05-ff8b2b74034d	nhà ông Mão	làng Cự Đà, xã Bình Minh, Hà Nội	Nhà ở	\N	204.61	119.34	\N	\N	Kiến trúc nghệ thuật	\N	Nhà 3 gian	\N	\N	\N	\N	2026-09-21 07:18:17.766+00	2026-09-23 15:44:23.291717+00	01000000-0000-0000-0000-000000000001
414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	Chùa Cự Đà _ Linh Minh Tự	làng Cự Đà, xã Bình Minh, Hà Nội	Chùa	\N	\N	\N	cấp quốc gia	2000	lịch sử văn hóa	\N	ba gian hai chái. Chùa có một cổng phụ phía Tây mở ra bãi đất liền với cánh đồng làng. Cổng phụ phía Đông ăn thông với lối đi chính về phía cầu đường sắt. Cổng lớn của chùa là một tam quan hẹp, mặt quay hướng Nam nhìn qua hai cây muỗm to ra sông Nhuệ.	Chùa Cự Đà hay còn gọi là Linh Minh tự. Theo văn bia ghi lại, Linh Minh tự nằm ở phía Đông khu dân cư đô hội, phía Tây long phượng chầu về, bên phải là miếu thờ Thành Hoàng, bên trái là từ đường nhà họ Đinh, trước mặt là dòng sông Nhuệ uốn quanh, xứng đáng chốn danh lam trong vùng.	Không ai còn nhớ rõ - thời điểm trùng tu lần đầu tiên vào mùa xuân niên hiệu Chính Hòa thứ 16 thời Hậu Lê (1695)	\N	\N	2026-09-21 07:18:17.766+00	2026-09-23 15:44:23.291717+00	01000000-0000-0000-0000-000000000001
98dbb779-b90c-469b-bc18-8179a8158231	Đình làng Cự Đà	làng Cự Đà, xã Bình Minh, Hà Nội	Đình làng	\N	553.13	276.78	\N	\N	\N	\N	Đình có 2 phần cơ bản là nhà tiền tế có gian giữa thờ chính, tả ban và hữu ban thờ cận thần, phía trong là hậu cung.	Đình gắn với truyền thuyết đây là nơi tuyển chọn binh lính trong thời kỳ dẹp loạn 12 sứ quân của vị tướng nhà Đinh. Hàng năm vào ngày 14 tháng giêng âm lịch có lễ hội Đại kỳ phúc tiến hành lễ rước Thành Hoàng Thông Phả Độ Đại vương. Cứ 5 năm 1 lần trong ngày hội lớn, tục đấu vật được biểu diễn lại ngay tại sân đình	\N	\N	\N	2026-09-21 07:18:17.766+00	2026-09-23 15:44:23.291717+00	01000000-0000-0000-0000-000000000001
44000000-0000-0000-0000-000000000002	Chùa Sổ	làng Ước Lễ, xã Dân Hòa, Hà Nội	Chùa	\N	5000	\N	di tích cấp quốc gia	1986	Kiến trúc nghệ thuật	\N	Chùa xây kiểu “Nội công ngoại quốc” với hai hành lang 26 gian, nối hai đầu tiền đường, cùng nhà hậu phía sau bao lấy tòa thượng điện.Kiến trúc “Chồng giường, giá chiêng, con nhị” với kết câu trên là hai xà ngân, đặt trên đầu hai cột con và tất cả đặt trên quá giang đội toàn bộ mái. Toàn bộ tượng trong chùa có tất cả 25 pho được làm vào thế kỷ 17 và 18, có giá trị lịch sử lớn.	Chùa Sổ hay còn gọi là Hội Linh quán, mang tinh thần tam giáo đồng nguyên. Ngoài hai bức đại tự "Hội Linh Quán" và "Đại La thiên" những phạm trù trong Đạo giáo, còn có bức "Từ Vân Pháp Vũ" ở thượng điện thể hiện sự giao hòa tín ngưỡng dân gian thờ bà Pháp Vũ của người Việt Nam. Tại văn bia Quán Hội Linh của chùa Sổ có ghi việc tu sửa quán Hội Linh, tô tạo tượng phạt, đúc chuông cùng bài tựa: “... Xã Ước Lễ huyện Thanh Oai phủ Ứng Thiên có quan Hội Linh nổi tiếng ở nước Nam ta. Bên trái có thanh long dẫn dòng đỗ đạt, sông Tô uốn quanh; bên phải có bạch hổ bày núi bút nghiên, bảng vàng chói lọi. Phía trước Chu Tước ôm ấp chính dòng nước, cuồn cuộn đổ về nguồn. Đằng sau huyền vũ thật chênh vênh, núi cao hơn đất. Bốn bề chung đúc khí thiêng, người tài vật quý, chư Phật thảy đều linh ứng, phúc đến lộc về.”\nChùa Sổ là một trong những ngôi chùa hiếm hoi còn giữ được dấu tích nền móng thời Mạc (1527), hệ thống di vật ở chùa cho thấy có sự giao thoa phát triển đặc sắc của điêu khắc, kiến trúc Mạc, Lê Trung Hưng và Nguyễn. Về kiến trúc, chùa kết cấu theo kiểu nội công - ngoại quốc. Từ cổng chùa vào là tam quan được xây kiểu chồng diêm, hai tầng tám mái, lợp ngói vảy cá. Giữa tam quan có quả chuông đồng lớn đề bốn chữ: “Quan Chung Linh tự”. Xung quanh chùa được xây thêm giếng nước và trồng nhiều cây xanh góp phần làm cho không gian thêm thanh bình êm ả.	TK 16	\N	\N	2026-09-21 02:54:19.499+00	2026-09-23 15:44:23.291717+00	00000000-0000-0000-0000-000000000001
bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	Nhà ông Vũ Ngọc Giao	làng Cự Đà, xã Bình Minh, Hà Nội	nhà ở	Ông Vũ Ngọc Giao	689.44	493.84	\N	\N	Kiến trúc nghệ thuật	\N	nhà3 gian 2 chái	\N	\N	\N	\N	2026-09-21 07:18:17.766+00	2026-09-23 15:44:23.291717+00	01000000-0000-0000-0000-000000000001
2113eaa5-1727-4f3c-9f78-f2a426fda3d9	Đình Hạ Thái còn có tên gọi là Đình Bà Lạy	Thôn Hạ Thái, xã Duyên Thái, huyện Thường Tín, TP. Hà Nội ( Xã Hồng Vân)	Đình làng. Công trình tín ngưỡng thờ Thành hoàng làng	\N	\N	\N	Di tích Quốc gia	2017	Di tích kiến trúc nghệ thuật	\N	Khuôn viên Đình bao gồm: Đình chính hình chữ Công, nối thêm 2 nhà hành làng phía sau.  Phía trước là sân đình, sân có 3 nghi môn mỗi nghi môn có 2 trụ biểu, chính giữa mặt trước là 1 nghi môn và hai bên sân là 2 nghi môn kết nối với các đường làng. Phía trước Đình là giếng làng , tiếp đến là nhà Bia giữa hồ. Bia ghi tóm tắt lại lịch sử xây dựng đền cũng như các vị nhân thần được thờ trong Đình.	Nơi thờ hai vị Thành hoàng làng:  Thờ vọng quan võ thời Lê là Bùi Sĩ Lượng và bà Đinh Thị Trạch (bà Lạy). Gắn liền với lễ hội làng diễn ra từ ngày 9 đến 11/11 âm lịch hàng năm. Đình thờ chính là bà Đinh Thị Lạy. Theo văn bia: " Xưa kia vùng này vốn hoang vu, rậm rạp. Có con hổ dữ hoành hoành. Bà Lạy đã khấn trời đất và xin từ nộp mình cho hổ dữ, từ đó về sau hổ không còn xuất hiện nữa...Bà là người đức sáng, thuần nhã thực xứng đáng là đức Huy Đôn Ý Đại Vương. Đạo theo đạo trời, đức hợp với đất. Giúp nước giữ vẻ thanh bình, giữ cho dân yên, mở mang sáng tốt. Là bậc đại vương ý sáng, đức thuần, đôn hậu, chu toàn, minh triết, ôn hòa cung kính. Bao nhiêu lần bà đã hiển linh vượt lên cả những gì đã được tôn sùng và phong cấp. Xin ghi chép lại nơi điển sách để lưu giữ mãi muôn đời tự vương tiến phong, ngày 26/7/1783 ( năm Cảnh Hưng thứ 44) "	Khởi dựng đình vào năm 1780. Trùng tu gian ống muống năm 1994, thay thế cột gỗ bằng cột gạch và tường gạch thông gió. Năm 2026 sẽ được hạ giải và trùng tu lớn, thay thế những cấu kiện gỗ bị hư hỏng ( tại thời điểm khảo sát vào tháng 7/2026 thì chưa hạ giải.)	\N	\N	2026-09-21 07:18:32.033+00	2026-09-23 15:44:23.291717+00	fdd98e46-3b65-490d-aadc-dbb90eab321d
5b72fa35-638b-44c6-ab02-3947ba5a6102	Nhà cổ	Số 14 ngõ 12 Mỹ Lộc, thôn Hạ Thái , xã Hồng Vân, Hà Nội	Nhà ở	Bà Đỗ Thị Dịp	512	\N	Chưa	\N	\N	\N	Trong khuôn viên có 2 ngôi nhà trong đó có 1 nhà cổ xây năm 1943, Nhà 5 gian (kí hiệu số 3 trên TMB).	Ngôi nhà được xây năm 1943, cổng xây 1946, có trùng tu một vài bộ phận và nâng nền vào năm 2016. Tuy chưa được xếp hạng di tích, nhưng ngôi nhà cũng có tuổi đời hơn 80 năm, còn gần như nguyên vẹn phong cách kiến trúc cuối thời Nguyễn. Do tốp thợ Nam Định thi công trong 2 năm.	1943 (Chủ nhà cung cấp)	\N	\N	2026-09-21 07:18:32.033+00	2026-09-23 15:44:23.291717+00	fdd98e46-3b65-490d-aadc-dbb90eab321d
28dc7a86-a741-4fd7-9407-454b6af79bb4	nhà ông Lê Văn Trường	số 5 ngõ nghè thôn quang trung xã Phương Trung huyện Thanh Oai tp Hà Nội	nhà ở	ông Lê Văn Trung	701	\N	không có	\N	không có	\N	nhà 3 gian 2 chái	Ngôi nhà cổ có giá trị lâu đời, được truyền thừa qua nhiều đời, vẫn giữ nguyên được lối kiến trúc cổ đặc trưng vùng Đồng bằng Bắc Bộ và tính chất gia đình danh giá thời xưa	\N	\N	\N	2026-09-21 07:18:32.871+00	2026-09-23 15:44:23.291717+00	09ee09b0-41f2-429c-a515-0cd2592edc44
e92783f4-ea38-4375-9555-6751b3ac9129	đình làng chuông	làng Chuông, xã Phương Trung, huyện Thanh Oai, Hà Nội.	đình	nhân dân	481.44187	1500	Cấp quốc gia	1990	di tích lịch sử	\N	Chùa được xây dựng theo hình Đinh, 8 mái, tiền đường 5 gian, hậu cung 2 gian, nhà tổ có nhiều pho tượng cổ, sân chùa có cây đa cổ thụ hơn 100 tuổi.	- Đình thờ Lục vị Thành hoàng làng, bao gồm 2 vị thiên thần (Đức Thiên thần Địa kỳ và Thổ kỳ) và 4 vị nhân thần là Bố Cái Đại vương Phùng Hưng, Đức Đỗ Huệ, Thánh mẫu Tiên Dung và danh tướng Nguyễn Xí. Đây là nơi tri ân những nhân vật lịch sử có công mở đất, bảo vệ quê hương và là điểm tựa tinh thần của người dân\n- mang đậm dấu ấn kiến trúc đình chùa truyền thống của vùng Đồng bằng Bắc Bộ, gắn liền với các mảng chạm khắc gỗ tinh xảo, thể hiện tay nghề thủ công đỉnh cao của các nghệ nhân xưa	1894	\N	\N	2026-09-21 07:18:32.871+00	2026-09-23 15:44:23.291717+00	09ee09b0-41f2-429c-a515-0cd2592edc44
309af77b-1057-4d24-90ea-c37e69be4979	Nhà nghệ nhân Hoàng Hạnh	Thôn Phú Hữu, xã Phú Hữu	Nhà ở	Hoàng Hạnh	\N	\N	Không rõ	\N	Không rõ	Không rõ	Nhà cũ 3 gian 2 chái	\N	Trước 1954	\N	\N	2026-09-21 07:18:34.352+00	2026-09-23 15:44:23.291717+00	8216fe86-f66d-4b19-904b-cbdee0bf1eba
32db5b3c-354d-4b2f-a87c-e04fe72228c2	Nhà cổ ông Nguyễn Hữu Bật	Thôn Phú Hữu, xã Phú Hữu	Nhà ở	Nguyễn Hữu Bật	\N	\N	Không có	\N	Không có	Nguyễn Hữu Bật	Nhà cổ 5 gian	\N	Xấp xỉ 100 năm, mua nhà từ địa phương khác về lắp dựng	\N	\N	2026-09-21 07:18:34.352+00	2026-09-23 15:44:23.291717+00	8216fe86-f66d-4b19-904b-cbdee0bf1eba
7929cf67-5bc1-425f-b66e-1200ff174b80	Quán Phú Vinh	Làng	Thờ công chúa	Sở hữu của làng Phú Vinh	\N	\N	Không có	\N	Di tích lịch sử	Làng Phú Hữu	Nhà quán dạng chữ Đinh, với hậu cung. Nhà có 3 gian	\N	thế kỉ 17	\N	\N	2026-09-21 07:18:34.352+00	2026-09-23 15:44:23.291717+00	8216fe86-f66d-4b19-904b-cbdee0bf1eba
b0cc3513-c04e-423c-912b-b5653534ffdf	Nhà ông Nguyễn Hữu Kí	Thôn Phú Hữu, xã Phú Hữu	Nhà ở	Nguyễn Hữu Kí	\N	\N	Không có	\N	Không có	Không có	Nhà cổ 5 gian	\N	Xấp xỉ 100 năm, mua nhà từ địa phương khác về lắp dựng	\N	\N	2026-09-21 07:18:34.352+00	2026-09-23 15:44:23.291717+00	8216fe86-f66d-4b19-904b-cbdee0bf1eba
f5cc6df5-789e-4e33-a718-02219cf0c184	Đình Phú Vinh	Xã Phú Nghĩa	Đình làng	Làng Phú Vinh	\N	\N	Di tích lịch sử cấp thành phố	2004	Di tích lịch sử	Làng Phú Vinh	https://drive.google.com/file/d/1fyw2pNjaXua-nn_Yufu4fZmYwuLzBhSM/view?usp=sharing	\N	Xây dựng mới trên nền công trình cũ năm 2019	\N	\N	2026-09-21 07:18:34.352+00	2026-09-23 15:44:23.291717+00	8216fe86-f66d-4b19-904b-cbdee0bf1eba
\.


--
-- Data for Name: history_stories; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.history_stories (id, village_id, site_id, type, title, body_text, media_ids, created_at, updated_at) FROM stdin;
4d609f72-f94d-4fba-8d21-8e15ad1e4977	01000000-0000-0000-0000-000000000001	\N	lich_su	Lịch sử làng	Từ thế kỷ 16 đến đầu thế kỷ 17, làng phát triển cực thịnh về mọi mặt kinh tế, văn hóa,…, việc kinh doanh buôn bán của dân làng Cự đà, nhất là dòng họ Trịnh, phát triển rất mạnh vượt ra khỏi phạm vi của làng để vươn tới các thành phố lớn. Tại các thành phố, thị xã lớn như Hà nội, Hải Phòng, Hà Đông, Sơn Tây, Sài gòn,… đã thất xuất hiện nhiều cửa hiệu buôn lớn của người Cự đà. Nghề làm tương và nghề buôn bán là hai ngành kinh tế xương sống của làng. Bên cạnh đó, nông nghiệp phát triển cũng mạnh mẽ. \nNhững năm 1920-1940 của thế kỷ trước, người làng đua nhau ra Hà nội lập xưởng, làm chủ nhà máy, chủ cửa hàng, tiệm buôn khá đông. Một loạt tên tuổi các nhà giàu Hà nội lấy tên hiệu bắt đầu bằng chữ Cự như Cự Doanh, Cự Chân, Cự Phát,… chính là người Cự Đà. Do đó, làng Cự đà trong những năm đầu thế kỷ 20 thực chất là làng thương mại ven đô giàu có, điều này kiến giải cho kiến trúc pha trộn nét Đông – Tây độc đáo của làng Cự đà. Theo tài liệu Cự Đà thôn địa bạ ghi vào năm Gia Long 4 (1805) tổng diện tích đất đai tại thôn Cự Đà tại thời điểm này là 183 mẫu, 5 sào, 11 thước, 4 tấc (trong đó bao gồm đất ở , ruộng công, ruộng thuê, đất đình chùa đền miếu, vườn ao). Ngoài ra còn có 7 mẫu , 4 sào thổ phụ và đất gò, đống. Tổng cộng là 190 mẫu, 9 sào, 11 thước, 4 tấc, bằng khoảng 68 ha. Về quá trình phát triển, giai đoạn đầu, người dân tới làng sinh sống chủ yếu ở giữa làng. Điều này được minh chứng qua mật độ dày đặc của các ngôi nhà có niên đại lâu đời ở giữa làng. Về sau nhiều dòng họ đến đây sinh sống, người dân đã mở rộng địa bàn sinh sống sang 2 bên. Hiện nay, người dân còn làm nhà ở ngay bờ sông, nơi trước kia chủ yếu làm bến đồ thuyền	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
20d0d147-a7ca-4da1-9b89-ec9a05b9f9d0	01000000-0000-0000-0000-000000000001	\N	phong_tuc	Phong tục	Hàng năm lễ hội làng ngày 14 tháng giêng phải khấn cụ Hoằng Thông trước, cụ Vũ Lôi Hùng Uy sau. Nhưng ngày 12 tháng 5 làng cùng nhiều làng khác thì dọc sông Nhuệ làm lễ tế cụ Vũ Lôi Hùng Uy. Đây là ngày đầu mùa mưa lụt cũng là lễ Tịch Điền	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
41ddc363-b834-43b0-88d0-ef5c586f1a58	01000000-0000-0000-0000-000000000001	\N	truyen_thuyet	Truyền thuyết	Khi dân đến ở, chưa được triều đình phong Thành hoàng, chưa có người bảo vệ, dọc 2 bên sông thờ 1 vị thần tưởng tượng ở trên trời Vũ Lôi Hùng Uy, để cầu mưa thuận gió hòa và bảo vệ dân làng. Sau này cần có nhân thần chính thức làm thần hoàng làng . Ngày 14 tháng giêng cuối nhà Lê, phong cụ Hoàng Thông là Thành hoàng làng. Cụ là mưu sĩ của cụ Trần Vĩ - bố nuôi của Đinh Bộ Lĩnh, hoạch định cho cụ Trần Vĩ và vua Đinh Bộ Lĩnh sách lược quản lý đất nước và phát triển kinh tế. Khi Đinh Bộ Lĩnh chưa đánh xong 12 sứ quân thì cụ đã mất, để ghi nhớ công lao của cụ nên cụ được phong làm thành hoàng làng Cự Đà, nhưng gọi tránh chữ Hoàng nên gọi là Phả độ Hoằng Thông, được phong là Quang Ý Đại Vương (sáng cả vùng rộng). Sau này khi làm hồ sơ làng thì nhân thần tưởng tượng không được công nhận nên đã đưa ông Vũ Lôi Hùng Uy là 1 vị tướng thời Hùng Vương đánh giặc Ân, được phong Linh Thúy Đại Vương.	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
4bdca793-e2ea-474f-aa67-10f0ae5557ab	fdd98e46-3b65-490d-aadc-dbb90eab321d	\N	lich_su	Lịch sử làng	Làng Hạ Thái là một làng có lịch sử lâu đời ở đồng bằng Bắc Bộ, thuộc xã Duyên Thái, huyện Thường Tín, Hà Nội. Nghề sơn ở đây được cho là đã hình thành trên 200 năm, có từ trước khi xây dựng đình làng (1780). Trước đây, làng có tên là Cự Tràng (gồm làng Duyên Trường và Hạ Thái), sau đổi thành Đông Thái, và nay là Hạ Thái. Xuất phát điểm là một làng nông nghiệp, Hạ Thái đã tận dụng lợi thế gần sông Tô Lịch và các trục giao thông thủy, bộ để phát triển đa dạng ngành nghề, trong đó nghề sơn nổi bật và trở thành thương hiệu riêng.\n \n Nghề sơn mài Hạ Thái gắn liền với tên tuổi của cụ Đinh Văn Thành, một giảng viên người làng tại trường Mỹ thuật Đông Dương. Vào những năm 1930, cụ đã đưa kỹ thuật sơn mài từ trường về truyền dạy cho người dân trong làng, mở ra một giai đoạn phát triển mới cho nghề, từ sơn son thiếp vàng thuần túy (phục vụ vua chúa) sang sơn mài mỹ nghệ với các tác phẩm nghệ thuật đa dạng. Ngày 08/12/2020, Làng nghề sơn mài Hạ Thái được UBND thành phố Hà Nội công nhận là điểm du lịch. Năm 2017, Đình Hạ Thái được xếp hạng là di tích quốc gia.	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
d87f2ef2-2a17-46c5-9e51-69fa829da0c4	fdd98e46-3b65-490d-aadc-dbb90eab321d	\N	su_kien	Sự kiện lịch sử đã diễn ra	hời gian Sự kiện Ghi chú\n Khoảng thế kỷ XVII Nghề sơn bắt đầu hình thành tại làng, chủ yếu là sơn son thiếp vàng, được gọi là làng nghề "dâng vua". \n Khoảng năm 1780 Đình làng Hạ Thái được dựng và khánh thành (ngày rằm tháng 10 năm Canh Tý). \n Khoảng năm 1799 Chùa Phúc Thái (chùa làng) có chuông đồng được khắc ghi niên đại\n Những năm 1930 Cụ Đinh Văn Thành (giảng viên trường Mỹ thuật Đông Dương) đưa kỹ thuật sơn mài về làng, tạo bước ngoặt cho nghề. Đánh dấu sự ra đời của tranh sơn mài hiện đại Hạ Thái.\n Trước 1980 Nghề sơn mài chịu ảnh hưởng bởi các cơ chế kinh tế khác nhau: trước 1945 sản xuất đồ thờ; 1945-1989 thời kỳ hợp tác xã bao cấp; từ 1989 đến nay tự sản tự tiêu, hình thành các doanh nghiệp tư nhân\n Khoảng năm 2006 Cụm công nghiệp làng nghề sơn mài Hạ Thái được hình thành và quy hoạch, tập trung các xưởng sản xuất[citation:8]. \n 2017 Đình Hạ Thái được Bộ Văn hóa Thể thao và Du lịch xếp hạng là di tích quốc gia (Quyết định số 824/QĐ-BVHTTDL, đợt 1/2017). \n 08/12/2020 Làng nghề sơn mài Hạ Thái được UBND thành phố Hà Nội công nhận là điểm du lịch (Quyết định số 5543/QĐ-UBND)	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
8ba64392-e29c-4942-bcf1-10dd49b2db73	fdd98e46-3b65-490d-aadc-dbb90eab321d	\N	truyen_thuyet	Truyền thuyết	Truyền thuyết về bà Đinh Thị Trạch (bà Lạy): Theo thần phả, vùng đất làng Hạ Thái xưa kia hoang vu, có một con hổ dữ (hổ lang) thường xuyên quấy phá, bắt người và gia súc. Không thể thu phục, dân làng đành phải cống nạp cho hổ một người vào ngày 10/11 hàng năm. Một người đàn bà không chồng con là bà Lạy, thấu hiểu nỗi đau của dân làng, đã tự nguyện xin dâng mình cho hổ để chấm dứt nạn cống nạp. Từ ngày bà bị hổ bắt đi mất, dân làng không còn thấy hổ quay lại. Để tưởng nhớ công ơn, bà được tôn làm Thành hoàng và ngày 10/11 trở thành ngày lễ hội chính của làng.\n \n Truyền thuyết về ông Bùi Sĩ Lương: Ông là quan võ thời Lê (1544-1597), người thông minh, văn võ song toàn, có công lớn trong việc phò Lê diệt Mạc. Khi đến vùng đất Hạ Thái, ông nhận thấy nơi đây có thế đất đẹp (rồng chầu hổ phục), bèn chọn lập gia trang và dạy dân chúng lập nghiệp. Sau khi mất, ông cũng được dân làng tôn là Thành hoàng và thờ phụng tại Đìn	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
684ce0eb-c72d-45a8-96fa-b56ce4414fa7	09ee09b0-41f2-429c-a515-0cd2592edc44	\N	lich_su	Lịch sử làng	Làng Chuông là một làng quê truyền thống lâu đời có từ thời xa xưa nằm giữa trung tâm tỉnh Hà Tây cũ nay là Thành Phố Hà Nội. Vào thế kỷ thứ 8 - 791 năm Tân Mùi, theo các bậc cao niên trong làng thì ban đầu làng Chuông có tên là Trang Thì Trung, về sau đông dân hơn nên được mở rộng thành làng. Đầu thời Lên Sơ, làng Chuông đã rất đông đúc. \nLàng Chuông là một làng nghề nổi tiếng cả nước với truyền thống làm nón lâu đời thông qua sản phẩm nón lá. Người dân làng Chuông sống chủ yếu bằng nghề làm nón lá và làm ruộng. Không nhiều người dân trong làng biết chiếc nón xuất hiện từ khi nào nhưng trong ca dao xưa đã có câu “Nón Chuông, khua lụa, quai thao làng Đơ”.	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
2ae41fd7-5978-43a6-9c30-1e32f79693f4	09ee09b0-41f2-429c-a515-0cd2592edc44	\N	su_kien	Sự kiện lịch sử đã diễn ra	Tháng Chín năm Đinh Mùi (tháng 10 năm 1847), Nguyễn Phúc Thì lên ngôi, năm sau (1848 – Mậu Thân) đặt niên hiệu và Tự Đức thì ngôi làng kiêng tên húy của vua nên xã Thì Trung và tổng Thì Trung phải đổi tên thành Phương Trung cùng các xã trong huyện Thanh Oai. Những dòng họ lớn trong làng là Lê Văn, Phạm. Ở cổng đinh làng có khắc đôi câu đối khẳng định vị thế của làng: \n“Thì Trung được đất tốt, âm trợ dương phù, ngoài chấn vũ công, muôn thuở trường tồn”.	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
8bfaebe0-a495-419c-b3d8-7f5b3124d041	c33319de-4845-41bf-94c1-3fa501e5e867	\N	lich_su	Lịch sử làng	Làng Cựu là một làng cổ, từ đời vua Lê Thánh Tông làng thuộc phủ Thường Tín, trấn Sơn Nam. Trước cách mạng tháng Tám, làng thuộc xã Vân Hoàng, huyện Phú Xuyên.\nLàng được thành lập từ lâu, người thành lập làng là Trần Ninh Thuận. Theo gia phả họ trần kể lại: Đầu thế kỉ 13, trước kia làng là khu vực vùng chiêm trũng, hoang vu chỉ có toàn cây cỏ. Cụ tổ của làng là Trần Ninh Thuận làm nghề chài lưới kiếm cá xuôi theo dòng sông Nhuệ xuống tới vùng này thấy có vài đồi gò hiện lên trên vùng đất trũng nên đã quyết định ở lại sinh sống, theo thời gian các ngư dân làm nghề chài lưới đi qua thấy vùng này có người ở nên cũng quyết đinh ở lại lập làng. Đặt tên làng là Cựu.	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
a2ce6e31-9884-4b84-8115-1097b9acf415	c33319de-4845-41bf-94c1-3fa501e5e867	\N	su_kien	Sự kiện lịch sử đã diễn ra	Biến cố hỏa hoạn năm 1921: Bước ngoặt lớn nhất của làng xảy ra vào năm 1921 khi một gia đình nấu ăn bất cẩn đã gây ra trận hỏa hoạn lớn. Do phần lớn là nhà tranh tre nứa lá, ngọn lửa đã nhanh chóng thiêu rụi 2/3 số nhà cửa trong làng. Đối diện với cảnh mất mùa, đói kém lại thêm nhà cửa hóa tro bụi, người dân khốn quẫn buộc phải khăn gói rời làng ra Hà Nội tìm đường mưu sinh. Hai người đầu tiên bước chân vào nghề may là anh em ông Phúc Mỹ, Phúc Hưng. Thấy làm ăn tốt, các ông bắt đầu về làng kéo mọi người đi làm cùng. Chẳng ai ngờ những đôi bàn tay chai sần bởi cuốc với cày lại có thể khéo léo tạo ra những bộ veston, bộ đầm đẹp đến thế. Họ may chủ yếu cho người Pháp và lớp người giàu ở Hà Nội.Từ những người nông dân cầm cuốc, người làng Cựu đã bén duyên với nghề may (bắt đầu từ hai anh em ông Phúc Mỹ, Phúc Hưng) và nhanh chóng phất lên, trở thành những "thợ may đệ nhất Hà Thành" . Họ chuyên may đo cho người Pháp và giới nhà giàu ở Hà Nội, sau đó bao thầu luôn cả nghề buôn vải, mở rộng thị trường vào tận Sài Gòn - Chợ Lớn. Kiến thiết quê hương (1920 - 1945): Thành công từ nghề may giúp người làng Cựu từ nông dân trở thành những triệu phú . Sự giàu có này được họ mang về quê hương để xây dựng hàng loạt biệt thự tráng lệ, nguy nga mang phong cách giao thoa Á - Âu (với vòm cuốn, mái chảy, gỗ lim, ngói mũi...) trong suốt giai đoạn từ năm 1920 đến 1945	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
def65a87-2115-409a-a7d6-93bb6e4cb852	c33319de-4845-41bf-94c1-3fa501e5e867	\N	truyen_thuyet	Truyền thuyết	Theo truyền thuyết đó là sự tích về cụ Thế tổ thứ 2 Trần miêu thuật nuôi hổ để trông coi gia sản. Cụ mặc thường phục giả danh để thử hổ xem việc trông coi có chăm chỉ không. Sự việc đã gây nên tai họa, hổ tát nhầm vào cụ, cụ đã tử vong. Di hài của thế tổ được mang đi chôn tại Hạ Thái, Thường Tín và ở thôn Cự, xã Vân Từ, Phú Xuyên nơi có hai nấm mồ máu do Hổ vun lại cùng gọi là Cổ Bồng.	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
1cd17162-17ac-4875-8b8d-f55f8da005ef	8216fe86-f66d-4b19-904b-cbdee0bf1eba	\N	lich_su	Lịch sử làng	Nghề mây tre đan truyền thống đã tồn tại và phát triển hơn 400 năm. Làng Phú Vinh được hình thành từ năm 1700, với tên gọi ban đầu là làng Phú Hoa Trang (Trời phú cho dân có bàn tay lụa), vì người dân nơi đây có bàn tay khéo léo, điệu nghệ, giỏi đan lát mây tre.\nVà cứ thế, theo nghề “cha truyền con nối”, những đứa trẻ làng Phú Vinh lớn lên đã gắn bó với cây mây, cây tre, nắm lòng bàn tay các thuộc tính của từng cây tre, từng sợi mây. Dần dần, mây tre đan đã phát triển trở thành nghề truyền thống của làng Phú Vinh. Những người thợ lành nghề càng ngày càng tạo ra nhiều các sản phẩm mây tre đan đẹp mắt, tinh xảo, đa dạng về mẫu mã, chủng loại.	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
41000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	\N	lich_su	Lịch sử làng	Ước Lễ nổi tiếng với nghề làm giò chả. Nghề làm giò chả ở làng Ước Lễ có cách đây gần 500 năm. Theo truyền miệng, thời nhà Mạc (1527 - 1592) có một cung tần trong triều đình vốn là người làng Ước Lễ về xây cổng làng và dạy cho dân làng nghề giò chả. Từ đó cha truyền con nối, nghề giò chả trở thành nghề truyền thống của làng Ước Lễ.	\N	2026-09-21 02:54:19.176135+00	2026-09-21 07:18:35.222331+00
41000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000001	\N	su_kien	Sự kiện lịch sử đã diễn ra	Theo thông tin lịch sử, cổng làng Ước Lễ được xây dựng vào năm 1851 (đời vua Tự Đức). Làng Ước Lễ là một trong số ít làng xây dựng được quỹ cứu trợ người dân trong những lúc gặp khó khăn: loạn lạc, mất mùa,...  có những lúc quỹ cứu trợ này lên tới 2000 đồng Đông Dương. Theo luật lệ thời đó, các làng xây dựng được quỹ cứu trợ 1000 đồng Đông Dương đã được vua ban thưởng, nên làng Ước Lễ đã được vua ngự ban cho biển “Mỹ tục khả phong” (Phong tục hay nên theo). Đến thời chống Pháp, lầu trên của cổng đã bị bắn phá đổ cùng với biển trên. Người dân làng đã cúng tiến và xây dựng lại tầng trên cùng với làm lại biển chữ từ khoảng năm 2000.	\N	2026-09-21 02:54:19.176135+00	2026-09-21 07:18:35.222331+00
41000000-0000-0000-0000-000000000003	00000000-0000-0000-0000-000000000001	\N	phong_tuc	Phong tục	ở Ước Lễ còn có một phong tục vô cùng độc đáo, đó là tục ăn “Tết bù” vào ngày rằm tháng Giêng. Phong tục này xuất phát từ việc dân làng thường bận làm giò chả phục vụ nhu cầu ăn Tết của người dân khắp nơi nên không thể chuẩn bị Tết chu đáo. Vì thế, rằm tháng Giêng mới là dịp các gia đình ở Ước Lễ quây quần ăn “Tết bù”.	\N	2026-09-21 02:54:19.176135+00	2026-09-21 07:18:35.222331+00
41000000-0000-0000-0000-000000000004	00000000-0000-0000-0000-000000000001	\N	truyen_thuyet	Truyền thuyết	ngày xưa, ông Lữ Gia đánh trận thua, chạy về tới cây đa trước cổng làng đầu đã bị chém gần lìa, gặp một bà cụ người làng, hỏi: Người bị chém đứt đầu có sống được không? Bà cụ nói: Sống thế nào được. Ông bèn dứt đầu ra khỏi cổ rồi ngã xuống ngựa. Dân tôn ông làm Thành hoàng, thờ cúng ở đình cho đến nay.\nTruyền thuyết kể rằng, mảnh đất giữa làng xưa kia là nền của kho dự trữ thóc gạo do làng tự lập, gọi là quỹ “Nghĩa thương”. Làng cử người coi sóc, nhằm giúp đỡ dân nghèo trong làng và người cơ nhỡ. Vua Tự Đức kinh lý qua thấy phong tục đẹp, phong cho bốn chữ “Mỹ tục khả phong”. Bản hương ước lập năm 1928 có 106 điều, trong đó có một điều rất hay, tôi cho rằng ít có làng quê xứ Bắc xưa nào đề cập đến: “Đi ăn cỗ cấm lấy phần”.	\N	2026-09-21 02:54:19.176135+00	2026-09-21 07:18:35.222331+00
\.


--
-- Data for Name: intangible_heritage_items; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.intangible_heritage_items (id, village_id, name, recognition_level, uniqueness_description, participation_scope, generations_transmitted, tourist_experience_level, event_timing, capacity_note, media_ids, created_at, updated_at) FROM stdin;
4db72c36-f46c-41ef-ae97-b2151dba097f	01000000-0000-0000-0000-000000000001	Hội làng	\N	Ngày 13 tháng giêng tổ chức vật thờ tại đình, đây cũng là nguồn gốc tên đình Vật. Ngày 14 tháng giêng ra đình dâng lễ. Tế ở miếu (nới thờ 2 vị Thành Hoàng làng), sau đó phụng nghênh Thánh giá xuống đình, Thánh giá đi qua cửa miếu sang cửa chùa sau đó rước xuống đình Vật . Từ ngày 15 diễn ra tế lễ thành hoàng vào sáng và chiều, xen vào là các hoạt động văn hóa thể thao, buổi tối hát cửa đình, chèo. Hội diễn ra 3 hoặc 5 ngày, ngày cuối làm lễ rước Thánh về miếu.	toan_the_cong_dong	hơn 3 thế hệ (cụ kị/  tổ tiên - ông bà - bố mẹ -con cháu) — từ lâu đời	trai_nghiem_mot_phan	tổ chức ngày 14/1 hàng năm làm lễ dâng hương ở đình. Cứ 2 hoặc 5 năm thì làm lễ lớn, rước thánh từ miếu qua cổng chùa rồi đến Đình Vực, lễ 3 hoặc 5 ngày, ngày cuối rước Thánh về miếu	khoảng 1000 người	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
e21d9719-b541-4608-9fe5-8b93fb79c662	01000000-0000-0000-0000-000000000001	Ẩm thực truyền thống: làm miến	\N	Miến làng Cự đà làm 100% bằng bột dong riềng, bột dong riềng phơi khô là tốt nhất. Dong riềng lấy từ các vùng như Bắc Kan, Lai Châu, Sơn La, Mộc Châu,… Bột dong riềng được ngâm với nước và lọc để chọn phần tinh bột, rồi đánh lên. Một phần bột được ngâm với nước sôi gọi là bột chin. Bột chin mang hòa với bột đã lọc, với tỷ lệ 1/10 tạo nên hỗn hợp. Tiếp đó, bột được tráng thành bánh, hấp chin, đem phơi nắng. Sau khi gần khô, bánh được đưa qua máy cán thành từng sợi miến nhỏ, dài và phơi nắng tiếp là thành miến thành phẩm. \n Hiện phơi miến ở bãi ngoài làng	toan_the_cong_dong	3 thế hệ (ông bà - bố mẹ - con cháu) — 3 thế hệ, khoảng từ 1950-1960	chi_xem	\N	\N	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
e81a43b9-ebd8-4d8c-b739-4ca33360e050	01000000-0000-0000-0000-000000000001	Ẩm thực truyền thống: làm tương	\N	Từ hàng trăm năm nay với câu ca danh truyền “Tương Cự Đà, cà làng Đám".Nguyên liệu để làm tương gồm gạo nếp, muối, đậu tương và nước sạch, làm nước mưa thì ngon hơn. Đối với gạo, phải chọn loại gạo nếp cái hoa vàng, là giống gạo nếp truyền thống nổi tiếng tại các tỉnh đồng bằng và trung du Bắc Bộ, có hạt gạo tròn, dẻo, thơm. Đậu tương cũng phải là đậu tương leo, khi chin hạt vẫn nhỏ và có màu vàng nhạt. Tương ngon phụ thuộc chính vào khâu làm mốc. Khi mốc đã vàng, đậu tương rang đã tróc vỏ thì phải ngâm cho hạt đậu ngập đủ nước, cộng thêm một lượng men rồi đem ủ kín trong bể. Khi mở bể cũng là lúc người làm phải khéo léo đảo sao cho tương phải đều, phải quyện, bao giờ thấy tương giống như loại bột lỏng thì coi như được.\nXưa kia chỉ người giàu mới mua được Tương Cự Đà và 1 năm làng cũng chỉ làm 1 vụ	toan_the_cong_dong	hơn 3 thế hệ (cụ kị/  tổ tiên - ông bà - bố mẹ -con cháu) — có lịch sử từ hàng trăm năm	chi_xem	\N	\N	\N	2026-09-21 07:18:17.766547+00	2026-09-21 07:18:17.766547+00
449d2e8f-2b44-4aa1-9c9c-7f93aafe140d	fdd98e46-3b65-490d-aadc-dbb90eab321d	Lễ hội làng	\N	Lễ rước kiệu với sự tham gia của các thanh niên độc thân khiêng kiệu; Lễ tế nam và tế nữ riêng biệt; Hát quan họ trên thuyền rồng; Gắn với sự tích bà Đinh Thị Trạch tự nguyện nộp mình cho hổ để cứu dân làng.	mot_nhom_hoi	\N	chi_xem	Chỉ tổ chức vào 1 thời gian cố định trong năm (9-11/11 âm lịch)	500 người - 1000 người	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
c222e4cb-64eb-4d3f-bf02-5f501d5af189	fdd98e46-3b65-490d-aadc-dbb90eab321d	Tín ngưỡng và tập quán xã hội (Tín ngưỡng thờ mẫu / tín ngưỡng phồn thực / Tín ngưỡng thờ thành hoàng làng / khác )	\N	Thờ hai vị Thành hoàng: Thái sư Bùi Sĩ Lương và bà Đinh Thị Trạch (Bà Lạy). Sự tích bà Lạy tự nguyện hiến thân cho hổ để cứu dân làng là độc đá	mot_nhom_hoi	\N	chi_xem	Chỉ tổ chức vào 1 thời gian cố định trong năm (9-11/11 âm lịch)	500 người - 1000 người	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
3e527667-a74f-4430-9363-008103516095	fdd98e46-3b65-490d-aadc-dbb90eab321d	Ngữ văn dân gian (chuyện kể, thần thoại, cổ tích…)	\N	Làng Hạ Thái nổi tiếng với nghề sơn mài, được xác định có mặt từ thế kỷ XVII. Điểm đặc trưng là kỹ thuật sơn mài với các vật liệu truyền thống như sơn cánh gián, sơn then, vỏ trai, vàng thếp, kết hợp kỹ thuật mài để tạo nên tác phẩm độc đáo. Sản phẩm lấy cảm hứng từ thiên nhiên và cảnh vật làng quê Việt Nam	mot_nhom_hoi	\N	chi_xem	Tổ chức được bất cứ thời gian nào trong năm	Dưới 500 người	\N	2026-09-21 07:18:32.03307+00	2026-09-21 07:18:32.03307+00
c18d493d-2a0a-47f8-b5ef-865028705418	09ee09b0-41f2-429c-a515-0cd2592edc44	Lễ hội làng Thuận Vi	\N	Tổ chức Hầu bóng (ba sáu giá) từ 10h00 đến 16h00 và tổ chức cho khách thập phương xin xăm (xin thẻ đầu năm cầu may mắn). Lễ rước kiệu, quay kiệu.	mot_nhom_hoi	2 thế hệ (bố mẹ - con cháu) — Hơn 3 thế hệ.	chi_xem	Chỉ tổ chức vào 1 thời gian cố định trong năm (vd: lễ hội chỉ tổ chức vào 1 vài ngày đầu năm)	Dưới 500 người.	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
e77efb55-f836-4c88-b7a3-7febe2142490	09ee09b0-41f2-429c-a515-0cd2592edc44	Ẩm thực truyền thống (bánh hấp)	\N	Bánh cuốn, bánh hấp, bún chả.	mot_nhom_hoi	\N	chi_xem	Tổ chức được bất cứ thời gian nào trong năm	500 người.	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
ed93388e-ec9a-4454-aa01-bb124ae55452	09ee09b0-41f2-429c-a515-0cd2592edc44	Nghệ thuật trình diễn dân gian (Chèo/ Múa rối nước / quan họ / ca trù / xẩm / khác)	\N	Nghệ thuật trình diễn nón lá ở làng Chuông thể hiện qua quá trình chế tác thủ công của người thợ với các công đoạn tỉ mỉ như xử lý lá, tạo khung, xếp lá và khâu nón. Điểm đặc trưng nằm ở sự khéo léo, kỹ thuật truyền đời và không gian trình diễn gắn với làng nghề, giúp du khách cảm nhận được giá trị văn hóa của chiếc nón lá và nghề thủ công truyền thống.	mot_nhom_hoi	2 thế hệ (bố mẹ - con cháu) — hơn 3 thế hệ (cụ kị/  tổ tiên - ông bà - bố mẹ -con cháu)	chi_xem	Chỉ tổ chức vào 1 thời gian cố định trong năm (vd: lễ hội chỉ tổ chức vào 1 vài ngày đầu năm)	Dưới  500 người.	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
3732fc6c-9e37-49c1-8277-7a48ca894740	09ee09b0-41f2-429c-a515-0cd2592edc44	Tín ngưỡng và tập quán xã hội (Tín ngưỡng thờ mẫu / tín ngưỡng phồn thực / Tín ngưỡng thờ thành hoàng làng / khác )	\N	\N	mot_nhom_hoi	2 thế hệ (bố mẹ - con cháu) — hơn 3 thế hệ (cụ kị/  tổ tiên - ông bà - bố mẹ -con cháu)	chi_xem	Tổ chức được bất cứ thời gian nào trong năm	Dưới 500 người.	\N	2026-09-21 07:18:32.871094+00	2026-09-21 07:18:32.871094+00
071da456-4608-49cf-b1b1-e6edaab0c749	c33319de-4845-41bf-94c1-3fa501e5e867	Lễ hội làng Cựu  (Lễ hội Thành Hoàng Làng Cựu)	\N	Nghề may – nghề đã làm nên tên tuổi và sự phồn thịnh của ngôi làng từ đầu thế kỷ XX. Không chỉ là dịp thực hành tín ngưỡng thờ Thành hoàng, lễ hội còn là dịp để con cháu làm nghề may trở về quê hương, tưởng nhớ tổ tiên và gìn giữ bản sắc làng nghề. Sự kết hợp giữa lễ hội truyền thống, nghề may lâu đời và không gian làng cổ đã tạo nên dấu ấn riêng của Làng Cựu.	mot_nhom_hoi	2 thế hệ (bố mẹ - con cháu) — Được truyền đời từ xưa đến nay.	chi_xem	Diễn ra trong 3 ngày, bắt đầu từ ngày mùng 7 đến mùng 9 tháng Giêng âm lịch hàng năm.	Dưới 500 người.	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
85e1349c-c7eb-4861-ba94-1f643b13d39b	c33319de-4845-41bf-94c1-3fa501e5e867	Ẩm thực truyền thống (bánh cuốn)	\N	Đặc trưng nằm ở cách làm thủ công, sự khéo léo trong tráng bánh, pha nước chấm và chuẩn bị nhân, phản ánh sự tinh tế của văn hóa ẩm thực Bắc Bộ.	\N	2 thế hệ (bố mẹ - con cháu) — Được truyền lại đến nay.	\N	\N	\N	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
e61abaa5-19a3-43c7-ba7a-9353fe67520a	c33319de-4845-41bf-94c1-3fa501e5e867	Trò chơi dân gian	\N	\N	mot_nhom_hoi	2 thế hệ (bố mẹ - con cháu) — Hơn 3 thế hệ.	chi_xem	Chỉ tổ chức vào ngày hội của làng.	Dưới 500 người.	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
3ea871c6-5864-4b84-84bc-2beca400d2a1	c33319de-4845-41bf-94c1-3fa501e5e867	Tri thức dân gian (nghề thuốc, chữa bệnh, may đo trang phục…)	\N	Nghề may Làng Cựu mang nét đặc trưng riêng bởi đây không chỉ là một nghề thủ công truyền thống mà còn gắn liền với quá trình hình thành và phát triển của cả cộng đồng cư dân. Từ đầu thế kỷ XX, nhiều người dân trong làng trở thành những thợ may nổi tiếng tại Hà Nội, phục vụ nhu cầu may đo cao cấp, đặc biệt là comple, veston. Sự phát triển của nghề may đã tạo nên sự thịnh vượng cho làng, làm thay đổi diện mạo không gian cư trú với những công trình kiến trúc mang dấu ấn giao thoa Việt – Pháp. Điểm đặc biệt của Làng Cựu nằm ở sự kết hợp giữa tay nghề may thủ công tinh tế, truyền thống làng nghề lâu đời và giá trị kiến trúc – văn hóa được hình thành từ chính nghề nghiệp của người dân.	\N	2 thế hệ (bố mẹ - con cháu) — Hơn 3 thế hệ.	chi_xem	Tổ chức bất cứ lúc nào trong năm.	Dưới 500 người.	\N	2026-09-21 07:18:33.53014+00	2026-09-21 07:18:33.53014+00
5c452674-fdb7-44ba-9532-9ab2982c27ee	8216fe86-f66d-4b19-904b-cbdee0bf1eba	Lễ hội làng Đồng Trữ	\N	Tổ chức ngày 16 và ngày 17/3 (tức ngày 11 và 12/2 năm Kỷ Hợi)\nlễ hội Quán Bà - thôn Đồi Chè, xã Thanh Bình được tổ chức ngày 18 và 19/3 (tức ngày 13 và 14/2 năm Kỷ Hợi) nhằm tưởng nhớ công lao to lớn của các vị Thành Hoàng làng. Cả hai lễ hội truyền thống đều diễn ra với chương trình đó là:  phần lễ gồm tế lễ, dâng hương và rước kiệu truyền thống. Phần hội diễn ra các hoạt động như: giao lưu văn hóa văn nghệ, các trò chơi dân gian...	\N	\N	\N	\N	\N	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
f80025b2-f08d-4752-966f-44c1aa0badd6	8216fe86-f66d-4b19-904b-cbdee0bf1eba	Ẩm thực truyền thống (bánh cuốn, bánh đúc)	\N	Làng Phú Vinh có món\nbánh cuốn ngon nổi tiếng trong vùng. Theo Nguyễn Văn Trung – Trước đây từng là chủ nhiệm CLB nghệ nhân; hiện nay chỉ dạy nghề chứ không sản xuất, thì món bánh cuốn làng Phú Vinh được nhiều người dân trong ngoài làng cũng như du khách ưa thích. Ngoài ra ở chợ Chuông còn có món bánh đúc lạc cũng được bày bán thường xuyên trong các phiên chợ và là một món ăn dân dã gắn bó với cuộc sống người nông dân.	\N	\N	\N	\N	\N	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
853fa527-b187-4f8b-9941-82b0183bcc93	8216fe86-f66d-4b19-904b-cbdee0bf1eba	Tri thức dân gian (Nghề truyền thống)	\N	Làng nghề duy nhất ở Việt Nam có kỹ thuật xâu xiên sử dụng sợ Mây. Đây là kỹ thuật đỉnh cao của nghệ thuật đan lát Việt Nam. Được làm thủ công từ đôi bàn tay khéo léo, được chăm chút bằng trái tim yêu nghề say nghề, mỗi sản phẩm mây tre đan Phú Vinh đều mang trên mình dấu ấn của cá nhân người nghệ nhân, dấu ấn của quê hương và cả hơi thở của thời đại. Từ cái nơm cái vó, cái mủng cái giỏ xưa kia, vẫn bằng kỹ thuật đan lát được truyền từ đời này qua đời khác nhưng nhờ sự sáng tạo của các nghệ nhân, bình hoa, lót cốc, cái khay, chiếc ghế với nhiều hoa văn đẹp mắt đã ra đời phục vụ nhu cầu của người dân. Kết quả lao động sáng tạo ấy đã giúp nhiều gia đình, nhiều thế hệ người làng trụ được với nghề truyền thống.	\N	hơn 3 thế hệ (cụ kị/  tổ tiên - ông bà - bố mẹ -con cháu) — Hơn 3 thế hệ	trai_nghiem_toan_bo	Bất cứ thời gian nào	Dưới 500 người	\N	2026-09-21 07:18:34.352443+00	2026-09-21 07:18:34.352443+00
d5fa2839-2491-425d-bb65-dc108cee8575	00000000-0000-0000-0000-000000000001	Lễ hội làng	\N	Ngày 12/3 và 12/8 là ngày kỳ phước, giỗ Thành hoàng làng: 12/3 cúng thịt thủ tại đình; ngày 12/8 thì làm thịt bò thui trấu, là ngày lễ đặc biệt trong làng. Thường có khoảng 160-170 mâm tại Đình	toan_the_cong_dong	\N	\N	12/3 và 12/8 âm lịch	\N	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
9397e3f7-6cda-4c63-a35a-84aafb1ca11c	00000000-0000-0000-0000-000000000001	Lễ hội ăn Tết bù	\N	Cứ vào ngày Rằm tháng Giêng hàng năm, trong khi người dân khắp mọi miền nô nức lễ chùa thì làng giò chả Ước Lễ lại rộn ràng ăn Tết trở lại. Đặc biệt, ở làng Ước Lễ có một tục lệ “bất thành văn” là những người con xa quê hương dù ở mọi miền đất nước và có bận trăm công ngàn việc cũng sắp xếp về sum họp cùng gia đình, bà con dân làng. Theo nghi lễ của làng, sau khi làm lễ cúng gia tiên xong, người dân làng Ước Lễ súng sính quần áo lên chùa dự hội, xin lộc hoặc đến các gia đình hàng xóm để gặp mặt nhau và chúc Tết cho nhau những điều tốt đẹp nhất.	toan_the_cong_dong	\N	trai_nghiem_toan_bo	Rằm tháng Giêng	chia về ăn cỗ ở các nhà dân	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
b7010a01-e06c-4ac2-9bea-7e7c5e04158a	00000000-0000-0000-0000-000000000001	Ẩm thực truyền thống: giò chả	quoc_gia	Làm từ thịt lợn tươi, còn nóng, với các khâu lọc, xay, gói. Gói giò bằng lá chuối, để giò thơm ngon, dậy mùi. Lá chuối cũng phải chọn kỹ, lá nõn lần trong, lá bánh tẻ lần giữa, lá già lần ngoài. Giò gói xong đem thả ngay vào nồi nước sôi và luộc, tùy theo cỡ giò mà có thời gian vớt thích hợp. Giò thành phẩm mịn, nhẵn có màu hồng nhạt, ăn phải giòn, còn thơm mùi thịt, miếng giò cắt ra phải có những lỗ nhỏ… mới là giò ngon. Miếng giò mượt như lụa nên được gọi tên là giò lụa	toan_the_cong_dong	hơn 3 thế hệ (cụ kị/  tổ tiên - ông bà - bố mẹ -con cháu) — hơn 500 năm	trai_nghiem_toan_bo	Tổ chức hàng tuần vào thứ 5, thứ 7 hoặc khi có đoàn đăng ký	\N	\N	2026-09-21 07:18:35.222331+00	2026-09-21 07:18:35.222331+00
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.media (id, url, kind, attribution, caption, owner_entity_type, owner_entity_id, created_at, updated_at) FROM stdin;
dd7c9441-08d8-4b32-bb3b-67674a8dca68	/api/uploads/villages/a6b6aab9-98a0-4865-8c7b-07ba22f1144c.jpg	anh	\N	\N	villages	09ee09b0-41f2-429c-a515-0cd2592edc44	2026-09-25 15:11:36.133835+00	2026-09-25 15:11:36.133835+00
aef52a73-4dde-4edf-9c54-e08ba739d014	/api/uploads/villages/1adf6d6e-437c-4dc1-9ca2-088f0e7df651.jpg	anh	\N	Tổng mặt bằng làng Cự Đà	villages	01000000-0000-0000-0000-000000000001	2026-09-21 02:53:49.449443+00	2026-09-25 15:13:18.902718+00
30000000-0000-0000-0000-000000000005	/heritage/khu-lang.jpg	anh	\N	\N	sites	20000000-0000-0000-0000-000000000005	2026-09-21 02:53:32.05889+00	2026-09-21 02:53:32.05889+00
5b3324ed-e842-417d-bc18-1ae6b715f7d9	/cu-da/sites/chua-cu-da-21000000-1.jpg	anh	\N	Chùa Cự Đà	sites	21000000-0000-0000-0000-000000000009	2026-09-21 02:53:49.453492+00	2026-09-21 02:53:49.453492+00
6487981d-5192-46ab-85ba-2838d8f812c9	/cu-da/sites/cay-nhan-2-21000000-1.jpg	anh	\N	Cây	sites	21000000-0000-0000-0000-000000000021	2026-09-21 02:53:49.460537+00	2026-09-21 02:53:49.460537+00
e2cf5a74-a0c2-4e72-91db-c0770ff91203	/cu-da/sites/cay-muom-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000020	2026-09-21 02:53:49.4625+00	2026-09-21 02:53:49.4625+00
b66e95d3-8f5e-42c4-b6e2-0e87c10b83e2	/cu-da/sites/cay-nhan-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000019	2026-09-21 02:53:49.46444+00	2026-09-21 02:53:49.46444+00
fa634fd2-81bd-4196-84c8-f8e084f2f3be	/cu-da/sites/cong-lang-cu-da-21000000-1.jpg	anh	\N	Cổng Giữa	sites	21000000-0000-0000-0000-000000000005	2026-09-21 02:53:49.466806+00	2026-09-21 02:53:49.466806+00
bfb9049c-0e8f-4456-bb5b-1e20fb514728	/cu-da/sites/cong-lang-cu-da-21000000-2.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000005	2026-09-21 02:53:49.469474+00	2026-09-21 02:53:49.469474+00
b20a2743-7e10-4842-9c5c-95b3f61984bd	/cu-da/sites/cong-xom-duong-lang-nha-co-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000013	2026-09-21 02:53:49.471432+00	2026-09-21 02:53:49.471432+00
94e97152-6bda-4806-abc7-b2b41461ad42	/cu-da/sites/cong-xom-hieu-de-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000011	2026-09-21 02:53:49.473543+00	2026-09-21 02:53:49.473543+00
8559ce87-68a6-4412-bc7f-09cf07d61c89	/cu-da/sites/cong-xom-quang-trung-21000000-1.jpg	anh	\N	Cổng Xóm Quang Trung	sites	21000000-0000-0000-0000-000000000012	2026-09-21 02:53:49.475525+00	2026-09-21 02:53:49.475525+00
a5e67258-f93b-4288-834f-1cac764e02aa	/cu-da/sites/gieng-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000010	2026-09-21 02:53:49.479466+00	2026-09-21 02:53:49.479466+00
3f6916bf-46ea-4718-827d-e6be12f0dbd8	/cu-da/sites/nha-co-216-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000018	2026-09-21 02:53:49.484433+00	2026-09-21 02:53:49.484433+00
0b29a4d9-8ed0-4cbd-a8ac-ea45578640fd	/cu-da/sites/nha-co-31-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000015	2026-09-21 02:53:49.486561+00	2026-09-21 02:53:49.486561+00
e4a074a8-916e-41da-91e1-58236c64ab5b	/cu-da/sites/nha-co-cu-mao-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000017	2026-09-21 02:53:49.48944+00	2026-09-21 02:53:49.48944+00
42bbdf20-e577-4df1-9f59-ab78dccb2cf7	/cu-da/sites/nha-co-ong-giao-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000016	2026-09-21 02:53:49.491558+00	2026-09-21 02:53:49.491558+00
d3cd9de7-6642-487b-816e-c877ca52833d	/cu-da/sites/nha-tho-ho-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000014	2026-09-21 02:53:49.494436+00	2026-09-21 02:53:49.494436+00
830630d3-7b6e-4126-a5de-be10ff15e872	/cu-da/sites/quan-nuoc-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000023	2026-09-21 02:53:49.496558+00	2026-09-21 02:53:49.496558+00
b8c5f58f-4a6f-437c-9d01-eba2701205ea	/cu-da/sites/quan-an-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000022	2026-09-21 02:53:49.49851+00	2026-09-21 02:53:49.49851+00
e21516c2-d281-41dd-8cd1-bd81a2242e68	/cu-da/sites/dan-xa-tac-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000008	2026-09-21 02:53:49.50048+00	2026-09-21 02:53:49.50048+00
3caacaa5-6908-4892-94a1-bde20cb29d03	/cu-da/sites/duong-chinh-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000001	2026-09-21 02:53:49.504569+00	2026-09-21 02:53:49.504569+00
8525b395-195f-47a6-8bba-bf6c9099de73	/cu-da/sites/duong-lang-gan-voi-hoat-dong-san-xuat-mien-21000000-1.jpg	anh	\N	\N	sites	21000000-0000-0000-0000-000000000003	2026-09-21 02:53:49.506524+00	2026-09-21 02:53:49.506524+00
3722c3ba-14ac-4d31-a7cb-7df911859b6f	/uoc-le/sites/quan-moi-1.jpg	anh	\N	Quán mới	sites	20000000-0000-0000-0000-000000000010	2026-09-21 02:54:18.884179+00	2026-09-21 02:54:18.884179+00
edaaac9a-5454-40c6-a336-a509a6258eab	/uoc-le/sites/chua-sung-phuc-2.jpg	anh	\N	Chùa Sùng Phúc	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.903113+00	2026-09-21 02:54:18.903113+00
eb9d5804-4e9f-4d10-807b-556e71f48d01	/uoc-le/sites/den-cho-1.jpg	anh	\N	Đền Chợ	sites	20000000-0000-0000-0000-000000000016	2026-09-21 02:54:18.91313+00	2026-09-21 02:54:18.91313+00
c7a18111-2948-4765-aa00-82aa8388c477	/uoc-le/sites/nha-ba-van-sieu-co-1.jpg	anh	\N	Nhà bà Vân	sites	20000000-0000-0000-0000-000000000020	2026-09-21 02:54:18.915204+00	2026-09-21 02:54:18.915204+00
f2d88db7-929d-49fa-8c06-27f0b30f0002	/uoc-le/sites/nha-co-khum-biec-ten-1.jpg	anh	\N	Nhà cổ không biết tên	sites	20000000-0000-0000-0000-000000000019	2026-09-21 02:54:18.918103+00	2026-09-21 02:54:18.918103+00
0fe8039c-8f53-4083-b526-e479013bdd1a	/uoc-le/sites/nha-co-nha-cu-sam-1.jpg	anh	\N	Nhà cụ Sẩm	sites	20000000-0000-0000-0000-000000000012	2026-09-21 02:54:18.920228+00	2026-09-21 02:54:18.920228+00
fd26ab91-dbaa-4c84-9279-d080ed2db325	/uoc-le/sites/gieng-ngo-phat-1.jpg	anh	\N	Giếng Ngõ Phát	sites	20000000-0000-0000-0000-000000000004	2026-09-21 02:54:18.931077+00	2026-09-21 02:54:18.931077+00
dcc29e30-3ca5-4434-b47b-6222fb975b1b	/uoc-le/sites/dinh-lang-uoc-le-5.jpg	anh	\N	Chụp thượng lương	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.936096+00	2026-09-21 02:54:18.936096+00
a254b52f-8840-4809-8f53-4896928a84fd	/uoc-le/sites/dinh-lang-uoc-le-6.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt bên công trình	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.938236+00	2026-09-21 02:54:18.938236+00
75561a50-a386-4da1-a37d-7cd983d85e3f	/cu-da/sites/chua-cu-da-21000000-2.jpg	anh	\N	Chùa và miếu không có sông bên cạnh	sites	21000000-0000-0000-0000-000000000009	2026-09-21 02:53:49.456498+00	2026-09-21 02:54:20.975172+00
fa2eb908-9ea5-4743-ab85-6038e85d3099	/uoc-le/sites/chua-sung-phuc-4.jpg	panorama	\N	Chùa Sổ	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.92914+00	2026-09-21 08:08:41.780335+00
621b3b73-f88e-45c8-920a-3f40f3ebc847	/uoc-le/sites/dinh-lang-uoc-le-2.jpg	panorama	\N	Xếp hạng di tích gì — ảnh công nhận di tích	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.933231+00	2026-09-21 08:08:41.780335+00
c15ec5a0-7594-4484-877f-100e302eafad	/uoc-le/sites/dinh-lang-uoc-le-7.jpg	panorama	\N	Mặt đứng, mặt bên công trình — Mặt đứng công trình	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.94108+00	2026-09-21 08:08:41.780335+00
248eb4d9-0c1c-42a0-a9f5-cb99ceb9dda4	/uoc-le/sites/dinh-lang-uoc-le-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.943198+00	2026-09-21 02:54:18.943198+00
cc4f581f-5b3d-401a-b077-7398627aee04	/uoc-le/sites/dinh-lang-uoc-le-11.jpg	anh	\N	Mái_cấu tạo — Mái	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.946087+00	2026-09-21 02:54:18.946087+00
91ef1cba-d2bd-48e6-a869-c84c7a1ec77a	/uoc-le/sites/dinh-lang-uoc-le-12.jpg	anh	\N	Hình ảnh hiên — ẢNh hiên	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.948203+00	2026-09-21 02:54:18.948203+00
8b47472e-a3cb-4dba-b72c-ccb14c8c5a7a	/uoc-le/sites/dinh-lang-uoc-le-14.jpg	anh	\N	Kết cấu ảnh — Tổng thể bộ vì	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.953226+00	2026-09-21 02:54:18.953226+00
d504bfe7-928a-487b-86a9-86bd11c09f75	/uoc-le/sites/dinh-lang-uoc-le-15.jpg	anh	\N	Kết cấu ảnh — vì nóc	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.956097+00	2026-09-21 02:54:18.956097+00
dddb90e4-c737-4644-a660-6d63f6fe43ca	/uoc-le/sites/dinh-lang-uoc-le-16.jpg	anh	\N	Kết cấu ảnh — vì nách	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.958208+00	2026-09-21 02:54:18.958208+00
24a26ecb-5508-41c5-ac70-724dde1ca4fc	/uoc-le/sites/dinh-lang-uoc-le-17.jpg	anh	\N	Chân tảng ảnh — chân tảng	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.961093+00	2026-09-21 02:54:18.961093+00
ea10eb42-1861-46a7-b3d9-f5cca1c8784c	/uoc-le/sites/dinh-lang-uoc-le-18.jpg	anh	\N	Chân tảng hoa văn — hoa văn chân tảng	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.963056+00	2026-09-21 02:54:18.963056+00
07d07be0-1837-410c-9e1c-7cdfed77f412	/uoc-le/sites/dinh-lang-uoc-le-19.jpg	anh	\N	Chân tảng hoa văn — hoa văn chân tảng	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.965191+00	2026-09-21 02:54:18.965191+00
962d925d-08b6-46be-ac38-77044d10b1e2	/uoc-le/sites/dinh-lang-uoc-le-20.png	anh	\N	Linh vật: Rồng, Phượng, Lân, Long mã, nghê, rùa,…	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.96807+00	2026-09-21 02:54:18.96807+00
7bf5935a-ab66-45f7-94d5-008952513ef1	/uoc-le/sites/dinh-lang-uoc-le-21.jpg	anh	\N	Tích xưa	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.970182+00	2026-09-21 02:54:18.970182+00
7dd00503-4c7b-4909-9509-5bb70050f82e	/uoc-le/sites/dinh-lang-uoc-le-22.jpg	anh	\N	Đề tài cây cối: tre, trúc, tùng	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.97309+00	2026-09-21 02:54:18.97309+00
bd314dc2-bb83-4442-ba2f-b06afbca9298	/uoc-le/sites/dinh-lang-uoc-le-23.png	anh	\N	Mây	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.9752+00	2026-09-21 02:54:18.9752+00
0d6a5269-ee9f-4027-83b5-1e5be39f955c	/uoc-le/sites/chua-sung-phuc-5.jpg	anh	\N	Chụp thượng lương	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.978074+00	2026-09-21 02:54:18.978074+00
2083bc7f-37f0-4e8c-b64a-a71e1b234fd8	/uoc-le/sites/chua-sung-phuc-6.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt đứng	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.980202+00	2026-09-21 02:54:18.980202+00
f0e7fd3c-feb9-4cb7-861c-c459e44e3d9e	/uoc-le/sites/chua-sung-phuc-7.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt bên	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.983123+00	2026-09-21 02:54:18.983123+00
63642183-395a-473a-a834-cebb7179b1e1	/uoc-le/sites/chua-sung-phuc-8.jpg	anh	\N	Tam quan	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.985232+00	2026-09-21 02:54:18.985232+00
ae0a922c-ce43-4d3b-85dc-3420be654a43	/uoc-le/sites/chua-sung-phuc-9.jpg	anh	\N	Tả vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.98809+00	2026-09-21 02:54:18.98809+00
f22db19a-b26a-4cc1-8ced-f0bcb23a4a52	/uoc-le/sites/chua-sung-phuc-10.jpg	anh	\N	Hữu vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.990056+00	2026-09-21 02:54:18.990056+00
d9a86ffc-50b0-4a09-a2c0-aa376fca7db0	/uoc-le/sites/chua-sung-phuc-11.jpg	anh	\N	Bia đá hữu vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.992178+00	2026-09-21 02:54:18.992178+00
1cc9cd3c-c889-4d40-8f96-15cb2d6b5259	/uoc-le/sites/chua-sung-phuc-12.jpg	anh	\N	Bia đá tả vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.995089+00	2026-09-21 02:54:18.995089+00
a40be266-f442-4e93-b9f1-87848795d72e	/uoc-le/sites/chua-sung-phuc-13.jpg	anh	\N	Hậu đường — Gác chuông	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.997184+00	2026-09-21 02:54:18.997184+00
63802ebb-51cb-4c68-9b6c-7c90323d86f3	/uoc-le/sites/chua-sung-phuc-14.jpg	anh	\N	Phía sau Hậu đường — Phía sau hậu đường	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.000071+00	2026-09-21 02:54:19.000071+00
1a9ed418-ab1d-430c-80f5-5c84fd80c0df	/uoc-le/sites/chua-sung-phuc-16.jpg	anh	\N	Hình ảnh hiên — Hiên tiền đường	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.002191+00	2026-09-21 02:54:19.002191+00
1d9cb135-6b24-453f-931d-688fb7a343fa	/uoc-le/sites/chua-sung-phuc-17.jpg	anh	\N	Hiên tam quan	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.005094+00	2026-09-21 02:54:19.005094+00
be4804e6-8f51-4518-a1fe-89e676d7097b	/uoc-le/sites/chua-sung-phuc-18.jpg	anh	\N	Hiên gác chuông	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.007194+00	2026-09-21 02:54:19.007194+00
6ee01a39-418e-4919-97b8-1d21f7d30dac	/api/uploads/villages/169a50e4-9f79-48df-8187-202f176c89ab.jpg	anh	\N	\N	villages	8216fe86-f66d-4b19-904b-cbdee0bf1eba	2026-09-25 15:14:42.195956+00	2026-09-25 15:14:42.195956+00
9ff155e0-e5f3-4d10-988d-633de8db27c9	/uoc-le/sites/chua-sung-phuc-20.jpg	anh	\N	Nền hữu vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.012209+00	2026-09-21 02:54:19.012209+00
83638e23-e59f-4b77-a2c3-7141e1467c1a	/uoc-le/sites/chua-sung-phuc-21.jpg	anh	\N	Nền gác chuông	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.015088+00	2026-09-21 02:54:19.015088+00
3e4db191-3120-47e0-a170-8aabe65ff2e5	/uoc-le/sites/chua-sung-phuc-22.jpg	anh	\N	Nền tả vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.017218+00	2026-09-21 02:54:19.017218+00
3c9596d5-b4fd-4cb3-9b3d-4171ea41caae	/uoc-le/sites/chua-sung-phuc-23.jpg	anh	\N	Nền thượng điện	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.020113+00	2026-09-21 02:54:19.020113+00
0558f471-24f4-4af6-a387-f850498ae086	/uoc-le/sites/chua-sung-phuc-25.jpg	anh	\N	Ảnh trong nhà — Tả vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.025102+00	2026-09-21 02:54:19.025102+00
bee88e68-13b8-4e3f-bfef-ace791655b36	/uoc-le/sites/chua-sung-phuc-26.jpg	anh	\N	Ảnh trong nhà — Hữu vu	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.027075+00	2026-09-21 02:54:19.027075+00
dbbd02fb-cdd0-4cad-b7ff-f68a3625df83	/uoc-le/sites/chua-sung-phuc-27.jpg	anh	\N	Ảnh trong nhà — Tam quan	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.029171+00	2026-09-21 02:54:19.029171+00
c05b4db3-d870-4b82-9dac-0e837b4ba2c5	/uoc-le/sites/chua-sung-phuc-28.jpg	anh	\N	Kết cấu ảnh — tổng thể bộ vì	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.03208+00	2026-09-21 02:54:19.03208+00
717f8255-5b30-4464-b783-7b352ab6c6e2	/uoc-le/sites/chua-sung-phuc-29.jpg	anh	\N	Kết cấu ảnh — vì nóc	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.03421+00	2026-09-21 02:54:19.03421+00
e3f1f3a6-3aa0-4c02-a67b-37dde89740fe	/uoc-le/sites/chua-sung-phuc-30.jpg	anh	\N	Kết cấu ảnh — vì nách	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.037087+00	2026-09-21 02:54:19.037087+00
394ceca9-2752-4438-a235-7a67fdf28ae4	/uoc-le/sites/chua-sung-phuc-31.jpg	anh	\N	Kết cấu ảnh — đầu dư	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.039195+00	2026-09-21 02:54:19.039195+00
d0f20327-11d3-474e-8446-55f2714cd4ba	/uoc-le/sites/chua-sung-phuc-32.jpg	anh	\N	Chân tảng ảnh — chân tảng thượng điện	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.042127+00	2026-09-21 02:54:19.042127+00
8bec8725-b77e-496f-a803-831aba5bbd9c	/uoc-le/sites/chua-sung-phuc-33.png	anh	\N	Chân tảng ảnh — chân tảng thượng điện	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.045127+00	2026-09-21 02:54:19.045127+00
161f262d-258b-4f25-9d3a-eacd62114b57	/uoc-le/sites/chua-sung-phuc-34.png	anh	\N	Chân tảng hoa văn — Hoa văn chân tảng	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.047118+00	2026-09-21 02:54:19.047118+00
4a7c1338-14bc-4130-a1d9-6fd380dfd820	/uoc-le/sites/chua-sung-phuc-35.png	anh	\N	Chân tảng hoa văn — hoa văn chân tảng	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.049204+00	2026-09-21 02:54:19.049204+00
a8639654-cc66-46aa-ac9a-e0550c22ff08	/uoc-le/sites/chua-sung-phuc-36.png	anh	\N	Chân tảng hoa văn — Chân tảng gác chuông	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.052102+00	2026-09-21 02:54:19.052102+00
53ab9052-d037-4ee2-8693-bddca638db5f	/uoc-le/sites/khu-lang-nghe-gio-cha-1.jpg	anh	\N	Ảnh công nhận làng nghề	sites	20000000-0000-0000-0000-000000000006	2026-09-21 02:54:19.054209+00	2026-09-21 02:54:19.054209+00
ba9fb027-be4a-4ce3-b692-b710e6e5fd3b	/uoc-le/heritage-buildings/chua-so-44000000-1.jpg	anh	\N	Chụp thượng lương	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.602924+00	2026-09-21 02:54:19.602924+00
7624a228-05ff-4c86-8e21-8c2dbc14a6b6	/uoc-le/heritage-buildings/chua-so-44000000-2.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt đứng	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.606249+00	2026-09-21 02:54:19.606249+00
a8e488ee-b375-4c6e-a1f2-1de95718b3b7	/uoc-le/sites/dinh-lang-uoc-le-13.jpg	anh	\N	Ảnh trong nhà	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.951079+00	2026-09-21 08:08:41.780335+00
a31cbede-a1a6-4bcc-ba29-66f5b2b39a33	/uoc-le/heritage-buildings/chua-so-44000000-3.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt bên	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.609098+00	2026-09-21 02:54:19.609098+00
8ae831a4-edb0-4b87-88ae-96394287dfeb	/uoc-le/heritage-buildings/chua-so-44000000-4.jpg	anh	\N	Tam quan	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.611177+00	2026-09-21 02:54:19.611177+00
815f9460-b1cf-4339-8497-559c662c8f4b	/uoc-le/heritage-buildings/chua-so-44000000-5.jpg	anh	\N	Tả vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.613164+00	2026-09-21 02:54:19.613164+00
7e42c6f8-b140-4442-bcef-338fae6cc357	/uoc-le/heritage-buildings/chua-so-44000000-6.jpg	anh	\N	Hữu vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.615076+00	2026-09-21 02:54:19.615076+00
f6985770-c59a-42fc-9e27-85e56a2be027	/uoc-le/heritage-buildings/chua-so-44000000-7.jpg	anh	\N	Bia đá hữu vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.617049+00	2026-09-21 02:54:19.617049+00
ceffd758-7762-461c-9bfc-7a2cfcb7f78d	/uoc-le/heritage-buildings/chua-so-44000000-8.jpg	anh	\N	Bia đá tả vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.619181+00	2026-09-21 02:54:19.619181+00
03a41cf9-8300-4db4-bbdf-86c5d490f5da	/uoc-le/heritage-buildings/chua-so-44000000-9.jpg	anh	\N	Hậu đường — Gác chuông	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.621121+00	2026-09-21 02:54:19.621121+00
d9be2dbb-c80c-470f-bb06-af17687e88c3	/uoc-le/heritage-buildings/chua-so-44000000-10.jpg	anh	\N	Phía sau Hậu đường — Phía sau hậu đường	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.623107+00	2026-09-21 02:54:19.623107+00
9d651ee5-7db8-4e31-b593-a64b95aeb9df	/uoc-le/heritage-buildings/chua-so-44000000-11.jpg	panorama	\N	Ảnh360 — Ảnh 360	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.625044+00	2026-09-21 02:54:19.625044+00
fb308ccb-a95c-4cdf-b45f-4d818ba80260	/uoc-le/heritage-buildings/chua-so-44000000-12.jpg	anh	\N	Hình ảnh hiên — Hiên tiền đường	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.627174+00	2026-09-21 02:54:19.627174+00
d652b8cd-fe95-46d3-8a39-4e76c8bc67bb	/uoc-le/heritage-buildings/chua-so-44000000-13.jpg	anh	\N	Hiên tam quan	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.629119+00	2026-09-21 02:54:19.629119+00
97bb341e-7dcd-402a-b23c-8a7f3d8082b6	/uoc-le/heritage-buildings/chua-so-44000000-14.jpg	anh	\N	Hiên gác chuông	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.631077+00	2026-09-21 02:54:19.631077+00
62c04f32-c0fa-4cfd-9e4a-6f6e8a6aee9a	/api/uploads/villages/e6dd7b14-22c8-405e-8f77-1b8df075b036.jpg	anh	\N	\N	villages	00000000-0000-0000-0000-000000000001	2026-09-25 15:15:07.654908+00	2026-09-25 15:15:07.654908+00
d3793609-1d5f-4323-b198-53597c4fdddb	/uoc-le/heritage-buildings/chua-so-44000000-16.jpg	anh	\N	Nền hữu vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.635195+00	2026-09-21 02:54:19.635195+00
a3f550e9-075f-400f-8737-e8421d48e106	/uoc-le/heritage-buildings/chua-so-44000000-17.jpg	anh	\N	Nền gác chuông	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.637147+00	2026-09-21 02:54:19.637147+00
f3e2ec4a-699d-4313-8418-fba0503e25c9	/uoc-le/heritage-buildings/chua-so-44000000-18.jpg	anh	\N	Nền tả vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.639115+00	2026-09-21 02:54:19.639115+00
6e298df1-7bfe-48a6-8df3-4c38df281f7e	/uoc-le/heritage-buildings/chua-so-44000000-19.jpg	anh	\N	Nền thượng điện	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.641063+00	2026-09-21 02:54:19.641063+00
079de57a-646d-4255-8d26-fe840df5f917	/uoc-le/heritage-buildings/chua-so-44000000-20.jpg	anh	\N	Ảnh trong nhà — Thượng điện,	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.643212+00	2026-09-21 02:54:19.643212+00
f805a804-ee60-47a9-bbf1-35c584ed8891	/uoc-le/heritage-buildings/chua-so-44000000-21.jpg	anh	\N	Ảnh trong nhà — Tả vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.645138+00	2026-09-21 02:54:19.645138+00
2771cf87-65e4-43b6-b0c7-7f251441d7c8	/uoc-le/heritage-buildings/chua-so-44000000-22.jpg	anh	\N	Ảnh trong nhà — Hữu vu	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.647091+00	2026-09-21 02:54:19.647091+00
a4841fcf-1957-404b-8096-c9b4bce3829e	/uoc-le/heritage-buildings/chua-so-44000000-23.jpg	anh	\N	Ảnh trong nhà — Tam quan	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.649057+00	2026-09-21 02:54:19.649057+00
97bd5731-3f16-4a68-93f8-55ce93d4d546	/uoc-le/heritage-buildings/chua-so-44000000-24.jpg	anh	\N	Kết cấu ảnh — tổng thể bộ vì	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.651185+00	2026-09-21 02:54:19.651185+00
132e5421-af1a-4e73-9d18-9815bb1b0158	/uoc-le/heritage-buildings/chua-so-44000000-25.jpg	anh	\N	Kết cấu ảnh — vì nóc	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.653133+00	2026-09-21 02:54:19.653133+00
7754a4e4-b58f-4a92-9c0d-b307c580687e	/uoc-le/heritage-buildings/chua-so-44000000-26.jpg	anh	\N	Kết cấu ảnh — vì nách	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.655078+00	2026-09-21 02:54:19.655078+00
0f59531b-1f33-404c-b675-9eac623a4922	/uoc-le/heritage-buildings/chua-so-44000000-27.jpg	anh	\N	Kết cấu ảnh — đầu dư	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.657048+00	2026-09-21 02:54:19.657048+00
79fe2d1a-227a-4142-bd5c-fe02a65a600a	/uoc-le/heritage-buildings/chua-so-44000000-28.jpg	anh	\N	Chân tảng ảnh — chân tảng thượng điện	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.659167+00	2026-09-21 02:54:19.659167+00
cd8666d5-c4b8-45c4-88e3-d647888ee453	/uoc-le/heritage-buildings/chua-so-44000000-29.png	anh	\N	Chân tảng ảnh — chân tảng thượng điện	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.661124+00	2026-09-21 02:54:19.661124+00
434032af-ec53-4583-8976-5fa5721864be	/uoc-le/heritage-buildings/chua-so-44000000-30.png	anh	\N	Chân tảng hoa văn — Hoa văn chân tảng	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.663126+00	2026-09-21 02:54:19.663126+00
7797e7bc-b77e-4cd6-9bd9-a42215864b86	/uoc-le/heritage-buildings/chua-so-44000000-31.png	anh	\N	Chân tảng hoa văn — hoa văn chân tảng	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.665051+00	2026-09-21 02:54:19.665051+00
1b2e590b-2b96-4a30-ab9e-8dfdc6693c9e	/uoc-le/heritage-buildings/chua-so-44000000-32.png	anh	\N	Chân tảng hoa văn — Chân tảng gác chuông	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.667176+00	2026-09-21 02:54:19.667176+00
7e46e294-eaa2-424e-8a77-6f80ea834ae5	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — ảnh tổng thể từ nhà chính	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.669133+00	2026-09-21 02:54:19.669133+00
0d91e55a-edd3-40c5-ad5c-bcd9e8a0c339	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-2.pdf	ban_ve	\N	Tổng mặt bằng — TMB nhà bà Bào	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.671094+00	2026-09-21 02:54:19.671094+00
b1527ae0-93c6-4d98-8b1b-0023a76f231d	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-3.jpg	anh	\N	Chụp thượng lương	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.673056+00	2026-09-21 02:54:19.673056+00
b2816a19-b5ce-4659-a71c-8b65349316b1	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-4.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt đứng mặt bên công trình	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.675169+00	2026-09-21 02:54:19.675169+00
d9fa5a96-8b00-4b46-ae49-a7d977d733be	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-5.jpg	anh	\N	Ảnh các góc chính — Ảnh góc chính diện	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.677125+00	2026-09-21 02:54:19.677125+00
a994853a-f01a-4621-b85d-87c336454a86	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-6.jpg	panorama	\N	Ảnh các góc chính — Ảnh 360	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.679079+00	2026-09-21 02:54:19.679079+00
0755b2c5-60c1-473b-8ba5-cde7ea8ae8f9	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-7.jpg	anh	\N	Nền (ảnh chụp) — nền	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.68104+00	2026-09-21 02:54:19.68104+00
1bd99f63-af30-4ce0-a9a0-bcde707d7d6d	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-8.pdf	ban_ve	\N	Sơ đồ mặt bằng — sơ đồ mặt bằng	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.683182+00	2026-09-21 02:54:19.683182+00
8cb96e97-3073-4d2d-99bb-92169274f8ba	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-9.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.685118+00	2026-09-21 02:54:19.685118+00
dc2761cb-f372-4318-af6b-438a13032586	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-10.jpg	anh	\N	Ảnh trong nhà — gian1	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.687068+00	2026-09-21 02:54:19.687068+00
7b8a35b2-2978-4b6a-a85f-e5a0fb8ebe30	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-11.jpg	anh	\N	Ảnh trong nhà — gian2	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.689032+00	2026-09-21 02:54:19.689032+00
f2c54c9f-020b-412a-bc9e-aab0d53751e8	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-12.jpg	anh	\N	Ảnh trong nhà — gian3	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.691169+00	2026-09-21 02:54:19.691169+00
b82ff601-8967-4e99-ba75-ddc433ba9061	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-13.jpg	anh	\N	Ảnh trong nhà — gian4	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.693135+00	2026-09-21 02:54:19.693135+00
7bbad969-eb25-4611-b819-81e1a8c1782d	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-14.jpg	anh	\N	Kết cấu ảnh — kết cấu gian1	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.695074+00	2026-09-21 02:54:19.695074+00
ade0a2ed-e159-493e-b9d1-7f32411821a5	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-15.jpg	anh	\N	Kết cấu ảnh — kết cấu gian2	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.697036+00	2026-09-21 02:54:19.697036+00
9d043231-cf4c-463a-9373-824c0c8fd4f6	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-16.jpg	anh	\N	Kết cấu ảnh — kết cấu gian4	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.699171+00	2026-09-21 02:54:19.699171+00
a71005a8-1865-4e07-b99a-2866f1568b14	/uoc-le/heritage-buildings/nha-ba-bao-4-44000000-17.jpg	anh	\N	Chân tảng ảnh — Chân tảng	heritage_buildings	44000000-0000-0000-0000-000000000004	2026-09-21 02:54:19.701118+00	2026-09-21 02:54:19.701118+00
1075bd17-4294-4b28-a243-6ba4d37c4c0e	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-2.pdf	ban_ve	\N	Tổng mặt bằng — TMB cụ Khả	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.703098+00	2026-09-21 02:54:19.703098+00
09485930-029c-46fe-a87e-f3431eae8b90	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-3.jpg	anh	\N	Chụp thượng lương	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.70504+00	2026-09-21 02:54:19.70504+00
50d620c5-17da-40c2-a64f-d9eeaccf16d9	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-4.jpg	anh	\N	Mặt đứng, mặt bên công trình — mặt đứng	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.707171+00	2026-09-21 02:54:19.707171+00
2b971c4b-2e4d-4467-93fb-c5e5c2f50d4f	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-5.jpg	anh	\N	Ảnh các góc chính — ảnh chính diện các góc	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.709116+00	2026-09-21 02:54:19.709116+00
3e751e8e-b158-4870-ad51-9429b87c02d1	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-6.jpg	anh	\N	Ảnh các góc chính — ảnh góc phải	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.71108+00	2026-09-21 02:54:19.71108+00
bd6dff8a-57a4-4a6d-a1c6-0246907e2577	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-7.jpg	anh	\N	Ảnh các góc chính — ảnh góc trái	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.713046+00	2026-09-21 02:54:19.713046+00
1899b527-6a24-4283-a0bb-c42c8c236073	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-8.jpg	anh	\N	Ảnh các góc chính — ảnh nhìn từ nhà ra sân	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.71517+00	2026-09-21 02:54:19.71517+00
1d786d12-aa76-448f-8249-aaa9ed2a5c0a	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-9.jpg	panorama	\N	Ảnh các góc chính — ảnh 360	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.717121+00	2026-09-21 02:54:19.717121+00
adcaca4a-cd98-442f-b8c8-90e9c732b346	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — cột trang trí	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.719079+00	2026-09-21 02:54:19.719079+00
481e9ead-147d-4546-be60-ec5175c9cf37	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-12.jpg	anh	\N	Hình ảnh hiên — Ảnh hiên	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.723194+00	2026-09-21 02:54:19.723194+00
967d3570-6ed3-45ab-8afc-b2fcfbf64b7a	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-13.jpg	anh	\N	Nền (ảnh chụp) — Ảnh nền	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.725127+00	2026-09-21 02:54:19.725127+00
af27178d-0e07-48fe-a44e-1c8de85113bd	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-14.pdf	ban_ve	\N	Sơ đồ mặt bằng — sơ đồ mặt bằng	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.727085+00	2026-09-21 02:54:19.727085+00
65dc009d-fa11-4f44-b579-3b65f25c7dbb	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-15.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.729054+00	2026-09-21 02:54:19.729054+00
0a5b8bb4-9853-4540-9a77-cc4c8e38e299	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-16.jpg	anh	\N	Ảnh trong nhà — ảnh gian2	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.731176+00	2026-09-21 02:54:19.731176+00
fb37e88d-523c-407b-94a5-a06cd1fd423e	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-17.jpg	anh	\N	Ảnh trong nhà — ảnh gian3	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.733132+00	2026-09-21 02:54:19.733132+00
27a033e1-8788-46bf-b741-0d3f422b41a5	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-18.jpg	anh	\N	Ảnh trong nhà — ảnh gian4	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.735082+00	2026-09-21 02:54:19.735082+00
9896630c-4053-48de-a7e9-fa1842260571	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-19.jpg	anh	\N	Ảnh trong nhà — ảnh gian5	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.737062+00	2026-09-21 02:54:19.737062+00
5702420b-a72c-4eb1-8633-c0c7cacb0b48	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-20.jpg	anh	\N	Kết cấu ảnh — Kết cấu	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.73922+00	2026-09-21 02:54:19.73922+00
4548ddd5-b8e0-4d82-98d9-21c4741bb6c3	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-21.jpg	anh	\N	Kết cấu ảnh — Kết cấu	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.741129+00	2026-09-21 02:54:19.741129+00
4f76fdbe-1101-4f8c-a2be-4bb8e474faa2	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-22.jpg	anh	\N	Kết cấu ảnh — Kết cấu	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.743123+00	2026-09-21 02:54:19.743123+00
910b7f30-514c-46fb-b548-91c511b74bfd	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-23.jpg	anh	\N	Kết cấu ảnh — kết cấu	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.745064+00	2026-09-21 02:54:19.745064+00
b4c157f6-25b7-4ebf-892e-2bb1cf1d5177	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-24.jpg	anh	\N	Chân tảng ảnh — ảnh chân tảng	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.747199+00	2026-09-21 02:54:19.747199+00
b3956ef7-987d-4170-afa5-b62cbb428e21	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-25.png	anh	\N	Chân tảng hoa văn — ảnh cận	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.750076+00	2026-09-21 02:54:19.750076+00
e72baf69-dea9-4213-b4b0-63c4e2fb6f64	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-1.jpg	anh	\N	Xếp hạng di tích gì — ảnh công nhận di tích	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.752194+00	2026-09-21 02:54:19.752194+00
d4d2dc68-cd53-4dfa-9a9b-b42a1ec3fbb8	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-4.jpg	anh	\N	Chụp thượng lương	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.754136+00	2026-09-21 02:54:19.754136+00
fe4f1bc3-3458-4cba-bf1e-6d7e3f2080f6	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-5.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt bên công trình	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.756093+00	2026-09-21 02:54:19.756093+00
219b1421-dc67-4589-befb-d77510edc090	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-6.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt đứng công trình	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.758056+00	2026-09-21 02:54:19.758056+00
83275051-aa3f-41d9-927b-42a4ff7b82c9	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-7.jpg	panorama	\N	Ảnh các góc chính — Ảnh 360 từ cạnh bên	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.760201+00	2026-09-21 02:54:19.760201+00
89409ab2-5af8-4e1f-a6b1-ba06f2b6db7d	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-8.jpg	panorama	\N	Ảnh các góc chính — Ảnh 360 mặt trước	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.76214+00	2026-09-21 02:54:19.76214+00
935f28ab-cb5d-4dff-b600-e60979d549c1	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-9.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.764092+00	2026-09-21 02:54:19.764092+00
1a2b3c55-ffd7-4eae-9e8f-292830f9d87b	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-10.jpg	anh	\N	Mái_cấu tạo — Mái	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.766074+00	2026-09-21 02:54:19.766074+00
1dc166e3-5ba4-425f-af89-3d2cad3e8eca	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-11.jpg	anh	\N	Hình ảnh hiên — ẢNh hiên	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.768174+00	2026-09-21 02:54:19.768174+00
8cd32777-9905-49ba-9e4f-81c0cced648e	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-12.jpg	anh	\N	Ảnh trong nhà	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.770125+00	2026-09-21 02:54:19.770125+00
694a162b-c2ea-43f6-99e6-4a5a7df5d179	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-13.jpg	anh	\N	Kết cấu ảnh — Tổng thể bộ vì	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.772101+00	2026-09-21 02:54:19.772101+00
6bc9d17f-53a1-4285-913b-f8e061693722	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-14.jpg	anh	\N	Kết cấu ảnh — vì nóc	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.774062+00	2026-09-21 02:54:19.774062+00
f356ee02-01cf-4eef-a84d-1e9f4520a0d3	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-15.jpg	anh	\N	Kết cấu ảnh — vì nách	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.776204+00	2026-09-21 02:54:19.776204+00
4c2fffc5-ebd5-42c8-8c15-b48f9579e4f2	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-16.jpg	anh	\N	Chân tảng ảnh — chân tảng	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.779069+00	2026-09-21 02:54:19.779069+00
07aa3684-006f-4a3d-bb78-dff751bbee97	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-17.jpg	anh	\N	Chân tảng hoa văn — hoa văn chân tảng	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.781181+00	2026-09-21 02:54:19.781181+00
34d93ab5-76fa-4825-824a-ade4ca7ce023	/uoc-le/heritage-buildings/dinh-lang-uoc-le-44000000-18.jpg	anh	\N	Chân tảng hoa văn — hoa văn chân tảng	heritage_buildings	44000000-0000-0000-0000-000000000001	2026-09-21 02:54:19.783153+00	2026-09-21 02:54:19.783153+00
262c9215-cc46-4ac6-9201-1874ce1f195f	/ha-thai/sites/ao-e689ba8b-1.jpg	anh	\N	\N	sites	e689ba8b-cf6e-4826-a469-dfc732526f3b	2026-09-21 02:54:20.277715+00	2026-09-21 02:54:20.277715+00
6b745826-fcad-476b-b4be-14a7dc65ea55	/ha-thai/sites/chua-duyen-truong-6e5fc28f-1.jpg	anh	\N	\N	sites	6e5fc28f-9e4f-4290-8801-e97581ef232f	2026-09-21 02:54:20.281091+00	2026-09-21 02:54:20.281091+00
ea96239d-b238-4bb5-95c8-841ef0617ece	/ha-thai/sites/chua-phuc-thai-f8687aff-1.jpg	anh	\N	\N	sites	f8687aff-58a8-4df9-bdb1-7fa8db6417d1	2026-09-21 02:54:20.283211+00	2026-09-21 02:54:20.283211+00
0ce8f1c8-2771-45ae-968b-46011d0b2db4	/ha-thai/sites/cay-co-thu-c28846f5-1.jpg	anh	\N	\N	sites	c28846f5-ea72-460b-aa45-d9c3d3bb15a6	2026-09-21 02:54:20.285139+00	2026-09-21 02:54:20.285139+00
61f18571-1927-44be-853a-1219cc51cd6d	/ha-thai/sites/cong-lang-72157e2d-1.jpg	anh	\N	\N	sites	72157e2d-8d22-4022-b4be-18e3b63f3e4f	2026-09-21 02:54:20.288065+00	2026-09-21 02:54:20.288065+00
d4c826dd-3d14-4a7e-b55a-3dc813678dab	/ha-thai/sites/cong-xom-chu-my-4b9b87fb-1.jpg	anh	\N	\N	sites	4b9b87fb-0c41-43b4-81a5-38678458a9db	2026-09-21 02:54:20.290215+00	2026-09-21 02:54:20.290215+00
f61a2137-8f23-4c95-b6e2-d0ff46885dff	/ha-thai/sites/cong-xom-my-loc-6940e1f3-1.jpg	anh	\N	\N	sites	6940e1f3-7220-4ad7-b51e-98b86692df7c	2026-09-21 02:54:20.292146+00	2026-09-21 02:54:20.292146+00
1690a67a-0dc8-41f6-849d-3cbd1393ea06	/ha-thai/sites/cong-dinh-c2b27d51-1.jpg	anh	\N	\N	sites	c2b27d51-0c70-452a-b018-45cf6d7e9c56	2026-09-21 02:54:20.294102+00	2026-09-21 02:54:20.294102+00
def1e6a8-a209-44ff-bb7d-76087784a6f3	/ha-thai/sites/gieng-mieu-nghe-7ca23109-1.jpg	anh	\N	\N	sites	7ca23109-cf2c-4020-97da-ba3c67033918	2026-09-21 02:54:20.296081+00	2026-09-21 02:54:20.296081+00
34aca392-9c7b-4801-a445-9f363be35a8d	/ha-thai/sites/gieng-mieu-trinh-a2c635e8-1.jpg	anh	\N	\N	sites	a2c635e8-d3df-455e-bd55-f9aaa9e75507	2026-09-21 02:54:20.29804+00	2026-09-21 02:54:20.29804+00
992068a5-554f-4066-a9d9-5436bb984fde	/ha-thai/sites/gieng-dinh-ha-thai-9c831ce5-1.jpg	anh	\N	\N	sites	9c831ce5-2e1e-4468-b09c-27ee3a032d5a	2026-09-21 02:54:20.300184+00	2026-09-21 02:54:20.300184+00
a0383b4a-1dcf-4bea-bd13-00bad51a4a90	/ha-thai/sites/kenh-muong-thuy-loi-5d6055d9-1.jpg	anh	\N	\N	sites	5d6055d9-7ed7-4889-baf6-60b590360815	2026-09-21 02:54:20.302131+00	2026-09-21 02:54:20.302131+00
d716fedd-81ac-4975-93e4-e1fc6a8a258f	/ha-thai/sites/mieu-3b890288-1.jpg	anh	\N	\N	sites	3b890288-8a15-4484-a53f-444775d8fd20	2026-09-21 02:54:20.304092+00	2026-09-21 02:54:20.304092+00
3785f9a9-cd3d-44a6-a248-4175442e51f5	/ha-thai/sites/mieu-nghe-0d0db01e-1.jpg	anh	\N	\N	sites	0d0db01e-2bbf-4d28-a289-c9c2bdc9a3c7	2026-09-21 02:54:20.306068+00	2026-09-21 02:54:20.306068+00
ea6dc5d0-8601-40b5-ac9a-3aee5b66605e	/ha-thai/sites/mieu-trinh-60217152-1.jpg	anh	\N	\N	sites	60217152-a88b-4f05-8ee9-593985d9fb23	2026-09-21 02:54:20.308185+00	2026-09-21 02:54:20.308185+00
3779a55e-746f-4ef5-b475-25d38eda93c0	/ha-thai/sites/nha-co-ba-dip-cb162594-1.jpg	anh	\N	\N	sites	cb162594-8acc-419f-8e48-2ccf168f6288	2026-09-21 02:54:20.31017+00	2026-09-21 02:54:20.31017+00
20a3f59d-6a00-447d-af52-abb96e8dec13	/ha-thai/sites/nha-tho-ho-c7ed2238-1.jpg	anh	\N	\N	sites	c7ed2238-2c52-42ce-af48-c0dd241e6ef3	2026-09-21 02:54:20.312107+00	2026-09-21 02:54:20.312107+00
5f0d6299-5902-4943-a95e-3b61778c8cc4	/ha-thai/sites/quan-nuoc-b008170d-1.jpg	anh	\N	\N	sites	b008170d-a82b-4604-9220-5cc6f0f9e2a7	2026-09-21 02:54:20.314066+00	2026-09-21 02:54:20.314066+00
e1cbd163-b746-4aa9-90ad-8ebb5a16f4b6	/ha-thai/sites/song-to-lich-743a1c86-1.jpg	anh	\N	\N	sites	743a1c86-b0f5-4d4b-a6d8-ed2fe6444edc	2026-09-21 02:54:20.316053+00	2026-09-21 02:54:20.316053+00
e3737f63-a8e2-4779-9c54-3f65c4959c75	/ha-thai/sites/van-chi-4182fd39-1.jpg	anh	\N	\N	sites	4182fd39-6d5e-4a40-b050-4f141bc860a4	2026-09-21 02:54:20.318172+00	2026-09-21 02:54:20.318172+00
1b9c9a9e-97f4-4e42-b816-85c40412a28c	/ha-thai/sites/dinh-khong-gian-mo-ao-song-dong-ruong-cay-da-de-si-2edf0cc8-1.jpg	anh	\N	\N	sites	2edf0cc8-fdba-44ff-b83c-5aea246a11b9	2026-09-21 02:54:20.320138+00	2026-09-21 02:54:20.320138+00
86b37b71-bca1-426e-b33c-ea2e00bd7895	/ha-thai/sites/dinh-lang-d813ed0d-1.jpg	anh	\N	\N	sites	d813ed0d-366c-4aff-b7b0-033dad2906d4	2026-09-21 02:54:20.322093+00	2026-09-21 02:54:20.322093+00
3f75ada5-555a-459b-a039-ac3136240c67	/ha-thai/sites/duong-chinh-van-tho-297a57a6-1.jpg	anh	\N	\N	sites	297a57a6-4bcc-40fd-8b3b-761f984ff0fd	2026-09-21 02:54:20.324062+00	2026-09-21 02:54:20.324062+00
72aed6c4-fcd3-4b88-b18f-a21a436ccf05	/ha-thai/sites/duong-chinh-duong-thai-binh-f27421bb-1.jpg	anh	\N	\N	sites	f27421bb-5b83-4c77-acdc-7d3c68f220af	2026-09-21 02:54:20.326197+00	2026-09-21 02:54:20.326197+00
adf2d286-d5c4-4c55-9426-6f4744c30236	/ha-thai/sites/duong-chinh-duong-trang-ha-50cc1810-1.jpg	anh	\N	\N	sites	50cc1810-1a41-4d00-9bf6-d12465585123	2026-09-21 02:54:20.328144+00	2026-09-21 02:54:20.328144+00
a6a5b60c-12a8-471d-9939-8f73a88303fc	/ha-thai/sites/duong-nhanh-ngo-0556a156-1.jpg	anh	\N	\N	sites	0556a156-a3e3-4d29-8885-91ac17dcecb9	2026-09-21 02:54:20.330114+00	2026-09-21 02:54:20.330114+00
a9b67580-c446-4001-b0db-d73fa3688c54	/ha-thai/sites/duong-nhanh-ngo-0556a156-2.jpg	anh	\N	\N	sites	0556a156-a3e3-4d29-8885-91ac17dcecb9	2026-09-21 02:54:20.332076+00	2026-09-21 02:54:20.332076+00
e9233a23-19c8-4e1a-82ce-b864032ee292	/ha-thai/sites/duong-nhanh-ngo-0556a156-3.jpg	anh	\N	\N	sites	0556a156-a3e3-4d29-8885-91ac17dcecb9	2026-09-21 02:54:20.334047+00	2026-09-21 02:54:20.334047+00
c17c1e43-b44b-4918-8c7d-6bdfc69b0c2e	/ha-thai/sites/duong-nhanh-ngo-0556a156-4.jpg	anh	\N	\N	sites	0556a156-a3e3-4d29-8885-91ac17dcecb9	2026-09-21 02:54:20.336206+00	2026-09-21 02:54:20.336206+00
8fdc0643-2748-41ad-b5e9-53f80851b331	/ha-thai/sites/duong-nhanh-ngo-0556a156-5.jpg	anh	\N	\N	sites	0556a156-a3e3-4d29-8885-91ac17dcecb9	2026-09-21 02:54:20.338131+00	2026-09-21 02:54:20.338131+00
c865111f-b79b-47c9-9dc7-594d510151e0	/ha-thai/sites/duong-nhanh-ngo-0556a156-6.jpg	anh	\N	\N	sites	0556a156-a3e3-4d29-8885-91ac17dcecb9	2026-09-21 02:54:20.340096+00	2026-09-21 02:54:20.340096+00
a67f6532-b995-49fc-80f0-a66839742da5	/lang-cuu/sites/chua-2d807452-1.jpg	anh	\N	\N	sites	2d807452-23ae-46f0-9d24-753bea18f1f1	2026-09-21 02:54:20.451759+00	2026-09-21 02:54:20.451759+00
03a0d2b3-7628-42c8-8307-c8615744fdb1	/lang-cuu/sites/cay-co-thu-giua-lang-0b8904ea-1.jpg	anh	\N	\N	sites	0b8904ea-3cca-4609-9d61-fdeb8c753881	2026-09-21 02:54:20.45816+00	2026-09-21 02:54:20.45816+00
269fbf49-6a9b-45f0-a0c9-8dce7ee0f658	/lang-cuu/sites/cay-co-thu-dau-lang-2c84ff41-1.jpg	anh	\N	\N	sites	2c84ff41-5bbe-4314-b600-a89f0735e9d0	2026-09-21 02:54:20.460092+00	2026-09-21 02:54:20.460092+00
ec76f089-54fe-4c6f-8729-d46ff4826859	/lang-cuu/sites/cong-lang-889cf51e-1.jpg	anh	\N	\N	sites	889cf51e-4283-401e-bef4-78bef4e0f992	2026-09-21 02:54:20.462277+00	2026-09-21 02:54:20.462277+00
71d61460-8d41-4597-83dd-a6d57ee2c834	/lang-cuu/sites/nha-tay-78ba5481-1.jpg	anh	\N	\N	sites	78ba5481-fe5f-41a4-b64c-ca81e771ce53	2026-09-21 02:54:20.465175+00	2026-09-21 02:54:20.465175+00
d899e960-389d-4472-a9b1-922ee984db1b	/lang-cuu/sites/nha-co-bac-tu-6e4bdb96-1.jpg	anh	\N	\N	sites	6e4bdb96-4631-4af9-80d2-ff2a3f29bf8c	2026-09-21 02:54:20.46714+00	2026-09-21 02:54:20.46714+00
0cefd584-c02c-432c-a4fe-76884a397ccc	/lang-cuu/sites/nha-tho-ho-1cc62aa3-1.jpg	anh	\N	\N	sites	1cc62aa3-f869-4470-92fe-2a4d62c366a8	2026-09-21 02:54:20.469128+00	2026-09-21 02:54:20.469128+00
20ef360d-5048-4662-94a5-cffb58cbacd7	/lang-cuu/sites/ao-66cf0b99-1.jpg	anh	\N	\N	sites	66cf0b99-c24b-447c-b3f4-7d2d2a506cb7	2026-09-21 02:54:20.471116+00	2026-09-21 02:54:20.471116+00
2b8f688c-dea2-4876-94b7-132e89f3e5a3	/lang-cuu/sites/gieng-010f644d-1.png	anh	\N	\N	sites	010f644d-0f9d-4977-b357-138f306501e2	2026-09-21 02:54:20.473108+00	2026-09-21 02:54:20.473108+00
a7f493a7-e3b5-4ef3-8cbe-c8cdeb131034	/lang-cuu/sites/dinh-khong-gian-mo-ao-song-dong-ruong-cay-da-de-si-03111ee1-1.jpg	anh	\N	\N	sites	03111ee1-5fca-41d0-888e-9bb7f58a31b2	2026-09-21 02:54:20.475097+00	2026-09-21 02:54:20.475097+00
ea3bae9b-e217-4b55-add3-166056567e72	/lang-cuu/sites/dinh-lang-53fa7c45-1.jpg	anh	\N	\N	sites	53fa7c45-dac2-49cc-a4c1-11f6a7db5c24	2026-09-21 02:54:20.477254+00	2026-09-21 02:54:20.477254+00
9fd27d6d-2756-4269-9cbb-e17ca3473cd0	/lang-cuu/sites/duong-chinh-4c9de4f0-1.jpg	anh	\N	\N	sites	4c9de4f0-3b78-4ad2-b856-a6b635f3514b	2026-09-21 02:54:20.480149+00	2026-09-21 02:54:20.480149+00
db0525b9-a1d8-48bc-86e7-6626a62dd105	/lang-cuu/sites/duong-gach-7d904c2e-1.jpg	anh	\N	\N	sites	7d904c2e-ee19-480f-a93a-62c2f2810b6a	2026-09-21 02:54:20.482094+00	2026-09-21 02:54:20.482094+00
86b9092e-0d1d-4190-a79d-ee32fa175ee9	/lang-cuu/sites/duong-nhanh-ngo-b22e7458-1.jpg	anh	\N	\N	sites	b22e7458-33f4-46d7-a833-fa949d15fed0	2026-09-21 02:54:20.484054+00	2026-09-21 02:54:20.484054+00
229f8640-291a-4335-aa99-218c5cce3a00	/lang-cuu/sites/duong-nua-da-nua-gach-aca31262-1.jpg	anh	\N	\N	sites	aca31262-bb0a-47ee-8543-b7b8003ead58	2026-09-21 02:54:20.486183+00	2026-09-21 02:54:20.486183+00
f38b80ce-065b-4e82-95b6-4b1953786d21	/lang-cuu/sites/duong-da-9b2adb32-1.jpg	anh	\N	\N	sites	9b2adb32-b607-419d-a5c3-69894a2d5c66	2026-09-21 02:54:20.488144+00	2026-09-21 02:54:20.488144+00
1e748c5f-e8ea-4a62-bc1e-0c48a73aeb27	/lang-chuong/sites/cho-5e1d7cfb-1.jpg	anh	\N	\N	sites	5e1d7cfb-ad82-4bc9-99ab-dee66e8f0911	2026-09-21 02:54:20.608278+00	2026-09-21 02:54:20.608278+00
c8d93c56-1c23-4c10-a631-d588f40108d4	/lang-chuong/sites/cong-lang-bffd491e-1.jpg	anh	\N	\N	sites	bffd491e-5b22-49d1-b77b-377edd25664a	2026-09-21 02:54:20.613123+00	2026-09-21 02:54:20.613123+00
1f7b9db3-50b4-41b4-8617-5b53f7bcba73	/lang-chuong/sites/gieng-san-mieu-ban-tho-9ec04fb9-1.jpg	anh	\N	\N	sites	9ec04fb9-9aef-4c12-9f47-bfc19872c0b2	2026-09-21 02:54:20.615096+00	2026-09-21 02:54:20.615096+00
634d87dc-ac9f-4927-a015-d6246fedbf35	/lang-chuong/sites/gieng-chua-chuong-fafa82e9-1.jpg	anh	\N	\N	sites	fafa82e9-5d72-42aa-a059-1cdcce1ba4ea	2026-09-21 02:54:20.617102+00	2026-09-21 02:54:20.617102+00
d2b35ee0-8d60-4e0e-a09f-c716becbdc2e	/lang-chuong/sites/gieng-den-ong-de1a0d7d-1.jpg	anh	\N	\N	sites	de1a0d7d-37f8-4134-b172-1a739c3fa419	2026-09-21 02:54:20.621281+00	2026-09-21 02:54:20.621281+00
d50bdba5-0f4e-48ae-bd56-5f910abe054c	/lang-chuong/sites/luy-tre-67a60076-1.jpg	anh	\N	\N	sites	67a60076-5af3-4f6c-89d8-69e21342b36d	2026-09-21 02:54:20.624257+00	2026-09-21 02:54:20.624257+00
a1192cf2-e61d-44da-bfc2-45f0805381ab	/lang-chuong/sites/nha-co-5ebaa055-1.jpg	anh	\N	\N	sites	5ebaa055-99e0-4897-97c3-0170cbb6d381	2026-09-21 02:54:20.627138+00	2026-09-21 02:54:20.627138+00
3f338c54-0f5c-41ad-a8a4-5194337626b9	/lang-chuong/sites/nha-tho-78cb2d2e-1.jpg	anh	\N	\N	sites	78cb2d2e-69b3-42f3-8b28-5c5b9031961f	2026-09-21 02:54:20.6291+00	2026-09-21 02:54:20.6291+00
ce895417-c8e4-4dee-b152-d9eb0fc65c69	/lang-chuong/sites/song-d198a4db-1.jpg	anh	\N	\N	sites	d198a4db-d65d-4136-88d7-fe4692f03199	2026-09-21 02:54:20.633037+00	2026-09-21 02:54:20.633037+00
7dfaff17-7e72-4741-b443-1432363ec8ad	/lang-chuong/sites/van-chi-1c2471bb-1.jpg	anh	\N	\N	sites	1c2471bb-ae76-43fa-a3bf-97fdd76e5ce4	2026-09-21 02:54:20.635174+00	2026-09-21 02:54:20.635174+00
16e8ca41-23b3-4bd5-993b-030c112a4e59	/lang-chuong/sites/diem-ngoa-kieu-05777db9-1.jpg	anh	\N	\N	sites	05777db9-c92b-4da6-9f66-2833674f6ad5	2026-09-21 02:54:20.637131+00	2026-09-21 02:54:20.637131+00
c293eb2f-0f84-464d-a29d-1ae0d36cfab9	/lang-chuong/sites/dinh-khong-gian-mo-ao-song-dong-ruong-cay-da-de-si-15d48e54-1.jpg	anh	\N	\N	sites	15d48e54-3790-4900-9e87-df730349392f	2026-09-21 02:54:20.64106+00	2026-09-21 02:54:20.64106+00
f5860608-9c86-490f-a9bb-5e7d307ce66c	/lang-chuong/sites/dinh-lang-b052b7f7-1.jpg	anh	\N	\N	sites	b052b7f7-f771-4f18-8457-f4acc92c9b8d	2026-09-21 02:54:20.643191+00	2026-09-21 02:54:20.643191+00
e47c7239-1603-4f24-941d-786d4ee79c58	/lang-chuong/sites/dat-nong-nghiep-616bf014-1.jpg	anh	\N	\N	sites	616bf014-5516-44ce-80c3-7d52190f1da3	2026-09-21 02:54:20.651039+00	2026-09-21 02:54:20.651039+00
f00dc361-ab8f-4d6a-b253-71689346e8fd	/lang-chuong/sites/den-ong-ceb78e41-1.jpg	anh	\N	\N	sites	ceb78e41-82e6-4d87-8155-7ea70ec1a83e	2026-09-21 02:54:20.657087+00	2026-09-21 02:54:20.657087+00
67358cdb-545f-46c7-92a3-d2fddd14eef3	/phu-vinh/sites/gieng-c1ed694a-1.jpg	anh	\N	Hình ảnh giếng cổ	sites	c1ed694a-3a3d-4eab-bd63-18c619cd15be	2026-09-21 02:54:20.781105+00	2026-09-21 02:54:20.781105+00
210eb910-2ec4-46fa-bcb4-b8fba1ab6228	/phu-vinh/sites/nha-co-hoang-hanh-d3802314-1.jpg	anh	\N	Nhà ông Hoàng Hạnh	sites	d3802314-f819-40eb-9447-8d6f23b2a7b6	2026-09-21 02:54:20.783109+00	2026-09-21 02:54:20.783109+00
759452b0-acd1-4cfa-ba1a-52079677487b	/phu-vinh/sites/nha-co-nguyen-huu-ki-b7a1677b-1.jpg	anh	\N	Nhà ông Nguyễn Hữu Kí	sites	b7a1677b-f9ea-4a8d-9d1d-5c73ab4ba178	2026-09-21 02:54:20.78822+00	2026-09-21 02:54:20.78822+00
addb9cd5-c3dd-46ab-b851-d76864947c1f	/phu-vinh/sites/duong-nhanh-ngo-2fb52b97-1.jpg	anh	\N	Ảnh đường nhánh	sites	2fb52b97-503f-4f3f-8ed0-26595709db20	2026-09-21 02:54:20.797136+00	2026-09-21 02:54:20.797136+00
66fac027-8aa7-444d-a5cc-b881b610019a	/phu-vinh/sites/duong-theo-vat-lieu-6b618c65-1.jpg	anh	\N	Ảnh vật liệu	sites	6b618c65-7d7c-4287-accc-1845babb35cc	2026-09-21 02:54:20.799101+00	2026-09-21 02:54:20.799101+00
1822c41c-d4b5-4218-9457-511bc75f71f2	/cu-da/sites/chua-cu-da-21000000-3.jpg	anh	\N	Chùa Cự Đà	sites	21000000-0000-0000-0000-000000000009	2026-09-21 02:53:49.458445+00	2026-09-21 02:54:20.975172+00
5cf40a81-63e5-4284-933b-6572e13d64f3	/cu-da/sites/cot-co-21000000-1.jpg	anh	\N	Cột cờ	sites	21000000-0000-0000-0000-000000000006	2026-09-21 02:53:49.477455+00	2026-09-21 02:54:20.975172+00
25a5f282-0398-409d-8cb3-eca7c38bbb3c	/cu-da/sites/mieu-cu-da-21000000-1.jpg	anh	\N	Miếu	sites	21000000-0000-0000-0000-000000000007	2026-09-21 02:53:49.481562+00	2026-09-21 02:54:20.975172+00
f9c7156a-f2c7-440a-8848-b87c41c553f4	/cu-da/sites/dinh-lang-cu-da-21000000-1.jpg	anh	\N	Đình Vật	sites	21000000-0000-0000-0000-000000000004	2026-09-21 02:53:49.50244+00	2026-09-21 02:54:20.975172+00
7d76273a-9d01-4547-9c6b-e56cf24d0f26	/uoc-le/sites/diem-tuan-1.jpg	anh	\N	Ảnh điếm	sites	20000000-0000-0000-0000-000000000011	2026-09-21 02:54:18.887174+00	2026-09-21 02:54:20.975172+00
a4a8dec6-1cb3-4773-83a9-d4e78363abdc	/uoc-le/sites/cong-lang-uoc-le-2.jpg	anh	\N	Ảnh cổng mặt trong làng	sites	20000000-0000-0000-0000-000000000001	2026-09-21 02:54:18.892185+00	2026-09-21 02:54:20.975172+00
dcef4a11-b1a1-4594-a986-0bcc12fdd03e	/uoc-le/sites/cong-sau-lang-uoc-le-1.jpg	anh	\N	Ảnh cổng sau	sites	20000000-0000-0000-0000-000000000008	2026-09-21 02:54:18.895215+00	2026-09-21 02:54:20.975172+00
56ddf93d-ef63-4ecb-afa2-de94ab1ec154	/uoc-le/sites/dinh-lang-uoc-le-1.jpg	anh	\N	Đình làng ước lễ	sites	20000000-0000-0000-0000-000000000002	2026-09-21 02:54:18.898116+00	2026-09-21 02:54:20.975172+00
a9a973fe-725d-4eec-b818-22e86127d74b	/uoc-le/sites/chua-sung-phuc-1.jpg	anh	\N	Chùa Sổ	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.901127+00	2026-09-21 02:54:20.975172+00
9b8404b3-a7ca-4dd9-9391-1587f4ff914d	/uoc-le/sites/chua-hau-1.jpg	anh	\N	Chùa Hậu	sites	20000000-0000-0000-0000-000000000007	2026-09-21 02:54:18.905208+00	2026-09-21 02:54:20.975172+00
67c7c406-61ae-4d0e-b09f-7f560a3cf4b7	/uoc-le/sites/den-ngo-ho-1.jpg	anh	\N	Miếu nằm cạnh nhà thờ giáo họ	sites	20000000-0000-0000-0000-000000000013	2026-09-21 02:54:18.910242+00	2026-09-21 02:54:20.975172+00
b1014dbb-bfab-4afa-a8ec-27a3f04157ca	/uoc-le/sites/chua-sung-phuc-3.jpg	anh	\N	Giếng chùa sùng phúc mới	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:18.923114+00	2026-09-21 02:54:20.975172+00
c1623f5b-1ecc-483d-8a66-ce205a146a44	/lang-chuong/sites/chua-225152ae-1.jpg	panorama	\N	\N	sites	225152ae-cf96-485a-8fb4-5956bbd9bcff	2026-09-21 02:54:20.601303+00	2026-09-21 08:08:41.780335+00
66fed655-b83e-4ad1-abeb-7367e15922b9	/lang-chuong/sites/cho-chua-8322ba72-1.jpg	panorama	\N	\N	sites	8322ba72-4b66-4d0d-911b-61ea10332a97	2026-09-21 02:54:20.611124+00	2026-09-21 08:08:41.780335+00
44959b58-3307-4e48-8635-086b74b9378b	/lang-chuong/sites/nha-tho-ho-50800f73-1.jpg	panorama	\N	\N	sites	50800f73-2fe4-483f-8b4a-4177688cd00a	2026-09-21 02:54:20.631068+00	2026-09-21 08:08:41.780335+00
82f45ce3-22ee-47cb-a429-2ef5bc2e8663	/uoc-le/sites/nha-tho-giao-ho-2.jpg	anh	\N	Miếu thờ	sites	20000000-0000-0000-0000-000000000014	2026-09-21 02:54:18.92506+00	2026-09-21 02:54:20.975172+00
97407b5a-26ee-4100-adae-6c73299bdb20	/uoc-le/sites/chua-hau-2.jpg	anh	\N	Giếng chùa Hậu	sites	20000000-0000-0000-0000-000000000007	2026-09-21 02:54:18.927167+00	2026-09-21 02:54:20.975172+00
63398dfa-a01e-4b54-8837-bf44bcd0eb55	/uoc-le/sites/chua-sung-phuc-19.jpg	anh	\N	Hiên thượng điện — Hiên thượng điện	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.010097+00	2026-09-21 02:54:20.975172+00
0f90cdb2-f7c5-4c00-b575-0ef25a55762f	/uoc-le/heritage-buildings/chua-so-44000000-15.jpg	anh	\N	Hiên thượng điện — Hiên thượng điện	heritage_buildings	44000000-0000-0000-0000-000000000002	2026-09-21 02:54:19.633101+00	2026-09-21 02:54:20.975172+00
9f2d3c5d-aae2-4861-ace5-9942fbc36fbc	/phu-vinh/sites/nha-co-nguyen-huu-bat-5b519f6e-1.jpg	anh	\N	Nhà ông Nguyễn Hưu Bật	sites	5b519f6e-5d64-4d9b-9623-cb4e78f666cb	2026-09-21 02:54:20.785503+00	2026-09-21 02:54:20.975172+00
ba9a62a1-7c8d-4e76-b45f-fc4bccbd181b	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — Ảnh từ cổng chính	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.340312+00	2026-09-21 07:18:48.340312+00
8e8255a2-269a-4f3f-a640-614708bdf2fe	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-10.jpg	anh	\N	Mặt đứng, mặt bên công trình — Tháp chuông	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.346796+00	2026-09-21 07:18:48.346796+00
ce063bf0-488e-470d-80b9-9ce47df8c4dd	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-12.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.351672+00	2026-09-21 07:18:48.351672+00
e2718dc1-358b-475a-a6aa-bce8c8fa05af	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-13.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.353699+00	2026-09-21 07:18:48.353699+00
0f8d782d-c8e5-40c8-9bdb-792d704539b1	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-14.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.35593+00	2026-09-21 07:18:48.35593+00
21a4a7f7-f1d4-4a9b-afcb-2628435db56e	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-15.jpg	anh	\N	Mái_cấu tạo	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.358679+00	2026-09-21 07:18:48.358679+00
0a2bede9-b721-4f50-9c57-ddc120f94c11	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-16.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.360674+00	2026-09-21 07:18:48.360674+00
0d23d8a1-80b0-49e6-a3d9-d86455d60872	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-17.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.362692+00	2026-09-21 07:18:48.362692+00
531fc7dd-27da-4371-b0b3-f62650251d4d	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-18.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.364703+00	2026-09-21 07:18:48.364703+00
1fe991b3-e678-41e7-9eb7-bccb26f8927e	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-19.jpg	anh	\N	Nền (ảnh chụp)	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.366727+00	2026-09-21 07:18:48.366727+00
d83c7936-c83f-4c87-a0a2-b3ff5472dcd8	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-2.jpg	anh	\N	Tổng mặt bằng — TMB	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.368692+00	2026-09-21 07:18:48.368692+00
b102a1a5-4a0c-4733-9258-5ff6b28e0b0a	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-21.jpg	anh	\N	Gian 1	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.370645+00	2026-09-21 07:18:48.370645+00
d90b0d6a-fcf6-4865-9e98-5f2b3aa6b339	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-22.jpg	anh	\N	Gian 2	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.37276+00	2026-09-21 07:18:48.37276+00
0047b80a-5cc9-42d0-a9c3-6a4f9c3ed7f3	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-23.jpg	anh	\N	Gian 3	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.37572+00	2026-09-21 07:18:48.37572+00
4f9f8ae8-524a-4ddd-a3ea-ea2429fea15c	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-24.jpg	anh	\N	Gian 4	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.378712+00	2026-09-21 07:18:48.378712+00
52662fdf-0692-43ea-ab11-9f0fae845bf7	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-25.jpg	anh	\N	Gian 5	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.380657+00	2026-09-21 07:18:48.380657+00
15b36dcc-363b-46d4-93d3-8b799088a9c4	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-26.jpg	anh	\N	Kết cấu ảnh — Tổng thể bộ vì nóc	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.382783+00	2026-09-21 07:18:48.382783+00
aa1bc24c-6af6-481a-94b9-b95f2bd8c885	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-27.jpg	anh	\N	Kết cấu ảnh — Bộ vì nách	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.385671+00	2026-09-21 07:18:48.385671+00
50973af3-86f8-4c86-95df-559ae3823c65	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-28.jpg	anh	\N	Kết cấu ảnh — Bộ vì nách	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.387795+00	2026-09-21 07:18:48.387795+00
46566cd4-71e2-46d8-9d96-6161f8d57a6e	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-3.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — Bia vinh danh	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.39278+00	2026-09-21 07:18:48.39278+00
a6983239-7ce1-4b51-b509-18864e3069ef	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-4.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — Giếng quan âm	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.395662+00	2026-09-21 07:18:48.395662+00
64a3ca72-5552-4c06-afda-0a2dc2e2c260	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-5.jpg	anh	\N	Mặt đứng, mặt bên công trình — Tam bảo	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.397781+00	2026-09-21 07:18:48.397781+00
bc635b93-d837-429d-a747-dad686e21e94	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-6.jpg	anh	\N	Mặt đứng, mặt bên công trình — Đằng sau nhà tam bảo	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.400684+00	2026-09-21 07:18:48.400684+00
9584444c-56b1-442a-8a3a-d8e87e36eab0	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-7.jpg	anh	\N	Mặt đứng, mặt bên công trình — Gian thờ địa tạng	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.40279+00	2026-09-21 07:18:48.40279+00
9403fc08-7e5a-447d-af69-498d7e11501e	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-8.jpg	anh	\N	Mặt đứng, mặt bên công trình — Nhà học đường	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.405681+00	2026-09-21 07:18:48.405681+00
4e32c556-da27-4757-a981-3cb30d0960dc	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-9.jpg	anh	\N	Mặt đứng, mặt bên công trình — Tam quan	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.407793+00	2026-09-21 07:18:48.407793+00
9d377a26-ed42-4f6e-93c7-2aaa9a1e4344	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-1.pdf	ban_ve	\N	Tổng mặt bằng	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.410658+00	2026-09-21 07:18:48.410658+00
258c4f49-a9d3-473a-a862-c65e2640f446	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-12.jpg	anh	\N	Kết cấu ảnh — ảnh vì kèo	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.412779+00	2026-09-21 07:18:48.412779+00
ee052c62-dbbd-4bcb-a97e-c73598c93fe1	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-13.jpg	anh	\N	Kết cấu ảnh — ảnh vì kèo	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.415689+00	2026-09-21 07:18:48.415689+00
74b2e088-2178-46eb-9301-edb654926bbe	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-14.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.417795+00	2026-09-21 07:18:48.417795+00
d84ff1ed-80c5-4b21-b607-4f0fc25f7837	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-15.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.420647+00	2026-09-21 07:18:48.420647+00
4fb5a9b5-3760-4c29-9b7a-6142fc416ba4	/cu-da/sites/duong-nhanh-ngo-21000000-1.jpg	panorama	\N	Đường nhánh ngõ Quang Trung II	sites	21000000-0000-0000-0000-000000000002	2026-09-21 02:53:49.508466+00	2026-09-21 08:08:41.780335+00
af99458c-1fbc-4d1a-932e-f0e6903bd73b	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-16.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.422756+00	2026-09-21 07:18:48.422756+00
876580fb-fd94-49c5-aa3a-ac918eec2bcf	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-17.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.425635+00	2026-09-21 07:18:48.425635+00
6afc7ed0-e7cf-417f-b2b1-da7463ee840f	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-18.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.427741+00	2026-09-21 07:18:48.427741+00
9ade39b9-b4f9-4aa8-96a7-54aa4160a6fd	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-19.jpg	anh	\N	Chân tảng ảnh — chân tảng nhà chính	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.429698+00	2026-09-21 07:18:48.429698+00
1a442576-a1e2-46cb-afc6-f3fe969f9c27	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-2.jpg	anh	\N	Mặt đứng, mặt bên công trình	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.43167+00	2026-09-21 07:18:48.43167+00
de01a160-47ca-4bc5-9bf9-1ea64894085a	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-20.jpg	anh	\N	Chân tảng ảnh — chân tảng nhà phụ	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.433612+00	2026-09-21 07:18:48.433612+00
788bab4e-1fca-4e05-a1de-8759c9f18b6c	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-3.jpg	anh	\N	Mái_cấu tạo	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.435742+00	2026-09-21 07:18:48.435742+00
3ec73441-b951-42bd-ab5c-dfc6fb079ddc	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-4.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.437676+00	2026-09-21 07:18:48.437676+00
8d9201ae-94a9-4f58-b36d-96dfa9539c2d	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-5.jpg	anh	\N	Hình ảnh hiên — ảnh hiên nhà phụ	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.439634+00	2026-09-21 07:18:48.439634+00
b5503b26-f344-44bf-941e-cd4836e1bb0e	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-6.jpg	anh	\N	Nền (ảnh chụp) — nền sân	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.441595+00	2026-09-21 07:18:48.441595+00
678e1dcd-fac3-43f2-8a80-668e987fa297	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-7.jpg	anh	\N	Nền (ảnh chụp) — nền hiên	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.44374+00	2026-09-21 07:18:48.44374+00
d6c5651e-b532-4241-8681-daa2fcda5ae3	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-8.pdf	ban_ve	\N	Sơ đồ mặt bằng	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.445709+00	2026-09-21 07:18:48.445709+00
51397ee9-d435-48e4-af87-da38de002450	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-9.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — Sơ đồ mặt cắt	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.447668+00	2026-09-21 07:18:48.447668+00
96a2b737-b44e-4e58-8baf-3d468aa66b83	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — Không gian từ cổng chính	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.449622+00	2026-09-21 07:18:48.449622+00
3208500c-e929-49c7-a6c7-fa37699b2857	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.45175+00	2026-09-21 07:18:48.45175+00
f95589ad-b523-41c2-b52a-8bc40b791cac	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-11.jpg	anh	\N	Mái_cấu tạo — mái	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.454655+00	2026-09-21 07:18:48.454655+00
78341b42-c573-4e19-81d2-d583e5b847f6	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-12.jpg	anh	\N	Vị trí hiên — Hiên	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.456602+00	2026-09-21 07:18:48.456602+00
4b366dc5-2825-4f3f-b68c-9f5f11fcd5f4	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-13.jpg	anh	\N	Vị trí hiên — Hiên	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.458762+00	2026-09-21 07:18:48.458762+00
94dcaf3c-7a49-478e-bfea-d0067fda1aaa	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-14.jpg	anh	\N	Nền (ảnh chụp) — Ảnh nền	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.461633+00	2026-09-21 07:18:48.461633+00
11b79f96-e6f8-4be3-88b5-9f3d4a2efe41	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-15.pdf	ban_ve	\N	Sơ đồ mặt bằng — Sơ  đồ mặt bằng	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.463741+00	2026-09-21 07:18:48.463741+00
e9249497-f30a-437d-934e-a60e26b32060	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-16.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.466622+00	2026-09-21 07:18:48.466622+00
15e9b492-0f39-4d20-8360-bcd252a537d4	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-17.jpg	anh	\N	Ảnh trong nhà — Không gian bên trong	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.468755+00	2026-09-21 07:18:48.468755+00
807c26ad-4395-4f81-adc5-a76723d46dda	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-18.jpg	anh	\N	Ảnh trong nhà — Gian 1	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.470692+00	2026-09-21 07:18:48.470692+00
7500f749-b9b1-473d-a502-5650f9342aee	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-19.jpg	anh	\N	Ảnh trong nhà — GIan 1	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.472661+00	2026-09-21 07:18:48.472661+00
f19db7e7-00f2-47e1-910c-868079f253da	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-2.pdf	ban_ve	\N	Tổng mặt bằng — TMB	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.47462+00	2026-09-21 07:18:48.47462+00
c29880ac-5b41-4891-bc5f-2f82e0a7fc45	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-20.jpg	anh	\N	Ảnh trong nhà — Gian 2	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.47676+00	2026-09-21 07:18:48.47676+00
2478daec-378e-432e-8601-38904793dd7e	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-21.jpg	anh	\N	Ảnh trong nhà — Gian 3	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.479634+00	2026-09-21 07:18:48.479634+00
a2cd05a4-712a-46bd-b01f-e025af9a8439	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-22.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.48175+00	2026-09-21 07:18:48.48175+00
c9071106-eac5-4f06-9475-edb6570ab3c5	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-23.jpg	anh	\N	Kết cấu ảnh — Kết cấu	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.483698+00	2026-09-21 07:18:48.483698+00
16058d03-7484-4300-bd6c-f134107b2d16	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-24.jpg	anh	\N	Kết cấu ảnh — Kết cấu	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.485647+00	2026-09-21 07:18:48.485647+00
0f012402-3722-4a9e-ac6b-4c0927b7f093	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-25.png	anh	\N	Chân tảng ảnh — Trụ tảng	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.487609+00	2026-09-21 07:18:48.487609+00
a25f24a9-10dd-4351-8067-184e6f781947	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-3.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — Ảnh bình  phong	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.489744+00	2026-09-21 07:18:48.489744+00
24f7d457-7cd7-4492-85a3-ff67fea176f8	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-4.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt đứng	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.491695+00	2026-09-21 07:18:48.491695+00
3f046063-9953-4480-80eb-bee9db0ea5ee	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-6.jpg	anh	\N	Ảnh các góc chính — Ảnh góc chính	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.49366+00	2026-09-21 07:18:48.49366+00
6eb5f5e1-ed9b-42cd-8906-1490cdd66377	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-7.jpg	anh	\N	Ảnh các góc chính — Ảnh góc chính	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.49562+00	2026-09-21 07:18:48.49562+00
238cf315-6595-4c92-a521-a710fe997549	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-8.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.497739+00	2026-09-21 07:18:48.497739+00
71f87804-64da-4e42-b156-c7b593302c00	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-9.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:18:48.500639+00	2026-09-21 07:18:48.500639+00
a6a6806b-c746-43b4-8e4e-c30a409d1c51	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-1.jpg	anh	\N	Vị trí	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.50275+00	2026-09-21 07:18:48.50275+00
54d30daa-0351-4c01-b760-13b1a9ad0a5d	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-10.jpg	anh	\N	Hình ảnh hiên — Hiên	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.504691+00	2026-09-21 07:18:48.504691+00
33ee6140-9169-4ac9-9477-789d21ea254c	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-11.jpg	anh	\N	Hình ảnh hiên — Hiên	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.50665+00	2026-09-21 07:18:48.50665+00
5df23dc6-dccc-40a6-899e-142268fedb3d	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-12.jpg	anh	\N	Nền (ảnh chụp) — Nền sân	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.508608+00	2026-09-21 07:18:48.508608+00
6d5fd9dd-df80-4100-ae41-b5fc9a900d57	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-13.jpg	anh	\N	Nền (ảnh chụp) — Nền trong công trình	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.510733+00	2026-09-21 07:18:48.510733+00
12972b88-7914-4cb3-a171-0a798d8faf1c	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-14.pdf	ban_ve	\N	Sơ đồ mặt bằng — Mặt bằng	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.513623+00	2026-09-21 07:18:48.513623+00
851e224e-e3bc-4af1-9a1c-3a8556030bdf	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-15.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.515748+00	2026-09-21 07:18:48.515748+00
24ee6d2f-00be-441c-b4e1-8229fbc334eb	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-17.jpg	anh	\N	Gian 1	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.517717+00	2026-09-21 07:18:48.517717+00
ad14eade-67d6-4ccd-945e-573ca3914f33	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-18.jpg	anh	\N	Gian 2	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.519655+00	2026-09-21 07:18:48.519655+00
3b00ec48-fdbe-48a8-8fa4-9b7d94ae6df7	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-19.jpg	anh	\N	Gian 3	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.521618+00	2026-09-21 07:18:48.521618+00
e657457f-cc40-4dae-9406-abea40d4c8a8	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-2.jpg	anh	\N	Ảnh tổng thể từ cổng chính — ảnh cổng chính	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.52375+00	2026-09-21 07:18:48.52375+00
91e64bd5-4d11-468d-9317-ef98b87ed483	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-20.jpg	anh	\N	Gian 4	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.525699+00	2026-09-21 07:18:48.525699+00
f50ec393-7934-45b6-886b-3128069374cf	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-21.jpg	anh	\N	Gian 5	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.527656+00	2026-09-21 07:18:48.527656+00
9336d859-3e71-45a5-87de-fa22c44991f3	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-22.jpg	anh	\N	Gian 6 — GIan 6	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.529625+00	2026-09-21 07:18:48.529625+00
91aa2d38-46eb-4eed-abd4-2f9cab367819	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-23.jpg	anh	\N	GIan 7 — Gian 7	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.531748+00	2026-09-21 07:18:48.531748+00
5ad0b84e-7686-4d52-bb85-938de4959b48	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-24.jpg	anh	\N	Kết cấu ảnh — Kết cấu tổng thể	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.533697+00	2026-09-21 07:18:48.533697+00
ecf3f39e-eceb-4678-984e-c9279a71db72	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-25.jpg	anh	\N	Kết cấu ảnh — Vì nách	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.535644+00	2026-09-21 07:18:48.535644+00
d7cf32d0-868c-406d-b554-3c2647424742	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-26.jpg	anh	\N	Kết cấu ảnh — Vì nách	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.537614+00	2026-09-21 07:18:48.537614+00
664a2091-c260-4608-b45d-2926f46106a2	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-27.jpg	anh	\N	Chân tảng ảnh — ảnh chân tảng	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.539765+00	2026-09-21 07:18:48.539765+00
bcc62a47-3d25-42c9-81ad-dbd9302ee76a	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-28.jpg	anh	\N	Chân tảng hoa văn — chân tảng hoa văn	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.541703+00	2026-09-21 07:18:48.541703+00
822584e6-db8b-4dce-b177-fadd8420367d	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-3.pdf	ban_ve	\N	Tổng mặt bằng	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.543671+00	2026-09-21 07:18:48.543671+00
c3e3740b-227c-41c6-9df8-4d7efe6b089d	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-4.jpg	anh	\N	Mặt đứng, mặt bên công trình — Mặt đứng	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.545617+00	2026-09-21 07:18:48.545617+00
3161cc70-7dfd-45ac-bb2a-fdbb9daa7d14	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-5.jpg	anh	\N	Ảnh các góc chính — ảnh góc phải công trình	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.547746+00	2026-09-21 07:18:48.547746+00
86a8b55a-873c-4a03-a342-287611670d94	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-6.jpg	anh	\N	Ảnh các góc chính — Ảnh góc trái công trình	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.549693+00	2026-09-21 07:18:48.549693+00
d4bd2616-13ac-4acf-823f-0fecb0544025	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-7.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — Chi tiết	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.551666+00	2026-09-21 07:18:48.551666+00
1a6a1daf-ea2f-4bcc-a715-2c1112681faa	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-8.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — Chi tiết	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.553629+00	2026-09-21 07:18:48.553629+00
d8c25282-f3f7-4b5b-b2cb-7c47477befa9	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-9.jpg	anh	\N	Mái_cấu tạo — Mái	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.555751+00	2026-09-21 07:18:48.555751+00
0066849b-d5fe-43c2-8c5c-253f2b0302d4	/cu-da/decorative/bieu-tuong-thieng-va-bieu-tuong-ton-giao-6287041f-1.jpg	anh	\N	Bát bửu đạo giáo	decorative_art_items	eefd5277-aa1f-4507-b2b4-4fbe2174a6a7	2026-09-21 07:18:48.557709+00	2026-09-21 07:18:48.557709+00
dfb8d580-07f3-4e7e-afc9-b333071f852c	/cu-da/decorative/bat-tien-2cd719f7-1.jpg	anh	\N	\N	decorative_art_items	fe86923e-b8ed-4b2a-8e5a-b0b7a35ef5dc	2026-09-21 07:18:48.561641+00	2026-09-21 07:18:48.561641+00
60f96e37-ea7a-43db-9e57-a63cf00f1f2c	/cu-da/decorative/bat-tien-2cd719f7-2.jpg	anh	\N	\N	decorative_art_items	fe86923e-b8ed-4b2a-8e5a-b0b7a35ef5dc	2026-09-21 07:18:48.563759+00	2026-09-21 07:18:48.563759+00
97d7769d-66c9-443f-a9c6-de85ae08f37d	/cu-da/decorative/bat-tien-2cd719f7-3.jpg	anh	\N	\N	decorative_art_items	fe86923e-b8ed-4b2a-8e5a-b0b7a35ef5dc	2026-09-21 07:18:48.566631+00	2026-09-21 07:18:48.566631+00
a9cd294a-90a4-428e-8b01-3f7034925839	/cu-da/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-0df0c034-1.jpg	anh	\N	Vì nách hoạ tiết rồng	decorative_art_items	b56dcb41-f10d-4ab9-805d-9efcb01079ff	2026-09-21 07:18:48.56875+00	2026-09-21 07:18:48.56875+00
b61acc7f-08c3-4839-bf19-c4906fc94bdf	/cu-da/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-0df0c034-2.jpg	anh	\N	Lá hoá rồng	decorative_art_items	b56dcb41-f10d-4ab9-805d-9efcb01079ff	2026-09-21 07:18:48.571663+00	2026-09-21 07:18:48.571663+00
a492faa6-f7e1-4079-945e-dfffc5e9d2d2	/cu-da/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-314403c9-1.jpg	anh	\N	Lá hoá long	decorative_art_items	5f395108-0961-4d4e-962c-6cd053b4fbb9	2026-09-21 07:18:48.574708+00	2026-09-21 07:18:48.574708+00
f184494a-f9e3-4d64-a079-dc12241d5ed3	/cu-da/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-a79dc4b8-1.jpg	anh	\N	Vân hoá long	decorative_art_items	01659d8d-8e45-40dc-a5d9-90db7dca3e2e	2026-09-21 07:18:48.577739+00	2026-09-21 07:18:48.577739+00
774fcb06-55e5-4859-ac8f-d37344a057a4	/cu-da/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-a79dc4b8-2.jpg	anh	\N	Lá hoá long	decorative_art_items	01659d8d-8e45-40dc-a5d9-90db7dca3e2e	2026-09-21 07:18:48.580627+00	2026-09-21 07:18:48.580627+00
3a9eb184-2124-4ab5-906a-f9b086d5dfd1	/cu-da/decorative/linh-vat-rong-phuong-lan-long-ma-nghe-rua-1e09c0a0-1.png	anh	\N	Rồng ở đỉnh mái	decorative_art_items	8683e6bc-502f-403f-b994-99d76e4c5cce	2026-09-21 07:18:48.582758+00	2026-09-21 07:18:48.582758+00
376122a1-b9d1-40f8-a893-f9f76e3c4310	/cu-da/decorative/linh-vat-rong-phuong-lan-long-ma-nghe-rua-1e09c0a0-2.jpg	anh	\N	Nghê ở trước hiên	decorative_art_items	8683e6bc-502f-403f-b994-99d76e4c5cce	2026-09-21 07:18:48.585646+00	2026-09-21 07:18:48.585646+00
c1a91c8a-7d53-4ca8-bf78-7ac6f03420d3	/cu-da/decorative/linh-vat-rong-phuong-lan-long-ma-nghe-rua-fd1d837d-1.jpg	anh	\N	Con nghê ở đỉnh cột	decorative_art_items	ee362050-0e08-471c-8b7a-595749815888	2026-09-21 07:18:48.58776+00	2026-09-21 07:18:48.58776+00
c54f1187-b3b5-4ab8-9d1f-6008600403d6	/cu-da/decorative/luong-long-chau-nhat-0d6dbff7-1.jpg	anh	\N	Lưỡng long ở đỉnh mái	decorative_art_items	48fbd63b-11fa-44f1-945a-bb3e128d02ec	2026-09-21 07:18:48.590677+00	2026-09-21 07:18:48.590677+00
72ad2039-2db9-48d1-be04-e9052c695002	/cu-da/decorative/may-48b1e215-1.jpg	anh	\N	\N	decorative_art_items	68f79baf-1f0e-4722-b720-ca74a5478748	2026-09-21 07:18:48.593699+00	2026-09-21 07:18:48.593699+00
353f2ff0-0a48-40a7-8cce-05f71231a89e	/cu-da/decorative/tien-df4c0e8e-1.jpg	anh	\N	\N	decorative_art_items	e0929f69-0ea6-454a-8447-b112c95878a3	2026-09-21 07:18:48.595647+00	2026-09-21 07:18:48.595647+00
c11a5990-853b-42ee-b712-c43b39178f49	/cu-da/decorative/tuong-mau-trong-den-phu-428e557d-1.jpg	anh	\N	Tượng thờ mẫu	decorative_art_items	49a757b7-1fb0-46ba-ab5f-039fbb1f410b	2026-09-21 07:18:48.597763+00	2026-09-21 07:18:48.597763+00
5bc2ab93-f1d4-4748-82cc-2540c45427b6	/cu-da/decorative/tuong-to-trong-chua-6997111b-1.jpg	anh	\N	tượng sư tổ	decorative_art_items	ef4c41da-336e-4377-9952-3b0a7fe5ecd0	2026-09-21 07:18:48.600669+00	2026-09-21 07:18:48.600669+00
0a83d020-d756-4ede-9f6b-7dbbfc3cd838	/cu-da/decorative/tuong-to-trong-chua-6997111b-2.jpg	anh	\N	tượng Tổ	decorative_art_items	ef4c41da-336e-4377-9952-3b0a7fe5ecd0	2026-09-21 07:18:48.60262+00	2026-09-21 07:18:48.60262+00
f8f50ef8-3e1c-4041-a9b8-eac11e3831fb	/cu-da/decorative/tuong-phat-giao-trong-chua-d79dbbe9-1.jpg	anh	\N	Tượng Phật	decorative_art_items	58333609-f92c-4c17-8306-fa1f4559b873	2026-09-21 07:18:48.604728+00	2026-09-21 07:18:48.604728+00
1aea0597-e1a5-4058-bb21-a449a02d6501	/cu-da/decorative/tuong-phat-giao-trong-chua-d79dbbe9-2.jpg	anh	\N	Ban tượng Đức ông + 2 vị hậu cần	decorative_art_items	58333609-f92c-4c17-8306-fa1f4559b873	2026-09-21 07:18:48.60668+00	2026-09-21 07:18:48.60668+00
0293fc0c-1586-446c-a2ba-b97dc8eab1ae	/cu-da/decorative/tuong-thanh-than-trong-den-mieu-dao-quan-hoi-quan-fd5aa9f4-1.jpg	anh	\N	\N	decorative_art_items	44715bfb-72f0-40bb-a9a8-286544d594de	2026-09-21 07:18:48.608656+00	2026-09-21 07:18:48.608656+00
a4a6f0d0-a178-4ed7-b5a3-24a31c223330	/cu-da/decorative/tuong-thanh-than-trong-den-mieu-dao-quan-hoi-quan-fd5aa9f4-2.jpg	anh	\N	\N	decorative_art_items	44715bfb-72f0-40bb-a9a8-286544d594de	2026-09-21 07:18:48.610748+00	2026-09-21 07:18:48.610748+00
6c13bd90-658b-42e0-8cbe-a6bb9e2bb8d5	/cu-da/decorative/de-tai-cay-coi-tre-truc-tung-f81767a1-1.jpg	anh	\N	\N	decorative_art_items	9480a1e4-f49f-498f-ad50-f9dc919a715a	2026-09-21 07:18:48.613647+00	2026-09-21 07:18:48.613647+00
d560f477-a663-4eff-b37c-7e768fb70823	/cu-da/decorative/de-tai-cay-coi-tre-truc-tung-f81767a1-2.jpg	anh	\N	\N	decorative_art_items	9480a1e4-f49f-498f-ad50-f9dc919a715a	2026-09-21 07:18:48.615767+00	2026-09-21 07:18:48.615767+00
d933542a-d7a0-4c79-934a-e5bc4b376440	/cu-da/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-8231a62e-1.jpg	anh	\N	\N	decorative_art_items	b86cdb24-cd1a-4cd9-9a97-f2b75e79a885	2026-09-21 07:18:48.618656+00	2026-09-21 07:18:48.618656+00
3af03c38-f63f-4c58-8848-80ea278e9f86	/cu-da/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-0fe0485b-1.jpg	anh	\N	Cuốn thư	decorative_art_items	5af94691-44e4-4647-9e78-089b4b12cee8	2026-09-21 07:18:48.621716+00	2026-09-21 07:18:48.621716+00
a6bbe483-1049-48a8-90d5-a36417db7ef0	/cu-da/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-1a3a0d16-1.jpg	anh	\N	Hoành phi	decorative_art_items	19826bca-07d4-47e5-ac35-5263406d4084	2026-09-21 07:18:48.624794+00	2026-09-21 07:18:48.624794+00
2c16937c-595d-4cd1-9d6c-da26cd1e3992	/cu-da/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-a0a82cac-1.jpg	anh	\N	Hoành phi, câu đối	decorative_art_items	14d8c02c-2e8f-4b4a-9060-a0ec7f1fffa9	2026-09-21 07:18:48.627619+00	2026-09-21 07:18:48.627619+00
d4ece019-be04-4646-80e7-4adee755e245	/cu-da/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-d4636f70-1.jpg	anh	\N	hoành phi	decorative_art_items	590fe53a-b778-453f-b37d-b6e6ba6cdc5f	2026-09-21 07:18:48.629744+00	2026-09-21 07:18:48.629744+00
f1cc4c0d-543a-43f1-ba54-62045227d173	/cu-da/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-d4636f70-2.jpg	anh	\N	hoành phi2	decorative_art_items	590fe53a-b778-453f-b37d-b6e6ba6cdc5f	2026-09-21 07:18:48.632632+00	2026-09-21 07:18:48.632632+00
c2d50330-5838-4dc3-acbd-eb8b09e862c6	/cu-da/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-99ae5ca4-1.jpg	anh	\N	bát hương, mâm bồng	decorative_art_items	91b30cb6-9a23-48eb-8033-0c303ebf01ce	2026-09-21 07:18:48.637645+00	2026-09-21 07:18:48.637645+00
4ab62991-00f5-4da0-a8e0-1d9236091ed7	/cu-da/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-f4eae40c-1.png	anh	\N	bát hương	decorative_art_items	e7700e21-0a29-4bb2-8382-0d0472723e85	2026-09-21 07:18:48.640713+00	2026-09-21 07:18:48.640713+00
29a0e98e-0c7a-40e9-9319-64ac50b7f82f	/cu-da/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-1a5df654-1.jpg	anh	\N	Hương án	decorative_art_items	b202144b-01cb-48ae-af6c-23253bf34387	2026-09-21 07:18:48.64374+00	2026-09-21 07:18:48.64374+00
caed3af0-7d8d-4d51-865e-dc168e14915e	/cu-da/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-bfd47cd5-1.jpg	anh	\N	Hương án	decorative_art_items	0ff87038-f4d1-4bde-89cf-5f1a8b6b1242	2026-09-21 07:18:48.645696+00	2026-09-21 07:18:48.645696+00
a51e361c-6b6e-483c-9d5c-ba9a1fa609a6	/cu-da/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-d454d5cb-1.jpg	anh	\N	khám thờ	decorative_art_items	365483cc-e9db-4cf8-9651-4b05777c6cba	2026-09-21 07:18:48.647633+00	2026-09-21 07:18:48.647633+00
42cace84-787e-4388-9d7b-c06868fbc601	/cu-da/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-d454d5cb-2.jpg	anh	\N	hương án	decorative_art_items	365483cc-e9db-4cf8-9651-4b05777c6cba	2026-09-21 07:18:48.649755+00	2026-09-21 07:18:48.649755+00
7d950da3-020d-4c12-9d7f-61728361c047	/cu-da/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-d454d5cb-3.jpg	anh	\N	bài vị	decorative_art_items	365483cc-e9db-4cf8-9651-4b05777c6cba	2026-09-21 07:18:48.652626+00	2026-09-21 07:18:48.652626+00
5370b4b7-64e2-4339-b8d1-509203533426	/cu-da/craft-products/mien-23be602a-1.jpg	anh	\N	máy khoắng	craft_products	d7b4ad1e-464b-4f45-9abd-83d211020568	2026-09-21 07:18:48.654755+00	2026-09-21 07:18:48.654755+00
509ce1d0-ec07-405b-892a-c00b15e46bb8	/cu-da/craft-products/mien-23be602a-2.jpg	anh	\N	máy đánh	craft_products	d7b4ad1e-464b-4f45-9abd-83d211020568	2026-09-21 07:18:48.657756+00	2026-09-21 07:18:48.657756+00
00127055-caa1-4d3b-a08a-afe4d0b86b3a	/cu-da/craft-products/mien-23be602a-3.jpg	anh	\N	phên phơi (phơi tái)	craft_products	d7b4ad1e-464b-4f45-9abd-83d211020568	2026-09-21 07:18:48.660651+00	2026-09-21 07:18:48.660651+00
293e58a4-4d27-48a6-b1fd-d846eaae15b2	/cu-da/craft-products/mien-23be602a-4.jpg	anh	\N	phơi tái	craft_products	d7b4ad1e-464b-4f45-9abd-83d211020568	2026-09-21 07:18:48.66275+00	2026-09-21 07:18:48.66275+00
ec53f1eb-122a-4797-8040-b11e306c1b97	/cu-da/craft-products/mien-23be602a-5.jpg	anh	\N	phơi miến	craft_products	d7b4ad1e-464b-4f45-9abd-83d211020568	2026-09-21 07:18:48.66565+00	2026-09-21 07:18:48.66565+00
477d6567-3041-4c1a-b3d3-5e515db80a41	/cu-da/craft-products/tuong-798e9b00-1.jpg	anh	\N	Ảnh sản phẩm	craft_products	56f955bc-6786-4afe-b19d-607c21417a1f	2026-09-21 07:18:48.667767+00	2026-09-21 07:18:48.667767+00
e3fe3a3b-ea5b-41b4-81d7-c2842dc54070	/cu-da/heritage-buildings/dinh-lang-cu-da-26cdf372-16.jpg	panorama	\N	Ảnh trong nhà — Ảnh 360	heritage_buildings	98dbb779-b90c-469b-bc18-8179a8158231	2026-09-21 07:18:48.775372+00	2026-09-21 07:18:48.775372+00
e2828223-f966-4b16-b5b7-8763ed00443e	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-20.jpg	panorama	\N	Ảnh trong nhà — Ảnh 360 tam bảo	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.782773+00	2026-09-21 07:18:48.782773+00
06393eb4-3dfd-4780-9c94-48d7e254847c	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-10.jpg	panorama	\N	Ảnh trong nhà — ảnh 360 nhà chính	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.785836+00	2026-09-21 07:18:48.785836+00
68bab948-4449-4746-ad8f-d1c1e6fd9ffb	/cu-da/heritage-buildings/nha-ong-vu-ngoc-giao-0dcbc754-11.jpg	panorama	\N	Ảnh trong nhà — ảnh 360 nhà phụ	heritage_buildings	bf94d200-fd5c-46ea-a1fb-2cb52eb4797c	2026-09-21 07:18:48.788716+00	2026-09-21 07:18:48.788716+00
c767fa63-3967-4569-b97b-b4886d5fbd6b	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-11.jpg	panorama	\N	Ảnh các góc chính — Ảnh 360	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.349678+00	2026-09-21 07:18:48.790965+00
25afc8e7-66f9-4c21-9b79-154f840aaa2c	/ha-thai/heritage-buildings/nha-co-afe0acd9-1.jpg	panorama	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 và ảnh chụp)	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.920759+00	2026-09-21 07:18:48.920759+00
a4a410f6-ccee-4ae4-9480-7e3fe36e4c0b	/ha-thai/heritage-buildings/nha-co-afe0acd9-10.jpg	anh	\N	Mặt đứng công trình	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.924741+00	2026-09-21 07:18:48.924741+00
82239662-9290-4256-946e-90049cb37020	/ha-thai/heritage-buildings/nha-co-afe0acd9-11.jpg	anh	\N	Mặt bên công trình	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.926676+00	2026-09-21 07:18:48.926676+00
5c2ed90d-1a10-46f3-969a-9c323b38ae20	/ha-thai/heritage-buildings/nha-co-afe0acd9-12.jpg	anh	\N	Ảnh các góc chính	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.928622+00	2026-09-21 07:18:48.928622+00
2f447a2c-7456-41a1-808a-ce3941c17340	/ha-thai/heritage-buildings/nha-co-afe0acd9-14.jpg	anh	\N	Bờ nóc xây gạch hoa chanh, 2 đầu hồi có trang trí hoa văn đắp nổi, Diềm mái ngắt nước và đầu bảy khắc chữ Thọ vuông,	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.933633+00	2026-09-21 07:18:48.933633+00
861d228f-13a8-48d3-96a2-ee96a12d7fa5	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-32.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.076614+00	2026-09-21 07:18:49.076614+00
4af833a4-5e2f-488e-9f4d-5a6f4088b663	/ha-thai/heritage-buildings/nha-co-afe0acd9-15.jpg	anh	\N	Bờ nóc xây gạch hoa chanh, 2 đầu hồi có trang trí hoa văn đắp nổi, Diềm mái ngắt nước và đầu bảy khắc chữ Thọ vuông,	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.935781+00	2026-09-21 07:18:48.935781+00
205feaf3-e613-4d40-b582-652484f09abe	/ha-thai/heritage-buildings/nha-co-afe0acd9-16.jpg	anh	\N	Mái_vật liệu: Ngói nung, hình dạng ngói : loại ngói mũi hài	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.938619+00	2026-09-21 07:18:48.938619+00
ee2c5a3d-de5b-4006-9217-237880668f0d	/ha-thai/heritage-buildings/nha-co-afe0acd9-17.jpg	anh	\N	Mái_cấu tạo: Mặt bằng mái hình chữ nhật với 2 mái dốc.	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.940749+00	2026-09-21 07:18:48.940749+00
4bbe4dff-6d5e-466b-86ca-9febb2eda0bd	/ha-thai/heritage-buildings/nha-co-afe0acd9-18.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.943642+00	2026-09-21 07:18:48.943642+00
b3b93a8b-4951-4c1a-8b32-9632a9f0d56d	/ha-thai/heritage-buildings/nha-co-afe0acd9-19.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.945744+00	2026-09-21 07:18:48.945744+00
ac207cf7-621c-4fa0-a284-cd6e5767f00e	/ha-thai/heritage-buildings/nha-co-afe0acd9-2.jpg	panorama	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 và ảnh chụp)	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.94865+00	2026-09-21 07:18:48.94865+00
cd225037-3de3-4b33-bab4-ce5a7a3bd66a	/ha-thai/heritage-buildings/nha-co-afe0acd9-20.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.950748+00	2026-09-21 07:18:48.950748+00
43d2c713-2e9f-430d-8c4a-2b821a0a9164	/ha-thai/heritage-buildings/nha-co-afe0acd9-21.jpg	anh	\N	Nền (ảnh chụp): Nền sân, nền hiên, nền trong nhà	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.953633+00	2026-09-21 07:18:48.953633+00
767636e1-4ef7-4069-86a2-06e2abe48981	/ha-thai/heritage-buildings/nha-co-afe0acd9-22.jpg	anh	\N	Nền (ảnh chụp): Nền sân, nền hiên, nền trong nhà	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.955763+00	2026-09-21 07:18:48.955763+00
3a0fb26c-a8e0-4558-98f4-b241fc2c778f	/ha-thai/heritage-buildings/nha-co-afe0acd9-23.jpg	anh	\N	Nền (ảnh chụp): Nền sân, nền hiên, nền trong nhà	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.958655+00	2026-09-21 07:18:48.958655+00
4e827d13-5277-46e6-98a6-1a3fc7dc7cc1	/ha-thai/heritage-buildings/nha-co-afe0acd9-24.pdf	ban_ve	\N	Sơ đồ mặt bằng: Nhà có 5 gian — Bản vẽ	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.960776+00	2026-09-21 07:18:48.960776+00
f0ad0d6c-a1f1-45c5-b362-5f9ce832d557	/ha-thai/heritage-buildings/nha-co-afe0acd9-25.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì: Bộ vì 4 hàng chân cột gỗ ( trốn 1 cột để lòng nhà rộng hơn) — Bản vẽ	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.963633+00	2026-09-21 07:18:48.963633+00
d5b61ccb-9a70-41b3-a1ff-8c827272c237	/ha-thai/heritage-buildings/nha-co-afe0acd9-28.jpg	anh	\N	0-Vì các gian góc	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.970604+00	2026-09-21 07:18:48.970604+00
3726f354-a70a-404f-a12c-eeca74228213	/ha-thai/heritage-buildings/nha-co-afe0acd9-29.jpg	anh	\N	0-Vì các gian góc	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.972732+00	2026-09-21 07:18:48.972732+00
c636773a-5470-44ad-8f85-10846447ef6a	/ha-thai/heritage-buildings/nha-co-afe0acd9-30.jpg	anh	\N	0-Vì các gian góc	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.977743+00	2026-09-21 07:18:48.977743+00
e193fec8-f8cf-4944-ad1a-d62d83960b15	/ha-thai/heritage-buildings/nha-co-afe0acd9-31.jpg	anh	\N	0-Vì các gian góc	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.980651+00	2026-09-21 07:18:48.980651+00
2a67cec7-de6f-4815-a29b-8417574008b8	/ha-thai/heritage-buildings/nha-co-afe0acd9-32.jpg	anh	\N	1-Vì gian chính giữa:  Vì nóc kiểu Giá chiêng kết hợp kẻ ngồi, vì nách kiểu Kẻ ngồi. Trang trí đơn giản.	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.982777+00	2026-09-21 07:18:48.982777+00
98006ba8-6f06-48e3-bb80-039d4833cd4d	/ha-thai/heritage-buildings/nha-co-afe0acd9-33.jpg	anh	\N	1-Vì gian chính giữa:  Vì nóc kiểu Giá chiêng kết hợp kẻ ngồi, vì nách kiểu Kẻ ngồi. Trang trí đơn giản.	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.98566+00	2026-09-21 07:18:48.98566+00
0b9b1485-e44a-4448-b29e-4e298401a462	/ha-thai/heritage-buildings/nha-co-afe0acd9-34.jpg	anh	\N	1-Vì gian chính giữa:  Vì nóc kiểu Giá chiêng kết hợp kẻ ngồi, vì nách kiểu Kẻ ngồi. Trang trí đơn giản.	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.987802+00	2026-09-21 07:18:48.987802+00
b609b5f0-6033-4ca9-8ffa-c81950dcdd4e	/ha-thai/heritage-buildings/nha-co-afe0acd9-35.jpg	anh	\N	Câu đầu gian chính giữa và Thượng Lương	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.990657+00	2026-09-21 07:18:48.990657+00
f18027ff-0d30-4b97-a26e-b992e5b30851	/ha-thai/heritage-buildings/nha-co-afe0acd9-36.jpg	anh	\N	2-Vì gian 2 bên : Vì nóc kiểu Giá chiêng kết hợp chồng rường, vì nách kiểu Kẻ ngồi. Trang trí chạm nổi nhiều chi tiết.	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.992785+00	2026-09-21 07:18:48.992785+00
bcb5b8ba-f203-4032-b09b-f9e3f2bf82f6	/ha-thai/heritage-buildings/nha-co-afe0acd9-37.jpg	anh	\N	3-Vì gian biên: Vì gian biên làm đơn giản, không trang trí,  kiểu kẻ suốt (dầm xiên chạy hết các đầu cột)	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.995727+00	2026-09-21 07:18:48.995727+00
562184b4-71da-4039-8ce4-a853acdcb13f	/ha-thai/heritage-buildings/nha-co-afe0acd9-38.jpg	anh	\N	Chân tảng ảnh	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.998709+00	2026-09-21 07:18:48.998709+00
5a0b1af1-8b8e-4570-9565-c7f5c3d5a866	/ha-thai/heritage-buildings/nha-co-afe0acd9-5.pdf	ban_ve	\N	Tổng mặt bằng: Bản vẽ TMB thể hiện các hạng mục thành phần của nhà. — Bản vẽ	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:49.002611+00	2026-09-21 07:18:49.002611+00
f05b802b-397a-4ef9-8c68-ba98df8b0dcd	/ha-thai/heritage-buildings/nha-co-afe0acd9-6.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:49.004754+00	2026-09-21 07:18:49.004754+00
47fb7b12-6fd2-4fcb-b522-0d60f820c458	/ha-thai/heritage-buildings/nha-co-afe0acd9-7.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:49.007641+00	2026-09-21 07:18:49.007641+00
704d1b9e-688e-469f-af7e-0453c31404af	/ha-thai/heritage-buildings/nha-co-afe0acd9-8.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:49.009752+00	2026-09-21 07:18:49.009752+00
f580f5c1-bf89-4f96-94e9-c08b99a19ea7	/ha-thai/heritage-buildings/nha-co-afe0acd9-9.jpg	anh	\N	Chụp thượng lương: Dịch dòng chữ Hán trên Thượng lương: " Vào ngày lành, giờ đẹp của tháng mùa đông, năm(bị mờ)... tiến hành dựng cột và cất nóc nhà, cầu mong muôn vàn điều tốt lành, đại cát đại lợi."	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:49.012641+00	2026-09-21 07:18:49.012641+00
343cf9d1-6e5f-455b-a2e3-8de747696245	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-1.jpg	panorama	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 độ, các góc nhìn) — Ảnh 360	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.014758+00	2026-09-21 07:18:49.014758+00
ec93bc2b-4b3a-4e3e-8e43-e1f19188d13e	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-10.jpg	anh	\N	Trụ Biểu 1: Trụ biểu mang phong cách thời Nguyễn	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.017652+00	2026-09-21 07:18:49.017652+00
943586a7-b780-426c-b96d-aae78666d784	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-11.jpg	anh	\N	Trụ Biểu 2: Trụ biểu mang phong cách thời Nguyễn	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.019758+00	2026-09-21 07:18:49.019758+00
31d4c961-12f2-4663-93a5-0bdf6bbae137	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-12.jpg	anh	\N	Trụ biểu 3: Trụ biểu mang phong cách thời Nguyễn	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.022653+00	2026-09-21 07:18:49.022653+00
429a7893-fcc7-4ece-956b-98ac069b8a26	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-13.jpg	anh	\N	Tường bao: Tường bao xung quanh đình	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.024753+00	2026-09-21 07:18:49.024753+00
c583f439-7bae-43eb-ac0f-07a11a643983	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-14.jpg	anh	\N	Giếng làng: Giếng phía  trước đình	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.027649+00	2026-09-21 07:18:49.027649+00
fd283d47-efcc-4cb5-b9df-70b103b9b6d5	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-15.jpg	anh	\N	Bia đá: Bia đá đặt ở nhà bia giữa hồ	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.029787+00	2026-09-21 07:18:49.029787+00
fc4247fb-6956-4d4f-b6f8-5931bfceecd3	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-16.jpg	anh	\N	Mặt đứng: Đại đình có 5 gian và 2 chái. (Tổng là 7 gian)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.032653+00	2026-09-21 07:18:49.032653+00
8116caa0-4df8-41ee-b09d-4710a8f39020	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-17.jpg	anh	\N	Mặt bên: Mặt bên Đại đình có dạng đầu hồi bít đốc tức là mặt bên xây tường kín, không để hành lang.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.034775+00	2026-09-21 07:18:49.034775+00
cf44d963-5fec-42b7-ac6b-4502eacaa997	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-18.jpg	anh	\N	Ảnh các góc chính	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.037651+00	2026-09-21 07:18:49.037651+00
86b68267-882a-4662-9938-2376082bbffc	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-19.jpg	anh	\N	Ảnh các góc chính	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.039771+00	2026-09-21 07:18:49.039771+00
e18167f6-34bc-4c09-897a-429ed0cf3352	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-20.jpg	anh	\N	Bờ nóc trang trí hình song Long chầu mặt Nguyệt/ mặt Trời.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.044606+00	2026-09-21 07:18:49.044606+00
e9e0e00d-047f-400c-a8c2-f0df49572f12	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-21.jpg	anh	\N	Đầu 2 bờ nóc trang trí 2 con Si vẫn. Si vẫn là con linh vật chống cháy trong công trình cổ	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.046735+00	2026-09-21 07:18:49.046735+00
a73865bd-5aac-4146-b122-7738e9a08749	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-22.jpg	anh	\N	Vẽ chữ Thọ vuông (Thọ Triện) ở đầu Bẩy hiên.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.049629+00	2026-09-21 07:18:49.049629+00
bd19f7a5-429e-480e-9ad8-d785b96b24cd	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-23.jpg	anh	\N	Đắp nổi hình chim Phượng ở đầu hồi Đại đình, do Đình thờ vị nữ nhân thần, đây cũng là điểm đặc trưng của Đình thờ nữ thần.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.051745+00	2026-09-21 07:18:49.051745+00
9de723fb-5350-4aba-9512-11f32e361a9b	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-24.jpg	anh	\N	Cửa sổ trang trí chữ Thọ vuông (Thọ Triện) ở 2 gian chái đình.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.054637+00	2026-09-21 07:18:49.054637+00
53e3da27-5dd5-4c16-8653-e6e45ebe6714	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-25.jpg	anh	\N	Mái_cấu tạo: Tuy đình có mặt bằng hình chữ Công nhưng mái của 3 khu vực đại Đình, ống muống, hậu cung tách rời, không nối liền sống mái với nhau.                                                            Đại Đình có 2 mái, kiểu đầu hồi bít đốc (đầu hồi xây tường kín). Hậu cung có 2 mái và đầu hồi bít đốc. Riêng mái  ống muống có kiểu 2 tầng mái nhỏ.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.056759+00	2026-09-21 07:18:49.056759+00
0c754e38-3929-4167-9c41-079ed5b45a78	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-26.jpg	anh	\N	Mái_cấu tạo: Tuy đình có mặt bằng hình chữ Công nhưng mái của 3 khu vực đại Đình, ống muống, hậu cung tách rời, không nối liền sống mái với nhau.                                                            Đại Đình có 2 mái, kiểu đầu hồi bít đốc (đầu hồi xây tường kín). Hậu cung có 2 mái và đầu hồi bít đốc. Riêng mái  ống muống có kiểu 2 tầng mái nhỏ.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.059648+00	2026-09-21 07:18:49.059648+00
698e8f6c-632a-44ab-aa26-0b3e4358e364	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-27.jpg	anh	\N	Mái_cấu tạo: Tuy đình có mặt bằng hình chữ Công nhưng mái của 3 khu vực đại Đình, ống muống, hậu cung tách rời, không nối liền sống mái với nhau.                                                            Đại Đình có 2 mái, kiểu đầu hồi bít đốc (đầu hồi xây tường kín). Hậu cung có 2 mái và đầu hồi bít đốc. Riêng mái  ống muống có kiểu 2 tầng mái nhỏ.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.061753+00	2026-09-21 07:18:49.061753+00
577cab40-5367-4499-8374-41726bc3fa65	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-28.jpg	anh	\N	Mái_cấu tạo: Tuy đình có mặt bằng hình chữ Công nhưng mái của 3 khu vực đại Đình, ống muống, hậu cung tách rời, không nối liền sống mái với nhau.                                                            Đại Đình có 2 mái, kiểu đầu hồi bít đốc (đầu hồi xây tường kín). Hậu cung có 2 mái và đầu hồi bít đốc. Riêng mái  ống muống có kiểu 2 tầng mái nhỏ.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.064675+00	2026-09-21 07:18:49.064675+00
cce823b0-8254-4932-9b0e-8c3e58d6fe77	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-29.jpg	anh	\N	Mái_cấu tạo: Tuy đình có mặt bằng hình chữ Công nhưng mái của 3 khu vực đại Đình, ống muống, hậu cung tách rời, không nối liền sống mái với nhau.                                                            Đại Đình có 2 mái, kiểu đầu hồi bít đốc (đầu hồi xây tường kín). Hậu cung có 2 mái và đầu hồi bít đốc. Riêng mái  ống muống có kiểu 2 tầng mái nhỏ.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.066756+00	2026-09-21 07:18:49.066756+00
5c9dd4b3-3cc7-4b5a-b0e3-33f39aac7609	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-30.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.071756+00	2026-09-21 07:18:49.071756+00
b97f76a0-e76c-4aa8-9b86-87bebf2d12b7	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-31.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.07466+00	2026-09-21 07:18:49.07466+00
889a00f6-0815-40b9-bb68-58d32c32ad93	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-35.jpg	anh	\N	Nền (ảnh chụp)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.083744+00	2026-09-21 07:18:49.083744+00
51f17a5a-5d4b-4e4d-917b-c94cdb76d21e	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-36.pdf	ban_ve	\N	Sơ đồ mặt bằng: Đại đình có 7 gian, 1 gian ống muống nối với hậu cung. — Bản vẽ	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.086639+00	2026-09-21 07:18:49.086639+00
a9713fab-7b1a-445f-94fe-f5274949b13d	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-37.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì: Bộ vì có 4 hàng chân cột, không có cột hiên. — Bản vẽ	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.088753+00	2026-09-21 07:18:49.088753+00
1bfaf830-8d70-4f2f-92a5-0467333ce024	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-38.jpg	panorama	\N	Ảnh trong nhà: ảnh 360	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.091649+00	2026-09-21 07:18:49.091649+00
96d63d27-c11b-4d5e-b1be-9eb1a1aae311	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-39.jpg	panorama	\N	Ảnh trong nhà: ảnh 360	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.093759+00	2026-09-21 07:18:49.093759+00
0bc8ed89-32a0-4b30-9afc-564f9a35914a	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-40.jpg	anh	\N	Đại đình- Vì kèo các gian	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.098767+00	2026-09-21 07:18:49.098767+00
4ac60d4f-90a5-45aa-b1d2-7d3bedbdbc88	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-41.jpg	anh	\N	Vì nóc gian chính giữa  Đại đình: Tên gọi vì nóc Đại đình: Vì giá chiêng chồng rường con nhị. Vì được chạm hoa văn nổi đơn giản, thanh thoát.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.101651+00	2026-09-21 07:18:49.101651+00
a10eecc2-b6f3-45c1-a2e3-4a852332d5c4	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-42.jpg	anh	\N	Vì nách gian chính giữa  Đại đình: Vì nách gian chính giữa Đại đình: Tên gọi: Vì chồng rường, với các rường cụt. Các thanh rường được trang trí, chạm nổi, chạm lộng các hoa văn hình các con rồng dày đặc, các bờm tóc vuốt nhọn như hình mũi kiếm hay lưỡi thương rất đặc trưng của nghệ thuật thế kỷ 18.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.103614+00	2026-09-21 07:18:49.103614+00
fc9ba9c7-d2fa-4a69-94c4-d0409ebcb9b3	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-43.jpg	anh	\N	Vì nách gian chính giữa  Đại đình: Vì nách gian chính giữa Đại đình: Tên gọi: Vì chồng rường, với các rường cụt. Các thanh rường được trang trí, chạm nổi, chạm lộng các hoa văn hình các con rồng dày đặc, các bờm tóc vuốt nhọn như hình mũi kiếm hay lưỡi thương rất đặc trưng của nghệ thuật thế kỷ 18.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.105746+00	2026-09-21 07:18:49.105746+00
9e041d5b-a0db-4dad-aed9-6cf40335a397	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-44.jpg	anh	\N	Vì nóc gian biên	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.108627+00	2026-09-21 07:18:49.108627+00
c29f3bf8-0a77-4956-82d0-7e79ce90c673	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-45.jpg	anh	\N	Vì gian Ống muống và Hậu cung: Vì gian ống muống và hậu cung làm rất đơn giản, không hoa văn.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.110758+00	2026-09-21 07:18:49.110758+00
3e8c2bb9-d7cf-4e2e-8eb2-8b64534cf791	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-46.jpg	anh	\N	Vì gian Ống muống và Hậu cung: Vì gian ống muống và hậu cung làm rất đơn giản, không hoa văn.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.113621+00	2026-09-21 07:18:49.113621+00
c8e4ce33-ab95-4dad-bdd7-3e2692f8a65f	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-47.jpg	anh	\N	Vì gian Ống muống và Hậu cung: Vì gian ống muống và hậu cung làm rất đơn giản, không hoa văn.	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.115765+00	2026-09-21 07:18:49.115765+00
69939918-adab-40ee-8129-8a0474439670	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-48.jpg	anh	\N	Gian Ống muống	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.118647+00	2026-09-21 07:18:49.118647+00
95c01576-95ed-4969-a11a-b8fd2391959c	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-49.jpg	anh	\N	Chân tảng ảnh	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.120747+00	2026-09-21 07:18:49.120747+00
853c000b-d973-41ef-9e4c-4a7ea6d938d4	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-8.pdf	ban_ve	\N	Tổng mặt bằng (TMB): Bản vẽ TMB thể hiện các hạng mục thành phần của Đình. — Bản vẽ	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.130789+00	2026-09-21 07:18:49.130789+00
8aca934b-ef25-4ca8-9839-a2a900ccec52	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-9.jpg	anh	\N	Nhà bia	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.133641+00	2026-09-21 07:18:49.133641+00
a23ce20b-9283-446e-8f18-c09d827ec3b6	/ha-thai/decorative/cua-vong-hoanh-phi-vi-tri-gian-tho-chinh-giua-nha-df0835cd-1.jpg	anh	\N	\N	decorative_art_items	e0032a1a-7e70-4a83-bf40-b9b211da13cc	2026-09-21 07:18:49.135623+00	2026-09-21 07:18:49.135623+00
e54b0cdd-6fc3-4a4a-8f1a-8117f1c4453a	/ha-thai/decorative/trang-tri-thanh-cau-dau-va-thuong-luong-qua-giang-7847b5e1-1.jpg	anh	\N	\N	decorative_art_items	07bfd70f-6712-4999-9706-663f10b700b7	2026-09-21 07:18:49.139728+00	2026-09-21 07:18:49.139728+00
8ac9b983-5983-435c-8a8a-abc23eb27315	/ha-thai/decorative/linh-vat-phuong-f181cdf3-1.jpg	anh	\N	\N	decorative_art_items	ed67fa2e-ccbf-4d40-82e4-bbd2d309ce50	2026-09-21 07:18:49.145664+00	2026-09-21 07:18:49.145664+00
46cef90e-f659-4acd-99d2-e5bb23479cd0	/ha-thai/decorative/linh-vat-rong-1aa8e368-1.jpg	anh	\N	\N	decorative_art_items	d56e89d8-654f-43ca-bdd9-42e7e66b5da4	2026-09-21 07:18:49.148709+00	2026-09-21 07:18:49.148709+00
694c6a2b-9c9f-48b8-b435-2fd70f3717dc	/ha-thai/decorative/linh-vat-rong-1aa8e368-2.jpg	anh	\N	\N	decorative_art_items	d56e89d8-654f-43ca-bdd9-42e7e66b5da4	2026-09-21 07:18:49.151752+00	2026-09-21 07:18:49.151752+00
c74a4eed-afaa-429e-ba12-1b0c29426054	/ha-thai/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-3911e738-1.jpg	anh	\N	\N	decorative_art_items	1427d07c-9f70-4284-a467-95cc49f822d3	2026-09-21 07:18:49.154779+00	2026-09-21 07:18:49.154779+00
d507c02a-ca3f-4c20-9123-64da07e04957	/ha-thai/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-3911e738-2.jpg	anh	\N	\N	decorative_art_items	1427d07c-9f70-4284-a467-95cc49f822d3	2026-09-21 07:18:49.157627+00	2026-09-21 07:18:49.157627+00
c5b1c8ad-e21a-4be6-bae8-9e224cf10a94	/ha-thai/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-3911e738-3.jpg	anh	\N	\N	decorative_art_items	1427d07c-9f70-4284-a467-95cc49f822d3	2026-09-21 07:18:49.160676+00	2026-09-21 07:18:49.160676+00
9ba6256d-017d-49ab-b5b7-f49b92d24f4b	/ha-thai/craft-products/tranh-son-mai-cac-vat-dung-trang-tri-lo-hoa-dia-trung-bay-31f4e830-1.jpg	anh	\N	Tranh khảm trứng đức phật	craft_products	cee1b1d2-6f30-44ff-9862-e8c6a0cffe90	2026-09-21 07:18:49.163708+00	2026-09-21 07:18:49.163708+00
1689c1b4-8e0a-42a8-b844-de737ae0bb14	/ha-thai/craft-products/tranh-son-mai-cac-vat-dung-trang-tri-lo-hoa-dia-trung-bay-31f4e830-2.jpg	anh	\N	Tranh sơn mài làng quê	craft_products	cee1b1d2-6f30-44ff-9862-e8c6a0cffe90	2026-09-21 07:18:49.16672+00	2026-09-21 07:18:49.16672+00
329c69a4-48c3-458f-b231-0e5d9cdbc2bb	/ha-thai/craft-products/tranh-son-mai-cac-vat-dung-trang-tri-lo-hoa-dia-trung-bay-van-dung-gia-dinh-43925cd7-1.jpg	anh	\N	Tượng sơn mài	craft_products	e6e001cc-263b-416c-84b9-3303d54a8097	2026-09-21 07:18:49.168678+00	2026-09-21 07:18:49.168678+00
a1a2c5a7-2109-4ce4-aa1f-545292408774	/ha-thai/craft-products/tranh-son-mai-cac-vat-dung-trang-tri-lo-hoa-dia-trung-bay-van-dung-gia-dinh-43925cd7-2.jpg	anh	\N	Đĩa trang chí phòng	craft_products	e6e001cc-263b-416c-84b9-3303d54a8097	2026-09-21 07:18:49.170621+00	2026-09-21 07:18:49.170621+00
a46c920a-34e9-46bb-bb3d-cfc6ddc25fc8	/lang-cuu/heritage-buildings/nha-tay-0b7290de-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — ảnh đèn treo	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.292688+00	2026-09-21 07:18:49.292688+00
f40eab05-8447-407b-943a-30561f76213e	/lang-cuu/heritage-buildings/nha-tay-0b7290de-11.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — ảnh cửa chính	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.295732+00	2026-09-21 07:18:49.295732+00
8952aa39-4308-4127-b0a7-00642c403cc4	/lang-cuu/heritage-buildings/nha-tay-0b7290de-12.jpg	anh	\N	Mái_cấu tạo	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.297652+00	2026-09-21 07:18:49.297652+00
9e4bec57-ad76-428e-88d9-5e0f8c74be35	/lang-cuu/heritage-buildings/nha-tay-0b7290de-13.jpg	anh	\N	Hình ảnh hiên — ảnh ngoài nhìn vào hiên	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.299617+00	2026-09-21 07:18:49.299617+00
1aed6221-8a1f-4932-bba4-d7759765346d	/lang-cuu/heritage-buildings/nha-tay-0b7290de-14.jpg	anh	\N	Hình ảnh hiên — ảnh dọc hiên	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.301747+00	2026-09-21 07:18:49.301747+00
5ce41a03-542d-4d7a-abf2-0e20a6a63e8a	/lang-cuu/heritage-buildings/nha-tay-0b7290de-15.jpg	anh	\N	Nền (ảnh chụp)	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.304644+00	2026-09-21 07:18:49.304644+00
498a00c6-55f3-4b67-adbe-5a7db04fe919	/lang-cuu/heritage-buildings/nha-tay-0b7290de-16.pdf	ban_ve	\N	Sơ đồ mặt bằng — sơ đồ mặt bằng	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.306753+00	2026-09-21 07:18:49.306753+00
8ffe29c6-bd1b-4cda-82ca-ad91952d431e	/lang-cuu/heritage-buildings/nha-tay-0b7290de-17.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt và bộ vi	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.309637+00	2026-09-21 07:18:49.309637+00
81ad38f9-eb71-48e1-8495-94091daabefa	/lang-cuu/heritage-buildings/nha-tay-0b7290de-18.jpg	panorama	\N	Ảnh trong nhà — ảnh 360 trong nhà	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.311771+00	2026-09-21 07:18:49.311771+00
17d14718-46a4-402f-ab49-85ebc276c806	/lang-cuu/heritage-buildings/nha-tay-0b7290de-19.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.314665+00	2026-09-21 07:18:49.314665+00
1c08337b-0e1c-42e9-93e7-65e5ae6f1451	/lang-cuu/heritage-buildings/nha-tay-0b7290de-20.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.318749+00	2026-09-21 07:18:49.318749+00
1b96e713-a99e-4cd3-8dfc-60b86a4241f7	/lang-cuu/heritage-buildings/nha-tay-0b7290de-3.pdf	ban_ve	\N	Tổng mặt bằng — tổng mặt bằng	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.321635+00	2026-09-21 07:18:49.321635+00
08435d3e-9839-401e-8dd5-95a30acdce6b	/lang-cuu/heritage-buildings/nha-tay-0b7290de-4.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — ảnh·	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.323735+00	2026-09-21 07:18:49.323735+00
531dbe63-f5c5-44d1-b62f-64bc85b7d44b	/lang-cuu/heritage-buildings/nha-tay-0b7290de-5.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — ảnh·	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.326629+00	2026-09-21 07:18:49.326629+00
110d1a24-a1b3-48e6-9b84-89c6038c8667	/lang-cuu/heritage-buildings/nha-tay-0b7290de-6.jpg	anh	\N	Chụp thượng lương — ảnh thượng lương	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.328767+00	2026-09-21 07:18:49.328767+00
2c2454bd-14cf-4934-9d6a-3790c4a9193d	/lang-cuu/heritage-buildings/nha-tay-0b7290de-7.jpg	anh	\N	Mặt đứng, mặt bên công trình — ảnh mặt đứng	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.331763+00	2026-09-21 07:18:49.331763+00
d8939206-d36c-4f37-b423-1d82fe49c843	/lang-cuu/heritage-buildings/nha-tay-0b7290de-8.jpg	anh	\N	Ảnh các góc chính	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.334743+00	2026-09-21 07:18:49.334743+00
cc8f05d0-1e13-470b-a4dd-c7698f8cb9ef	/lang-cuu/heritage-buildings/nha-tay-0b7290de-9.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — ảnh bàn thờ có các chi tiết đặc biệt	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.337783+00	2026-09-21 07:18:49.337783+00
c0828db4-588e-4f2b-a0ca-679b590fba03	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-10.jpg	anh	\N	Ảnh các góc chính	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.341669+00	2026-09-21 07:18:49.341669+00
e8ed76fb-8fa8-4c62-8eff-64f2979d7cc7	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-11.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.343778+00	2026-09-21 07:18:49.343778+00
d1bbd431-fff8-4926-b5c5-38c22b1388c1	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-12.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.346673+00	2026-09-21 07:18:49.346673+00
938ac409-6eea-44de-9048-2a0768781edd	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-13.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.348794+00	2026-09-21 07:18:49.348794+00
87e7bcfb-8b77-471c-9dcd-b9883910bc87	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-14.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.35167+00	2026-09-21 07:18:49.35167+00
191d65d5-2f94-4aa2-98c7-40d67051a4d9	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-15.jpg	anh	\N	Nền (ảnh chụp)	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.353772+00	2026-09-21 07:18:49.353772+00
bebb7431-2ce2-4886-a099-41bd66f4a56c	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-16.pdf	ban_ve	\N	Sơ đồ mặt bằng — mặt bằng	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.356657+00	2026-09-21 07:18:49.356657+00
491332ee-3c73-4976-917a-4b8ade7e5aab	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-17.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt và bộ vi	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.358813+00	2026-09-21 07:18:49.358813+00
5092a1b7-3f3b-4866-8903-09c447ace488	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-18.jpg	panorama	\N	Ảnh trong nhà — ảnh 360 trong nhà	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.361667+00	2026-09-21 07:18:49.361667+00
d5cf1efa-4ca0-45ad-9e77-579b79c49cbc	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-19.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.363792+00	2026-09-21 07:18:49.363792+00
fb45c2c6-1499-4419-ba75-2ca15a07f3c7	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-2.pdf	ban_ve	\N	Tổng mặt bằng — tổng mặt bằng	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.366656+00	2026-09-21 07:18:49.366656+00
00a07cfe-b214-4b76-b780-2e8d6642e569	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-20.jpg	anh	\N	Chân tảng ảnh	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.368813+00	2026-09-21 07:18:49.368813+00
1935b6f9-45eb-42e3-8dc8-5b274f92598f	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-3.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — ảnh sân	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.371685+00	2026-09-21 07:18:49.371685+00
01b9f6bb-2e28-4b6b-97d7-74a3c1c68a83	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-4.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — ảnh chân tảng của cổng	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.373811+00	2026-09-21 07:18:49.373811+00
328c3ff4-516e-4352-a2f5-9df209301555	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-5.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — ảnh vòm cổng	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.376653+00	2026-09-21 07:18:49.376653+00
0aa0c98c-22c4-4d15-8362-c65bc90bcbda	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-6.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — ảnh chi tiết hoa văn của cổng	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.378794+00	2026-09-21 07:18:49.378794+00
9457e35a-dca4-4676-8003-e118286bf2e2	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-7.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có)	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.381666+00	2026-09-21 07:18:49.381666+00
74ec0583-d273-4aa5-bbb3-2bf0d6ab605b	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-8.jpg	anh	\N	Chụp thượng lương	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.383761+00	2026-09-21 07:18:49.383761+00
794901e5-7084-454e-a351-98a488af7bca	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-9.jpg	anh	\N	Mặt đứng, mặt bên công trình	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.386639+00	2026-09-21 07:18:49.386639+00
b714a77b-73f9-4499-afb5-6933ad7eb944	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — ảnh chi tiết đầu rồng được tái hiện lại trên mái nhà	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.391662+00	2026-09-21 07:18:49.391662+00
3048102f-a272-4ec8-8731-28507fe2334c	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-11.jpg	anh	\N	Hình ảnh hiên — ảnh từ bên ngoài	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.393774+00	2026-09-21 07:18:49.393774+00
4bd1c669-39e8-48d1-a3ff-b6dbeabad015	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-12.jpg	anh	\N	Hình ảnh hiên — ảnh từ trong ra	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.396644+00	2026-09-21 07:18:49.396644+00
78448400-f703-44f4-961d-99d32f3478f6	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-14.jpg	anh	\N	Nền (ảnh chụp) — vật liệu bâc hiên	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.400734+00	2026-09-21 07:18:49.400734+00
06f77efd-122e-46ec-8d72-c767753d5adb	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-15.jpg	anh	\N	Nền (ảnh chụp) — vật liệu nền trong nhà	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.40363+00	2026-09-21 07:18:49.40363+00
08f789a9-e5eb-42bd-a7be-4e71aeb51301	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-16.jpg	anh	\N	Nền (ảnh chụp) — ảnh vật liệu nền sân	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.405755+00	2026-09-21 07:18:49.405755+00
a320b3a0-009a-4442-a306-39e6c8a95866	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-17.pdf	ban_ve	\N	Sơ đồ mặt bằng — sơ đồ mặt bằng	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.408636+00	2026-09-21 07:18:49.408636+00
979edf17-3fbd-489a-a9f2-c9b442335def	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-18.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt và bộ vi	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.410759+00	2026-09-21 07:18:49.410759+00
204b5e6a-d933-45ff-be47-bb43abad3536	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-19.jpg	panorama	\N	Ảnh trong nhà — ảnh 360 trong nhà	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.413666+00	2026-09-21 07:18:49.413666+00
5a94e879-a2cb-41cb-b4c9-29d5392d325b	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-20.jpg	anh	\N	Kết cấu ảnh — ảnh kết cấu	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.418662+00	2026-09-21 07:18:49.418662+00
fdcc014a-7b56-49c7-affe-209a45fed381	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-21.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.420611+00	2026-09-21 07:18:49.420611+00
bc7fa07d-a96a-4802-b919-21a31086ec11	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-22.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.422722+00	2026-09-21 07:18:49.422722+00
3427a6f9-f23c-4911-9477-547104e48fb8	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-23.jpg	anh	\N	Kết cấu ảnh	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.425638+00	2026-09-21 07:18:49.425638+00
5ef0d4c2-8eee-4357-ba99-4ab16588c73f	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-24.jpg	anh	\N	Chân tảng ảnh — Chân tảng	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.427756+00	2026-09-21 07:18:49.427756+00
5e5286a0-fa29-47e3-924d-eab14d05bca1	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-3.jpg	anh	\N	Ảnh tổng thể từ cổng chính	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.430626+00	2026-09-21 07:18:49.430626+00
6fb77490-f1fa-4176-ab3d-4a9bba3279f1	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-4.pdf	ban_ve	\N	Tổng mặt bằng — TMB	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.432741+00	2026-09-21 07:18:49.432741+00
36945643-8217-4392-bc2e-10bbe19768bf	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-5.jpg	anh	\N	Chụp thượng lương — ảnh thượng lương	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.435653+00	2026-09-21 07:18:49.435653+00
ed8ff05e-61a7-4677-a1af-b8d3b7a4b597	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-6.jpg	anh	\N	Mặt đứng, mặt bên công trình — ảnh mặt đứng	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.437761+00	2026-09-21 07:18:49.437761+00
6ec46a2d-3f6f-41f9-9d21-237c8bd3885b	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-7.jpg	anh	\N	Ảnh các góc chính	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.440654+00	2026-09-21 07:18:49.440654+00
fdabc7c3-1c76-4b01-ba90-d436059e826d	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-8.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.442751+00	2026-09-21 07:18:49.442751+00
31d9f0af-efd2-48a7-bc70-cced84dd9e7e	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-9.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — ảnh hoạt cảnh đời sống con người được tái hiện lại	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.445652+00	2026-09-21 07:18:49.445652+00
6b97c874-7125-435b-9571-adf701b9261a	/lang-cuu/decorative/linh-vat-rong-phuong-lan-long-ma-nghe-rua-89ae3295-1.jpg	anh	\N	ảnh chi tiết bàn thờ tự có các linh vật	decorative_art_items	f4872c30-f539-426f-ad9e-63aa436decee	2026-09-21 07:18:49.448712+00	2026-09-21 07:18:49.448712+00
541bd004-8204-4385-8203-e5efc80cf42b	/lang-cuu/decorative/may-8da829fe-1.jpg	anh	\N	ảnh chi tiết mây quấn rồng	decorative_art_items	88b5ec3a-1ec3-45c8-8b8d-c50bfed20a5c	2026-09-21 07:18:49.452645+00	2026-09-21 07:18:49.452645+00
d516c04a-3855-4a76-8917-0e1478305dce	/lang-cuu/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-998509e2-1.jpg	anh	\N	ảnh chụp chi tiét cổng chính ( cây mai)	decorative_art_items	df18dcdb-5f56-428b-9510-7e1468e66ba2	2026-09-21 07:18:49.455707+00	2026-09-21 07:18:49.455707+00
0c892024-555a-4a90-8772-7c0e63f8f2c3	/lang-cuu/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-998509e2-2.jpg	anh	\N	ảnh hoa sen trên bàn thờ tự	decorative_art_items	df18dcdb-5f56-428b-9510-7e1468e66ba2	2026-09-21 07:18:49.458768+00	2026-09-21 07:18:49.458768+00
2abfe69e-e829-4467-8cd2-850dcbab4488	/lang-cuu/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-998509e2-3.jpg	anh	\N	ảnh hoa hồng ở sạp cúng bái	decorative_art_items	df18dcdb-5f56-428b-9510-7e1468e66ba2	2026-09-21 07:18:49.461629+00	2026-09-21 07:18:49.461629+00
384c95af-957f-444f-9ccf-5c1a811e4463	/lang-cuu/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-998509e2-4.jpg	anh	\N	ảnh đầy đủ của bàn thờ có các chi tiết cây	decorative_art_items	df18dcdb-5f56-428b-9510-7e1468e66ba2	2026-09-21 07:18:49.464683+00	2026-09-21 07:18:49.464683+00
6f58c490-64e6-4638-b5a7-50ff8944e708	/lang-cuu/decorative/linh-vat-rong-phuong-lan-long-ma-nghe-rua-eb186d6a-1.jpg	anh	\N	ảnh thờ tự có các linh vật	decorative_art_items	cae665ca-3c88-4952-9476-f360032beed8	2026-09-21 07:18:49.467743+00	2026-09-21 07:18:49.467743+00
6b34630a-1e84-483e-8f8f-06c633e185ad	/lang-cuu/decorative/long-quan-thuy-a469e054-1.jpg	anh	\N	\N	decorative_art_items	ee2eeb99-facd-4275-a3b8-cfecd7083fb4	2026-09-21 07:18:49.470775+00	2026-09-21 07:18:49.470775+00
986fb74b-95fe-4464-a372-59ec23d17338	/lang-cuu/decorative/may-5895fd7a-1.jpg	anh	\N	https://drive.google.com/file/d/1eSSJfynlQtkjeCxoIO_H3_Q4CmlCXDZx/view?usp=sharing	decorative_art_items	3577938d-cc41-4cbf-b344-63c13c38d009	2026-09-21 07:18:49.473641+00	2026-09-21 07:18:49.473641+00
9eba5ace-fd9d-4971-9d84-1d1c87bb1ac6	/lang-cuu/decorative/de-tai-cay-coi-tre-truc-tung-c1aa233e-1.jpg	anh	\N	\N	decorative_art_items	07ec5b69-8c4d-4dd1-8c82-e6945203333e	2026-09-21 07:18:49.476707+00	2026-09-21 07:18:49.476707+00
2bdcdc55-1f20-4193-9b26-f0a81af96d3d	/lang-cuu/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-a1834ac4-1.jpg	anh	\N	https://drive.google.com/file/d/1MOE1u5R_TBm8fkfyf0Xm4-LutUL3eWJY/view?usp=sharing	decorative_art_items	cfe82ca7-81b7-4e00-8d89-123674fd3157	2026-09-21 07:18:49.479748+00	2026-09-21 07:18:49.479748+00
f8b51d17-7b63-4510-a874-bd07b3796d90	/lang-cuu/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-73a8a9eb-1.jpg	anh	\N	\N	decorative_art_items	58260599-4fa5-4dcd-b6cc-44fc01437f4c	2026-09-21 07:18:49.48264+00	2026-09-21 07:18:49.48264+00
c0768ef1-26dd-4a6f-a2e9-2326bc5c60a2	/lang-cuu/decorative/may-572dfdd0-1.jpg	anh	\N	\N	decorative_art_items	a60091ee-6881-4bfb-8704-300ad3403d06	2026-09-21 07:18:49.485705+00	2026-09-21 07:18:49.485705+00
43522c19-a23b-46c4-a459-40040e551755	/lang-cuu/decorative/de-tai-cay-coi-tre-truc-tung-a08b9c2e-1.jpg	anh	\N	\N	decorative_art_items	f4fed6e7-b3bd-4f5c-9df7-c5b4ba440087	2026-09-21 07:18:49.488743+00	2026-09-21 07:18:49.488743+00
9d9767aa-3072-4459-84a8-7ccf453ae9e6	/lang-cuu/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-1b708e56-1.jpg	anh	\N	\N	decorative_art_items	f24a989c-63d5-4d3c-b7e0-135064750def	2026-09-21 07:18:49.491775+00	2026-09-21 07:18:49.491775+00
62311513-41bc-42d5-9266-375809495660	/lang-cuu/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-1136edae-1.jpg	anh	\N	ảnh hoành phi	decorative_art_items	c2eaf001-5794-4df4-b227-814c2500138f	2026-09-21 07:18:49.494673+00	2026-09-21 07:18:49.494673+00
e5838a2a-1b80-4bb9-a2e6-13455ee27185	/lang-cuu/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-1136edae-2.jpg	anh	\N	ảnh cửa võng	decorative_art_items	c2eaf001-5794-4df4-b227-814c2500138f	2026-09-21 07:18:49.497691+00	2026-09-21 07:18:49.497691+00
1037a2b4-48ba-443e-afc7-02600fb19df6	/lang-cuu/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-1136edae-3.jpg	anh	\N	ảnh y môn	decorative_art_items	c2eaf001-5794-4df4-b227-814c2500138f	2026-09-21 07:18:49.500757+00	2026-09-21 07:18:49.500757+00
1548a577-9c4c-40bd-b740-80399364ba44	/lang-cuu/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-1136edae-4.jpg	anh	\N	ảnh câu đối	decorative_art_items	c2eaf001-5794-4df4-b227-814c2500138f	2026-09-21 07:18:49.503799+00	2026-09-21 07:18:49.503799+00
f6d9b4b2-5c04-4778-8568-0e2fb54cfe81	/lang-cuu/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-d2cd2f6b-1.jpg	anh	\N	ảnh y môn	decorative_art_items	1428d990-d9c6-46d7-a77e-5ee37fbfef52	2026-09-21 07:18:49.506639+00	2026-09-21 07:18:49.506639+00
b4df5f6f-64fd-4051-bae1-d1208b774f63	/lang-cuu/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-d2cd2f6b-2.jpg	anh	\N	ảnh đỉnh đồng	decorative_art_items	1428d990-d9c6-46d7-a77e-5ee37fbfef52	2026-09-21 07:18:49.509705+00	2026-09-21 07:18:49.509705+00
05b482e7-4cdd-4cd8-8289-f81cac4d15db	/lang-cuu/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-d2cd2f6b-3.jpg	anh	\N	ảnh chân nến	decorative_art_items	1428d990-d9c6-46d7-a77e-5ee37fbfef52	2026-09-21 07:18:49.512743+00	2026-09-21 07:18:49.512743+00
d7f98f98-ca4a-4126-93ea-18e79bf1386a	/lang-cuu/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-d2cd2f6b-4.jpg	anh	\N	ảnh hạc chầu	decorative_art_items	1428d990-d9c6-46d7-a77e-5ee37fbfef52	2026-09-21 07:18:49.515781+00	2026-09-21 07:18:49.515781+00
ccbf6dc0-975e-4240-bc68-4ae6ff28a538	/lang-cuu/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-4ba9cfb4-1.jpg	anh	\N	ảnh ngai	decorative_art_items	285658bf-bcb3-4a1d-a28a-c10c6d166bb5	2026-09-21 07:18:49.518654+00	2026-09-21 07:18:49.518654+00
7c2a511a-7756-41fa-a3a6-104814e0f450	/lang-cuu/craft-products/complet-veston-doanh-nghiep-may-complet-veston-d-t-e9ad7af3-1.jpg	anh	\N	\N	craft_products	726a0782-41bc-4d11-bd84-36b5d042b15e	2026-09-21 07:18:49.52171+00	2026-09-21 07:18:49.52171+00
172bdf0a-d5e4-474a-9512-42de75d2276e	/lang-cuu/craft-products/complet-veston-hung-luyen-comple-veston-78223b9d-1.jpg	anh	\N	\N	craft_products	53c85b12-e2af-4d24-a6a4-6f41a57a371a	2026-09-21 07:18:49.524709+00	2026-09-21 07:18:49.524709+00
af6230a7-67cc-4a14-96e9-8e1ff4603bae	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — ảnh chụp chính diện công trình	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.638265+00	2026-09-21 07:18:49.638265+00
58164dd2-fe61-45ff-be70-c88da6e834cf	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-10.jpg	anh	\N	Nền (ảnh chụp) — ảnh nền	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.644757+00	2026-09-21 07:18:49.644757+00
4c22380e-577c-438a-8f12-6d962cbf9c1d	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-11.pdf	ban_ve	\N	Sơ đồ mặt bằng — sơ đồ mặt bằng	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.647821+00	2026-09-21 07:18:49.647821+00
1ad48632-1122-469a-83dc-63668868606a	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-12.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt và bộ vì kèo	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.650701+00	2026-09-21 07:18:49.650701+00
fe9e518c-3bf4-4cf3-8ed4-c753aee44eb7	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-13.jpg	anh	\N	Kết cấu ảnh — ảnh vì kèo	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.652686+00	2026-09-21 07:18:49.652686+00
24e9db07-2378-42be-a3bf-c5911b218179	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-14.jpg	anh	\N	Chân tảng ảnh — ảnh chân tảng	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.654693+00	2026-09-21 07:18:49.654693+00
cdd9a42f-45c4-4a24-a802-2e1dc166e859	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-2.jpg	anh	\N	Ảnh tổng thể từ cổng chính — ảnh chụp phối cảnh góc công trình	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.656671+00	2026-09-21 07:18:49.656671+00
4d5ebe8b-4c03-4745-be05-0fb5a3b0662f	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-3.pdf	ban_ve	\N	Tổng mặt bằng — ảnh tổng mặt bằng	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.658661+00	2026-09-21 07:18:49.658661+00
7b8c96b1-8255-4ddd-aa2a-f9ed6e161356	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-4.jpg	anh	\N	Chụp thượng lương — ảnh chụp thượng lương	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.660635+00	2026-09-21 07:18:49.660635+00
3a1e0d72-e90b-469d-8641-1f5008a6ca41	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-5.jpg	panorama	\N	Ảnh các góc chính — ảnh chụp 360 khuôn viên công trình	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.662649+00	2026-09-21 07:18:49.662649+00
4f531126-b029-49f0-966c-c92281607914	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-6.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — ảnh chụp chi tiết đầu hiên	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.665742+00	2026-09-21 07:18:49.665742+00
b50d76df-7890-4c01-af4a-24104862bb00	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-7.jpg	anh	\N	Mái_cấu tạo — ảnh chính diện mái	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.668633+00	2026-09-21 07:18:49.668633+00
dc7b81e3-69b4-4edb-89cc-45167b1d7695	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-8.jpg	anh	\N	Mái_cấu tạo — ảnh tổng thể mái	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.67075+00	2026-09-21 07:18:49.67075+00
24a28fb2-9271-4b49-9693-7326c4c50594	/lang-chuong/heritage-buildings/nha-ong-le-van-truong-d1ca37e2-9.jpg	anh	\N	Hình ảnh hiên	heritage_buildings	28dc7a86-a741-4fd7-9407-454b6af79bb4	2026-09-21 07:18:49.673638+00	2026-09-21 07:18:49.673638+00
449c9404-22ff-4d9d-b756-f682fd9ab108	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — ảnh tổng thể cổng chính	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.675743+00	2026-09-21 07:18:49.675743+00
c553007e-2af3-4d2f-a014-eb9c4bbd7d17	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-10.jpg	anh	\N	Nền (ảnh chụp) — ảnh chụp nền công trình	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.678646+00	2026-09-21 07:18:49.678646+00
1eeb32f3-38df-4cce-8e20-2f20a4dbff02	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-11.pdf	ban_ve	\N	Sơ đồ mặt bằng — sơ đồ mặt bằng	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.68073+00	2026-09-21 07:18:49.68073+00
6427924b-4638-4c36-a15c-d24e0f588ae0	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-12.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — sơ đồ mặt cắt và vì kèo	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.683619+00	2026-09-21 07:18:49.683619+00
6e890cc2-7a83-48a4-ae45-ab64eba32fea	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-13.jpg	anh	\N	Kết cấu tính chất	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.685731+00	2026-09-21 07:18:49.685731+00
5875289c-a720-4340-93d5-6d59fee6ccbb	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-2.pdf	ban_ve	\N	Tổng mặt bằng — ảnh tổng mặt bằng	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.68863+00	2026-09-21 07:18:49.68863+00
a3803112-14e9-4978-9358-dfca2e225721	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-4.jpg	anh	\N	Mặt đứng, mặt bên công trình — ảnh chụp công trình	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.690742+00	2026-09-21 07:18:49.690742+00
7c677e97-4617-4345-b2d7-cd052ddbd41e	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-5.jpg	anh	\N	Mặt đứng, mặt bên công trình — ảnh chụp chính diện công trình	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.693622+00	2026-09-21 07:18:49.693622+00
989bf9b2-3286-45cc-b58c-f425000ebc33	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-6.jpg	panorama	\N	Ảnh các góc chính — ảnh 360 chính diện khuôn viên công trình	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.695739+00	2026-09-21 07:18:49.695739+00
4a4e61fd-17b8-4289-b0f8-3a76713b93bd	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-7.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — ảnh chụp chi tiết đầu đao	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.698646+00	2026-09-21 07:18:49.698646+00
f79a5154-24a6-4e22-a25a-e2ed45099db4	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-8.jpg	anh	\N	Mái_vật liệu — ảnh chụp chính diện cấu tạo mái	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.70075+00	2026-09-21 07:18:49.70075+00
fd5c0c1a-fdd4-4e02-8365-7794b9e43f53	/lang-chuong/heritage-buildings/den-thuong-a5d82e99-9.jpg	anh	\N	Hình ảnh hiên — ảnh hiên công trình	heritage_buildings	821ce853-ea6d-4a82-a68f-c9f22e4a2014	2026-09-21 07:18:49.703652+00	2026-09-21 07:18:49.703652+00
8645abcc-0537-4801-a3a4-260cdd14c542	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — ảnh tổng thể	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.705745+00	2026-09-21 07:18:49.705745+00
d12bd2f4-4036-4f85-85ff-3c4b8bfe27c5	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-10.jpg	anh	\N	hình ảnh hiên — ảnh dọc theo hiên	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.708636+00	2026-09-21 07:18:49.708636+00
64ee9de5-0399-4971-ba4f-e6bebd410b03	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-11.jpg	anh	\N	Nền (ảnh chụp) — ảnh chụp nền	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.710735+00	2026-09-21 07:18:49.710735+00
1c04834c-ae1b-4fec-a24e-dc6b9fcfad52	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-12.pdf	ban_ve	\N	Sơ đồ mặt bằng — măt bằng	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.713624+00	2026-09-21 07:18:49.713624+00
4d964452-2cf3-4697-9880-187642351ce6	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-13.pdf	ban_ve	\N	Sơ đồ mặt cắt và bộ vì — mặt cắt	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.715744+00	2026-09-21 07:18:49.715744+00
df1b203f-c4a3-4f14-bd79-3c4a8e08a6f9	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-14.jpg	panorama	\N	Ảnh trong nhà — ảnh 360 trong nhà	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.718633+00	2026-09-21 07:18:49.718633+00
00654f5c-ff64-40e3-9f88-a2692e7e4130	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-15.jpg	anh	\N	Kết cấu ảnh — ảnh vì kèo mái	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.720742+00	2026-09-21 07:18:49.720742+00
47768281-260d-475b-8c36-e3706fe156a2	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-16.jpg	anh	\N	Kết cấu ảnh — ảnh chụp cận vì kèo	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.723627+00	2026-09-21 07:18:49.723627+00
a069f860-0cf9-4d35-8259-01345a166fe5	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-17.jpg	anh	\N	Chân tảng ảnh — ảnh chân tảng	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.725735+00	2026-09-21 07:18:49.725735+00
7ae3f500-7094-4dab-a585-dc6ee4a1c04b	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-2.pdf	ban_ve	\N	Tổng mặt bằng — ảnh tổng mặt bằng	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.72863+00	2026-09-21 07:18:49.72863+00
5cca1edc-9b04-4b93-bc53-c5ccde01c474	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-3.jpg	panorama	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — ảnh 360	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.73073+00	2026-09-21 07:18:49.73073+00
b03569dc-b0f1-4455-a295-ab95695ed9bc	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-5.jpg	anh	\N	Mặt đứng, mặt bên công trình — ảnh chụp mặt đứng công trình	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.735737+00	2026-09-21 07:18:49.735737+00
36f1360f-9b9d-4328-984e-9bb429054a0d	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-6.jpg	panorama	\N	Ảnh các góc chính — ảnh 360 khuôn viên công trình	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.738659+00	2026-09-21 07:18:49.738659+00
02f42633-1e6c-4bb0-96c1-d2c61e01f713	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-7.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — chi tiết đầu đao	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.74078+00	2026-09-21 07:18:49.74078+00
8d12f39c-cd01-49ea-b329-835a0991099a	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-8.jpg	anh	\N	Mái_cấu tạo — ảnh chụp mái công trình	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.743629+00	2026-09-21 07:18:49.743629+00
a7bf2050-ad3b-4419-9bc4-78caf0cd917e	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-9.jpg	anh	\N	hình ảnh hiên — ảnh từ trong ra	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.745746+00	2026-09-21 07:18:49.745746+00
a936ff04-e0b4-48f3-95a1-43b105ac2108	/lang-chuong/decorative/linh-vat-rong-phuong-lan-long-ma-nghe-rua-5db2dd96-1.jpg	anh	\N	ảnh rồng được điêu khắc trên hương án	decorative_art_items	cc7b8b83-06cd-481c-8156-e641b684f363	2026-09-21 07:18:49.748664+00	2026-09-21 07:18:49.748664+00
d8f509d9-aaff-4d45-a576-ab3abe579a1f	/lang-chuong/decorative/may-fa43f669-1.jpg	anh	\N	ảnh mây điêu khắc trên gỗ	decorative_art_items	e555dfb3-0fde-433d-b566-71b3b2d5a5cd	2026-09-21 07:18:49.752734+00	2026-09-21 07:18:49.752734+00
a8471644-2922-479b-9455-d3f73472b503	/lang-chuong/decorative/de-tai-hoa-qua-mau-don-hong-cuc-dao-luu-40e6e4fa-1.jpg	anh	\N	ảnh ngũ quả được điêu khắc ở vì kèo hiên	decorative_art_items	deedde9a-d4ac-41f3-8040-1f4502f13c4a	2026-09-21 07:18:49.755763+00	2026-09-21 07:18:49.755763+00
32aa4229-eaa4-4bba-839a-aa2a0d61301e	/lang-chuong/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-7f877366-1.jpg	anh	\N	ảnh chụp câu đối	decorative_art_items	4f9f8d25-8325-4f8f-9871-7f50be582d9c	2026-09-21 07:18:49.758665+00	2026-09-21 07:18:49.758665+00
6634e4b2-b517-4580-920d-2dcc84de75d2	/lang-chuong/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-7f877366-2.jpg	anh	\N	ảnh chụp câu đối	decorative_art_items	4f9f8d25-8325-4f8f-9871-7f50be582d9c	2026-09-21 07:18:49.761707+00	2026-09-21 07:18:49.761707+00
3a753b8d-01a5-4a9d-9a3d-60ba111a0708	/lang-chuong/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-7f877366-3.jpg	anh	\N	ảnh chụp hoành phi	decorative_art_items	4f9f8d25-8325-4f8f-9871-7f50be582d9c	2026-09-21 07:18:49.764737+00	2026-09-21 07:18:49.764737+00
2f66dc4b-c1a3-4137-ab0c-5b4d124a39dd	/lang-chuong/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-df378ea3-1.jpg	anh	\N	ảnh chụp tổng thể đồ thờ tự	decorative_art_items	91e0ec46-b80e-4734-ba6f-c8b041ca9a69	2026-09-21 07:18:49.767769+00	2026-09-21 07:18:49.767769+00
e9badef2-9296-4347-8226-c251ee1e8336	/lang-chuong/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-21b41f67-1.jpg	anh	\N	ảnh chụp hương án	decorative_art_items	a4664fee-2c27-46b8-9289-e296cff2c855	2026-09-21 07:18:49.770669+00	2026-09-21 07:18:49.770669+00
71365f37-b898-4f27-bbe3-16362ad62e8b	/lang-chuong/decorative/bieu-tuong-thieng-va-bieu-tuong-ton-giao-e9897981-1.jpg	anh	\N	ảnh bà voi	decorative_art_items	96179b07-2001-435d-8f03-1aacea2dc381	2026-09-21 07:18:49.773728+00	2026-09-21 07:18:49.773728+00
06dbde17-c7c5-434e-9e3a-a67988f06b9e	/lang-chuong/decorative/bieu-tuong-thieng-va-bieu-tuong-ton-giao-e9897981-2.jpg	anh	\N	ảnh ông voi	decorative_art_items	96179b07-2001-435d-8f03-1aacea2dc381	2026-09-21 07:18:49.776736+00	2026-09-21 07:18:49.776736+00
284387c5-b3a8-4213-898b-cc7d89cef928	/lang-chuong/decorative/long-quan-thuy-f44d00fc-1.jpg	anh	\N	ảnh rồng quấn mây	decorative_art_items	fc9f005f-2db3-4129-adc7-f2c6bfb6d0fc	2026-09-21 07:18:49.779612+00	2026-09-21 07:18:49.779612+00
72ba3265-5a30-4aa8-b289-a4a6c0287819	/lang-chuong/decorative/may-f54776cb-1.jpg	anh	\N	ảnh mây được khắc họa trên tường	decorative_art_items	0a438f42-1343-4849-97a1-08c7979d6750	2026-09-21 07:18:49.781731+00	2026-09-21 07:18:49.781731+00
5ad16a0f-e8e4-4e20-aa2b-5fa416cdda1c	/lang-chuong/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-8a60c130-1.jpg	anh	\N	ảnh câu đối	decorative_art_items	9d234bb9-2630-41ee-86c8-9333a7cd607f	2026-09-21 07:18:49.78463+00	2026-09-21 07:18:49.78463+00
d2158cea-fbc5-448d-bf5a-92192c2b1d7f	/lang-chuong/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-face3097-1.jpg	anh	\N	ảnh bát hương, đài	decorative_art_items	46ff5e4e-f05a-4eb6-96c9-d782fbbe4064	2026-09-21 07:18:49.787694+00	2026-09-21 07:18:49.787694+00
bec42a17-79b0-4a33-92ae-bbb55232af64	/lang-chuong/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-8addac9f-1.jpg	anh	\N	ảnh hương án	decorative_art_items	c50d1f17-2cb0-41ab-bfaa-05e1a318b909	2026-09-21 07:18:49.790731+00	2026-09-21 07:18:49.790731+00
5bed40b1-bc8c-42f7-be74-0cb040fe9cea	/lang-chuong/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-5856bdb6-1.jpg	anh	\N	ảnh ngựa được chmja khắc trên tường	decorative_art_items	df87cd2a-f9c6-48f9-adcc-5859bd058d53	2026-09-21 07:18:49.793752+00	2026-09-21 07:18:49.793752+00
771b0bfb-fa4b-49a5-8ce3-b73dbd1cfc57	/lang-chuong/decorative/may-867183ee-1.jpg	anh	\N	ảnh chụp điêu khắc mây	decorative_art_items	6cbe0eb7-3065-4664-8572-80ee2c6a87f9	2026-09-21 07:18:49.796639+00	2026-09-21 07:18:49.796639+00
46094750-af33-4508-9bce-9b2a27bcc945	/lang-chuong/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-1ab4ca76-1.jpg	anh	\N	ảnh chụp cửa võng	decorative_art_items	d2eeaf0f-5b2a-4870-822f-e55e15692493	2026-09-21 07:18:49.798807+00	2026-09-21 07:18:49.798807+00
26d0017a-5191-477d-ac5e-deb690a4122e	/lang-chuong/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-b4b7be4f-1.jpg	anh	\N	ảnh chụp bài vị	decorative_art_items	af053486-f75b-4e71-ad1e-2c99e65a1b8a	2026-09-21 07:18:49.801647+00	2026-09-21 07:18:49.801647+00
47b5b02b-5730-4d68-9ba5-faa13b709e36	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — https://drive.google.com/file/d/1GSevipoQQzdY_0IxwrBMzdW8zIzerXj3/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.922169+00	2026-09-21 07:18:49.922169+00
b3829e79-548e-402b-877b-a5cb2d66e123	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1noxOu-PBddXS2A_hLWJ3EMIvICPKbo_y/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.928824+00	2026-09-21 07:18:49.928824+00
1f563727-0b25-4296-a849-583963a899e4	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-11.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1KI4TplOk201D4SaLfihm41rEF3XXMubF/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.931854+00	2026-09-21 07:18:49.931854+00
c6cc5fdc-db8a-451a-820b-37998650ffbd	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-12.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/19BGYsclU_SgUjOfTug7k2TxiFbwSC1BJ/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.934753+00	2026-09-21 07:18:49.934753+00
8c4dd60b-e181-439f-85de-cbd1923f3185	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-13.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1tE_cnnkWxY7hU3d_jnjVv7gH-zG_ML4K/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.93791+00	2026-09-21 07:18:49.93791+00
aded067f-2d7d-495e-b623-338ef2aab363	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-14.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1CEeeruSKE24bKnigMoeFn-C-8-NfcBZ-/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.940834+00	2026-09-21 07:18:49.940834+00
29f31fd7-99ca-4611-99a9-bb28c8919c53	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-15.jpg	anh	\N	Mái_vật liệu — https://drive.google.com/file/d/1cqfwSbhIFmYrwltDAufxjaByjI6v4evB/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.943643+00	2026-09-21 07:18:49.943643+00
23d72743-4f4a-4f8d-8032-f4681d7f1f6e	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-16.jpg	anh	\N	Hình ảnh hiên — https://drive.google.com/file/d/1wYae9TH8259NvknaM8eUcQYyOmLsMEN1/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.945821+00	2026-09-21 07:18:49.945821+00
702952e2-c218-46ce-a88d-68744c5dbc9a	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-17.jpg	anh	\N	Hiên tam cấp ngưỡng cửa — https://drive.google.com/file/d/1Y96zCyNCIwQkBXxvmt_LoY5IfP2rdF30/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.948681+00	2026-09-21 07:18:49.948681+00
4bceb946-d4b4-423b-96a5-7f11ff67c667	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-18.jpg	anh	\N	Nền (ảnh chụp) — https://drive.google.com/file/d/12itWcRjIi3L-huUinVVEGJbYBaDq-6jv/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.949694+00	2026-09-21 07:18:49.949694+00
77cbe526-393c-4a99-b3e2-406b5681a0d9	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-19.pdf	ban_ve	\N	Sơ đồ mặt bằng — https://drive.google.com/file/d/1qeyQPBTn4Qa74_3Dt4gCbjekxGK0kCjZ/view?usp=drive_link	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.951649+00	2026-09-21 07:18:49.951649+00
715caeaa-3bea-42e0-aa6c-550b510ceeec	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-2.pdf	ban_ve	\N	Tổng mặt bằng — https://drive.google.com/file/d/1D2RQHtfY4sTQjrf73txOy1qiB62hU-8k/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.953621+00	2026-09-21 07:18:49.953621+00
3bfb298b-c2bd-4e1c-937d-39249261fe3f	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-20.pdf	ban_ve	\N	Sơ đồ kết cấu — https://drive.google.com/file/d/1CA_tsVE5MEpOXmGue8y0VjBu5aycdkHy/view?usp=drive_link	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.955748+00	2026-09-21 07:18:49.955748+00
cdd42210-e738-4e52-9c35-09c64f52837e	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-21.jpg	anh	\N	Ảnh trong nhà — https://drive.google.com/file/d/1ggYYJU-ovTHsO26i2nlRfgFX2dq10Khm/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.958627+00	2026-09-21 07:18:49.958627+00
58571f56-547b-48ae-9de7-a77cdfcb14b4	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-22.jpg	anh	\N	Kết cấu vật liệu — https://drive.google.com/file/d/1qR9PdQthAcaz387u7gMQQA3jv6qsF8sJ/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.960746+00	2026-09-21 07:18:49.960746+00
258cb4ba-3423-48a8-98ba-8b5d3d8730d1	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-23.jpg	anh	\N	Kết cấu tính chất — https://drive.google.com/file/d/1ZzdV5-6lHqdilrHPHUGez-JhCMPlKVN9/view?usp=drive_link	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.96364+00	2026-09-21 07:18:49.96364+00
938bdda4-58d2-428f-a809-1030659e9356	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-24.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/139efURUL3DA7rjA7iGAlKfGAeMALeq5t/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.965752+00	2026-09-21 07:18:49.965752+00
c2902f17-2703-4b60-b257-bdb219b55b44	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-25.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1z7Ym3e-mrKOmNulzsyq369PDy60HgTrV/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.968636+00	2026-09-21 07:18:49.968636+00
e19b4f8d-1097-4aa0-baca-b0c83328b723	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-26.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1CbqRnxFFHNcmDS0c3l-LjzPkNJD9ClKa/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.970747+00	2026-09-21 07:18:49.970747+00
2a4d0f6b-98f5-4441-ba12-e1a93ec3408c	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-27.jpg	anh	\N	Chân tảng ảnh — https://drive.google.com/file/d/1a5L7LWeqGxcw_MbMWDjlr-73daNcxmwu/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.973629+00	2026-09-21 07:18:49.973629+00
97642886-a741-408c-8eb9-013e771366e0	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-3.jpg	anh	\N	Các đối tượng phụ trợ — https://drive.google.com/file/d/10bgS16qp_DD3s0GtVRJ-aaiTsSvxzpaI/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.975755+00	2026-09-21 07:18:49.975755+00
adbf8be2-3afd-4f01-90ee-65cf37b869ec	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-4.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — https://drive.google.com/file/d/1QVJE6zLQNy5kbGwejG1wrqbVgf1tA_xr/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.978647+00	2026-09-21 07:18:49.978647+00
9f11e4dd-8287-4fd3-9b54-656573464e42	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-5.jpg	anh	\N	Mặt đứng, mặt bên công trình — https://drive.google.com/file/d/1OJ73aL3VC1xyiqGwv4BSfAtq5R5lGtSL/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.980602+00	2026-09-21 07:18:49.980602+00
5ab1c2c4-2c15-4daa-a08d-f6d224f3883d	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-6.jpg	anh	\N	Ảnh các góc chính — https://drive.google.com/file/d/1CZNsjVA3igLY5oYJTX-tcTT7iztIjsqC/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.982723+00	2026-09-21 07:18:49.982723+00
f24a0991-c3ef-4b9d-bee5-1e34cd2ec334	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-7.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/17rYUt0EYgQRsBcD2YbmGNqvhCh3L5fyy/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.984663+00	2026-09-21 07:18:49.984663+00
07147283-5326-4223-a6a1-08d9f4942ccb	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-8.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1bEqyDHcd3zBUxoAOviJkYR8na6y3kje8/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.986602+00	2026-09-21 07:18:49.986602+00
35669daf-7989-4c37-be9d-0f5166f72675	/phu-vinh/heritage-buildings/nha-co-ong-nguyen-huu-bat-8300ffc9-9.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1u52FGHsjWbbWL7Bs4G-bjGtiRCvTiMFg/view?usp=sharing	heritage_buildings	32db5b3c-354d-4b2f-a87c-e04fe72228c2	2026-09-21 07:18:49.988763+00	2026-09-21 07:18:49.988763+00
0b01d9d5-bba6-4d93-a1d8-c616ff7836ea	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — https://drive.google.com/file/d/1KuwjaOyW0Fyr1oiKb8CFi3sQ5wHyFM1l/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:49.991642+00	2026-09-21 07:18:49.991642+00
a401746b-3437-4236-8d0a-205898fb3563	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/138hApDFzR36PDrcOzl_bHIom7rbyaQ-y/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:49.993743+00	2026-09-21 07:18:49.993743+00
c95c3f26-6126-48c2-b73c-705c7587e5a5	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-11.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1S3KITEyuXGagwQrXPAxQwF-BukX1dBav/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:49.996636+00	2026-09-21 07:18:49.996636+00
d4c8f05c-2b89-482c-a906-984bf8585ba3	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-12.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1cOButhe8UoRzO01rEOFGpLb9BiM7fmQN/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:49.998768+00	2026-09-21 07:18:49.998768+00
3bf7addb-c6c2-412b-98d9-ccc03e716da7	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-13.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1gCDzmo1HIrU7FBWYQyXX5lRrj8j-HkJj/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.001644+00	2026-09-21 07:18:50.001644+00
84268ab8-98e2-4cb9-a4a9-fb74483bbdd1	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-14.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1QzDRtrPKZito-WQtI0JE-LublYPKqP1a/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.003751+00	2026-09-21 07:18:50.003751+00
bca7bc52-09e0-4951-a764-933f49fc44f2	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-15.jpg	anh	\N	Hình dạng mái — https://drive.google.com/file/d/1Khio265pbFL9a5MFfQiztasJVYXq28EN/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.006627+00	2026-09-21 07:18:50.006627+00
dd0f6ce9-a3ed-4ce3-9703-3e057c3e6308	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-16.jpg	anh	\N	Mái_vật liệu — https://drive.google.com/file/d/1ItESrYcC8uWwL2b3nT37R9ntSoC6d6fa/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.008588+00	2026-09-21 07:18:50.008588+00
edb14552-fe2b-455a-9f3b-0c890035a3c4	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-17.jpg	anh	\N	Hình ảnh hiên — https://drive.google.com/file/d/13zONIWJQNfXwFdUrFF3RjM_kyyXvAw24/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.010724+00	2026-09-21 07:18:50.010724+00
410b44a0-6b7b-4358-bfcd-51989abe7f55	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-18.jpg	anh	\N	Nền (ảnh chụp) — https://drive.google.com/file/d/1w2ifbukI63OARipCrKuxaY4_fIYTjIpa/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.012668+00	2026-09-21 07:18:50.012668+00
cbb023bb-310e-4034-ace2-c8c3795d0d33	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-19.pdf	ban_ve	\N	Sơ đồ mặt bằng — https://drive.google.com/file/d/13vKA68gOXqi705TVy_iGjUrASaUMKmbx/view?usp=drive_link	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.014612+00	2026-09-21 07:18:50.014612+00
709150b8-ba5c-4ad2-8b47-2a3909c68312	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-2.pdf	ban_ve	\N	Tổng mặt bằng — https://drive.google.com/file/d/1NDLb5_kH7EB3mkDpZc3yMSL1_vSf1Gaz/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.016733+00	2026-09-21 07:18:50.016733+00
8935f554-d0d3-45ea-aa34-61d82670eceb	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-20.pdf	ban_ve	\N	Sơ đồ kết cấu — https://drive.google.com/file/d/1_bfxMgmCGU3P3Z5zw6b9AuIpPmbxaqgJ/view?usp=drive_link	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.018691+00	2026-09-21 07:18:50.018691+00
dbee7ae4-2757-41a1-b657-5a3dbcea5dbc	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-21.jpg	anh	\N	Ảnh trong nhà — https://drive.google.com/file/d/1_p2-ndotQBLe8BPwYbfa1zu1T8pPR2yu/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.020636+00	2026-09-21 07:18:50.020636+00
8b6ff857-d1f2-4f61-ba1e-673406d71802	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-22.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1ewyATCsMabzV_fkFTHIFj5pUcZUaU4HM/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.022593+00	2026-09-21 07:18:50.022593+00
7dce43bf-9d7c-48ee-906e-cafdf6a9d6bc	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-23.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1sg4wgOs2sFK79_eBh2dyLAf_w54GF_E6/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.024755+00	2026-09-21 07:18:50.024755+00
f916ac36-8f78-413d-8491-6e90f6b122e1	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-24.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1wnxdUKKHIqF-fA_PygUl0QS6N4hTnPJE/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.027607+00	2026-09-21 07:18:50.027607+00
e2f9579b-7eac-4222-84c3-73a1fa483b52	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-25.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1FhQULb1ZttpsTXuRiZi5Z2e7RWE-wohg/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.02974+00	2026-09-21 07:18:50.02974+00
fda58c45-181b-4f6e-9acf-a350ec55e6f0	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-26.jpg	anh	\N	Chân tảng ảnh — https://drive.google.com/file/d/1UNon-FLAhphjf_nJPMqNrS6YPgYhJKBO/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.031692+00	2026-09-21 07:18:50.031692+00
d89d19ee-6703-42e2-bc32-731f7e123378	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-3.jpg	anh	\N	Chức năng các công trình trong tổng thể — https://drive.google.com/file/d/1uUDTdruQ7HldAKpCmpAnprbzipVIyfvx/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.03365+00	2026-09-21 07:18:50.03365+00
7652cca3-03a8-4ff0-a3b8-515cb4a2a3ef	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-4.jpg	anh	\N	Chức năng các công trình trong tổng thể — https://drive.google.com/file/d/11OQ0hl7u-HCKFqJddv0AUAxr0reGY0L0/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.035602+00	2026-09-21 07:18:50.035602+00
c8939895-113e-42e0-a38c-1ea1f0ff0ef9	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-5.jpg	anh	\N	Chức năng các công trình trong tổng thể — https://drive.google.com/file/d/18v7sXb2DBM5-7lAnKByO4yxBgD7S9e50/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.037756+00	2026-09-21 07:18:50.037756+00
d1aac9eb-208b-417d-9feb-ab463b432c60	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-6.jpg	anh	\N	Chức năng các công trình trong tổng thể — https://drive.google.com/file/d/1YA3OTurmPg1sDFjNIdWaw9eGvjN7Xz6K/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.040612+00	2026-09-21 07:18:50.040612+00
39f39e1a-37ea-4995-9c89-49b9c58f4746	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-7.jpg	anh	\N	Chụp thượng lương — https://drive.google.com/file/d/18-72gtnBynkAL3lNh2w5eujHYw4FNvQo/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.042589+00	2026-09-21 07:18:50.042589+00
c28dc12d-a2d7-4f2f-a06c-233cb556ce4e	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-8.jpg	anh	\N	Mặt đứng, mặt bên công trình — https://drive.google.com/file/d/1eIC_KK6EW1Zk4RfgyBjhUBMMjYmUREP3/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.044727+00	2026-09-21 07:18:50.044727+00
d48ccaa0-7169-4eae-80a3-4cdca48c3095	/phu-vinh/heritage-buildings/nha-nghe-nhan-hoang-hanh-b7b5c87b-9.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1kfgMb7AUuJf_tAhjDuQ525LpbAYfrl2I/view?usp=sharing	heritage_buildings	309af77b-1057-4d24-90ea-c37e69be4979	2026-09-21 07:18:50.047634+00	2026-09-21 07:18:50.047634+00
344de295-6a17-4e54-a192-5c6453f6c80d	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — https://drive.google.com/file/d/1ADgsM6hspurA1AXSXYFYxou2M7KWNrqG/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.049727+00	2026-09-21 07:18:50.049727+00
810f5edb-1051-4b6b-99e5-9644d87af76e	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-10.jpg	anh	\N	Hình ảnh hiên — https://drive.google.com/file/d/1eU46rcs85AFDxdPILfSfdyBhp3-mkPSz/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.05167+00	2026-09-21 07:18:50.05167+00
76b9ac4b-c237-4158-8d81-c42b5041f184	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-11.jpg	anh	\N	Vị trí hiên — https://drive.google.com/file/d/120_WLdbEeI2zRFt7WFcvp40uHVnQAqRU/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.053632+00	2026-09-21 07:18:50.053632+00
1aa7489f-29ba-4104-9a7a-a1d5d3b70a45	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-12.jpg	anh	\N	Nền (ảnh chụp) — https://drive.google.com/file/d/1ZM6uKIElshia4uoTRwHmHQ8am4D0PTXI/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.055595+00	2026-09-21 07:18:50.055595+00
75d7f641-8cc8-499b-9ebd-3ca2f558f209	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-13.pdf	ban_ve	\N	Sơ đồ mặt bằng — https://drive.google.com/file/d/18CVdupMZMBAKw_BZU4XL85u3rCW76Or7/view?usp=drive_link	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.057719+00	2026-09-21 07:18:50.057719+00
caf2a4e5-0122-4558-b8cf-9bf5522a5b6f	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-14.pdf	ban_ve	\N	Sơ đồ kết cấu — https://drive.google.com/file/d/1yHyU_TCyWQBo0iMRRgx-2qrVmR3ZoSBn/view?usp=drive_link	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.060609+00	2026-09-21 07:18:50.060609+00
6a9806cb-02a3-4164-bb6c-b51b4444999c	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-15.jpg	anh	\N	Ảnh trong nhà — https://drive.google.com/file/d/1Lkn9rSjfnR5bmqqYnyWst61uL6Fs2N0Z/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.062727+00	2026-09-21 07:18:50.062727+00
a57e89cf-366c-4a1e-a5b9-6d50fb631c29	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-16.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1XXEX3KEYr6U4Ji5mDtE5cWw7Dtaawz6Y/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.064676+00	2026-09-21 07:18:50.064676+00
4a3076f5-5178-4c8d-aa14-7e6398c85757	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-17.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1DZNdvTn8kno--xSzlUo-AvL9ZOiMI9RX/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.066626+00	2026-09-21 07:18:50.066626+00
1359ffa1-8f5b-401d-b270-47742448885b	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-18.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1xuX6Xfyp6XeVwYIMxFZWmFrShioVk9DR/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.068579+00	2026-09-21 07:18:50.068579+00
1c79ff1b-b1db-4b23-b2ff-18740cca18a6	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-19.jpg	anh	\N	Chân tảng ảnh — https://drive.google.com/file/d/14CdUuEwDXkClyiGSVTAHzC7FXQIylsOX/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.070717+00	2026-09-21 07:18:50.070717+00
0331cf5d-a70c-4c1a-b4bb-e7315b586ff9	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-2.pdf	ban_ve	\N	Tổng mặt bằng — https://drive.google.com/file/d/1Vb9WJ77ERFNDwQGaAZG2YTLCRBQGIZ00/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.073599+00	2026-09-21 07:18:50.073599+00
5f4cbe13-d5ed-4eee-a05a-3a9a4d3d54d2	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-3.jpg	anh	\N	Mặt đứng, mặt bên công trình — https://drive.google.com/file/d/1KOox9w1JwbQCiO0wSMTQ2zWriW8Q6upH/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.075743+00	2026-09-21 07:18:50.075743+00
c25eb658-1d47-4367-86cc-2d4a8485fdfe	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-4.jpg	anh	\N	Ảnh các góc chính — https://drive.google.com/file/d/13_KmUpuGP3ygAKOizHt0TYYyqv21PCZF/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.077683+00	2026-09-21 07:18:50.077683+00
d143381a-1b7f-45a2-a443-0ad8974fcf4a	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-5.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1r_BBvsIqax83lavEUngL1mEvg2hnPJmM/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.079641+00	2026-09-21 07:18:50.079641+00
8d710f1a-1573-4671-978c-4ab2e9cf3f8b	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-6.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1dLeLTlcJhHUx0zpRsWdwdk8oIinNthXR/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.081601+00	2026-09-21 07:18:50.081601+00
78a98a47-48a3-4579-92fc-4d7533e29f9d	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-7.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1ubn04zCWeFK0vKhxP-HQujMkyiYI09Yg/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.083737+00	2026-09-21 07:18:50.083737+00
64f801f4-c52d-43d0-b3c2-81dc6edc37fd	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-8.jpg	anh	\N	Mái_vật liệu — https://drive.google.com/file/d/15_m2l75LBXz-7GXUEC0Nps9go_fdZhxD/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.086619+00	2026-09-21 07:18:50.086619+00
724f4440-a92b-4b0a-9c16-18b9d6e93710	/phu-vinh/heritage-buildings/nha-ong-nguyen-huu-ki-e447dc56-9.jpg	anh	\N	Mái_cấu tạo — https://drive.google.com/file/d/1B2LyJ9A7XnqGwgk9w6VOn6uQogSsxopw/view?usp=sharing	heritage_buildings	b0cc3513-c04e-423c-912b-b5653534ffdf	2026-09-21 07:18:50.088586+00	2026-09-21 07:18:50.088586+00
6d3aa676-450d-41b5-9538-6cb218025081	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-1.jpg	anh	\N	Ảnh tổng thể từ cổng chính — https://drive.google.com/file/d/1w7wUiubR3JCSvXrNwKQ-DRn0EX_MZbsF/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.090714+00	2026-09-21 07:18:50.090714+00
2fe5fdc7-13e4-4dc2-a43c-2b9d568afff3	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-10.jpg	anh	\N	Mặt đứng, mặt bên công trình — https://drive.google.com/file/d/1liF7GG5h3-yqDcrj8KB8v87uyzQx4D74/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.092679+00	2026-09-21 07:18:50.092679+00
a4537d6a-97e4-4a50-84f1-1ec9e1962782	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-11.jpg	anh	\N	Mặt đứng, mặt bên công trình — https://drive.google.com/file/d/1Gr9-t5xjyX1Wrq0F5hFeGlJsdzuCtbkE/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.094626+00	2026-09-21 07:18:50.094626+00
707a025a-06f8-4164-bb01-78c69bf13166	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-12.jpg	anh	\N	Vỏ công trình (màu sắc) — https://drive.google.com/file/d/1O5ovhPAtCOypHBVREg7eNGmwacUOELtR/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.096598+00	2026-09-21 07:18:50.096598+00
a53c04bf-8e62-4a6b-bda3-52cea8a00877	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-13.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1WPrVLwOssS-f7UfVwZh3qfh8InUUdVFU/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.098738+00	2026-09-21 07:18:50.098738+00
ac48e486-7ba8-449f-a8a3-3f3583ffa886	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-14.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1m0BQHYjnB88Q2ZQRbTBJoMjB15_SNWgJ/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.100676+00	2026-09-21 07:18:50.100676+00
0716b37a-7914-48ce-8b65-47a3ff09c1fd	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-15.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1KFvX6PbmSBJwh3smivHNiDbPAN5C_ifH/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.102635+00	2026-09-21 07:18:50.102635+00
0584d206-36d3-4b00-808f-b1f4368143dd	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-16.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1w00vwGRifp3_GUe2dKZLWNwTg8O5aBws/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.104597+00	2026-09-21 07:18:50.104597+00
07997f60-0e75-4469-8816-eee8d643e91b	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-17.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/13Kg6c1NG6sFNH22tgvYjgTzd97RJlRPr/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.10674+00	2026-09-21 07:18:50.10674+00
03825e6a-6dd3-4e38-94e6-ad9f97964848	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-18.jpg	anh	\N	Mái_vật liệu — https://drive.google.com/file/d/1hezL08xIIZ6HfVBLaauWkMsq9yPyIsxh/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.108687+00	2026-09-21 07:18:50.108687+00
de13fe2e-5c8c-413a-9181-c61ddd0a7cff	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-19.jpg	anh	\N	Mái_cấu tạo — https://drive.google.com/file/d/1k2Ma78ZFxt-ecWg6bZ7zVInr8-tm1SAX/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.110632+00	2026-09-21 07:18:50.110632+00
dbca184a-bbdd-4e58-a205-ee68e7aaaec0	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-2.jpg	anh	\N	Ảnh tổng thể từ cổng chính — https://drive.google.com/file/d/1yWI7J3Yoep-DPMLLKE6YZwAso2jRop2E/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.112605+00	2026-09-21 07:18:50.112605+00
397b1558-1710-4c0a-8a92-8e7d5c6a170a	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-20.jpg	anh	\N	Công trình có hiên không — https://drive.google.com/file/d/1fTgha_W3suoMyoCQH47P1UsOLIgQgUiY/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.11474+00	2026-09-21 07:18:50.11474+00
7bad8633-a544-40d7-a61a-de0b73157fda	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-21.jpg	anh	\N	Hiên tam cấp ngưỡng cửa — https://drive.google.com/file/d/1eRnoJeeA5cNUTGUSqMpncTQTnn84iWes/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.117642+00	2026-09-21 07:18:50.117642+00
6d86494e-9548-4d22-b779-625921ad738a	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-22.jpg	anh	\N	Nền (ảnh chụp) — https://drive.google.com/file/d/1m5SNy0Wjx0Z3ZaTe5ZFpvgwPcSb17tnz/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.119749+00	2026-09-21 07:18:50.119749+00
868445e3-886d-4241-aeb4-f006760058ef	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-23.pdf	ban_ve	\N	Sơ đồ mặt bằng — https://drive.google.com/file/d/1STuE8JWeZW-5W7OVZvgawzTo9_xYc_OP/view?usp=drive_link	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.121689+00	2026-09-21 07:18:50.121689+00
d318f346-716b-444b-8495-ba5706bef233	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-24.pdf	ban_ve	\N	Sơ đồ kết cấu — https://drive.google.com/file/d/1iJcE4E-W2Cem8-QaHVqiE68EclL8YdZG/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.123657+00	2026-09-21 07:18:50.123657+00
faecb927-ce53-41b0-87e3-f6a0f07e5d24	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-25.jpg	anh	\N	Ảnh trong nhà — https://drive.google.com/file/d/1c6oVAbLSXOV7rd8FAQgbYRweIfUU1Eju/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.125611+00	2026-09-21 07:18:50.125611+00
71f567b5-de00-441e-a07b-3ac09ae1e25d	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-26.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1E3WVyNzqXMbRoKMIyYWmToTuiKrFFKCt/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.127583+00	2026-09-21 07:18:50.127583+00
62d36efe-224e-4b97-a829-cb706d3fce7b	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-27.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/14mjjmUd-hYxa8N7u1lDnVZ0MiJw1HUVM/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.129731+00	2026-09-21 07:18:50.129731+00
ee5f8a63-d824-4997-bbaf-2e73d740561f	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-28.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/11W2m1aCN27DLJfXREPJVz-88XwN_hGNR/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.131683+00	2026-09-21 07:18:50.131683+00
ab7248a5-acb7-4172-87e8-156dbdd04ca5	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-29.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1GUouXQYP_7vIHv1a1xclMQBwqhDhYkfU/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.133644+00	2026-09-21 07:18:50.133644+00
d24a46cc-ff28-40af-a08f-28595b019bbd	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-3.pdf	ban_ve	\N	Tổng mặt bằng — https://drive.google.com/file/d/1fWgdy7bXi_gGBDTs6oc2sCJ_EIrmxnoo/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.135607+00	2026-09-21 07:18:50.135607+00
3c6eab6c-d8d4-48cb-90cf-e78b832240cd	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-30.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1ksr8w4UWJcMJIfK0w9PH24tt0KckKo5L/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.137738+00	2026-09-21 07:18:50.137738+00
51d36ca4-0db3-43e8-8359-223feb3c7789	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-31.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1xr9kolf0vQLYFU3rmmQMg1vxZsfCXK1n/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.13969+00	2026-09-21 07:18:50.13969+00
5cd3ba9c-102c-45c6-8fbb-7520342cebac	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-32.jpg	anh	\N	Chân tảng ảnh — https://drive.google.com/file/d/1Zo2Bk_m-6eS28cvwzmhloOX7bH8wbAsB/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.141642+00	2026-09-21 07:18:50.141642+00
868e2c03-a4f9-430b-b4f1-2de978f44065	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-4.jpg	anh	\N	Chức năng các công trình trong tổng thể — https://drive.google.com/file/d/1NMLOX1RNS4X7jwSaG4k-7bh2IZtGj-rV/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.143619+00	2026-09-21 07:18:50.143619+00
f1d7ef24-d545-4a6f-9ee0-5ee8652f656a	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-5.jpg	anh	\N	Chức năng các công trình trong tổng thể — https://drive.google.com/file/d/1fhKhhTgV-fh68TG5EpyT79az0z61IAu7/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.145749+00	2026-09-21 07:18:50.145749+00
ba65f6d9-a9b9-4099-aacd-bd526050a193	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-6.jpg	anh	\N	Chức năng các công trình trong tổng thể — https://drive.google.com/file/d/12Zk7x3ZEvd-WbnzGA8wh4tfXDahi2rEb/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.147687+00	2026-09-21 07:18:50.147687+00
44fb735a-26d0-4cf5-b16d-036c991daea9	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-7.jpg	anh	\N	Các đối tượng phụ trợ — https://drive.google.com/file/d/1f0hxYqpRlGAEcvYtIHvDKjetRmW_wa5C/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.149644+00	2026-09-21 07:18:50.149644+00
e3d777df-2eb5-4158-b9e2-625a6fe35f2a	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-8.jpg	anh	\N	Các đối tượng phụ trợ — https://drive.google.com/file/d/14hqSTWOvX7uaonsBTyLIhQl37Pt1wNuA/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.151623+00	2026-09-21 07:18:50.151623+00
c70bfc3a-1a69-4c63-8b6a-9237b233caf9	/phu-vinh/heritage-buildings/quan-phu-vinh-61782dee-9.jpg	anh	\N	Ảnh chụp đối tượng phụ trợ (nếu có) — https://drive.google.com/file/d/1ESCKxmmXvlftFtVpp-_NcN8yz7gr09UE/view?usp=sharing	heritage_buildings	7929cf67-5bc1-425f-b66e-1200ff174b80	2026-09-21 07:18:50.153588+00	2026-09-21 07:18:50.153588+00
4815b72c-f634-4cfb-968b-e811d2be22e0	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-1.jpg	anh	\N	Kiểu loại được xếp hạng — https://drive.google.com/file/d/1UBW93xi4tv1I_zdewwMrs857rQc8c3YM/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.155746+00	2026-09-21 07:18:50.155746+00
ee4140d1-02ba-4d63-85ed-60b663f6759f	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-10.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/113WRIVKICjvPLCR1lozILqbqZBq0EXRj/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.158628+00	2026-09-21 07:18:50.158628+00
db74a0c7-6b7c-4c50-8f25-38a7340fcd89	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-11.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1eoMZWESlZY5HW2q9LG9mWky6xKFw5_Yh/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.160729+00	2026-09-21 07:18:50.160729+00
061f885c-8eca-4a24-8357-48ad58bba69d	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-12.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1lHgmvcJWVmGvJXYK1Mw4gDMBnW_XLgmM/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.163627+00	2026-09-21 07:18:50.163627+00
12cf8bc2-7a27-45de-8aa7-17295f9425f1	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-13.jpg	anh	\N	Các bộ phận, chi tiết đặc biệt — https://drive.google.com/file/d/1rkqcTwv26fsTDcaWBj2iFnzDnLJtvIwC/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.165749+00	2026-09-21 07:18:50.165749+00
8176b7b4-64ac-490a-8dc7-6827180e6e35	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-14.jpg	anh	\N	Mái_vật liệu đại đình — https://drive.google.com/file/d/18lM2_5FYGCh83cF202iWEWyG0eQ75lGu/view?usp=drive_link	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.168649+00	2026-09-21 07:18:50.168649+00
75a5d57a-438a-4d30-b197-b0df392a3130	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-15.jpg	anh	\N	Mái_vật liệu nhà kho — https://drive.google.com/file/d/1-E_HyfQj-uQO6_Zs6aKip_EAWgOvagH3/view?usp=drive_link	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.170734+00	2026-09-21 07:18:50.170734+00
89437b59-6825-44db-9552-6f478f79445f	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-16.jpg	anh	\N	Mái_cấu tạo đại đình — https://drive.google.com/file/d/19--RF6V_S6UmsdnZ37Krgk2SwT7ronL-/view?usp=drive_link	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.173617+00	2026-09-21 07:18:50.173617+00
428e80fb-7119-4353-859a-d926dcf76dc5	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-17.jpg	anh	\N	Mái_cấu tạo nhà kho — https://drive.google.com/file/d/1BkJoWxuZfW9W9vrEqw5PiYzB52IUqzCj/view?usp=drive_link	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.175728+00	2026-09-21 07:18:50.175728+00
7f848481-5dcf-4a07-ad9f-f2f81fc25f4e	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-18.jpg	anh	\N	Nền (ảnh chụp) — https://drive.google.com/file/d/1AuxXoYUQ1rB11ZXLC6PQwN0bRt3RT9PP/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.177687+00	2026-09-21 07:18:50.177687+00
92f0fdaf-b927-4572-8695-17094891ab2a	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-19.jpg	anh	\N	Nền (ảnh chụp) — https://drive.google.com/file/d/1JvhnrCFAU2lIvVfMARC5Rtk_7Gte9ueZ/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.179628+00	2026-09-21 07:18:50.179628+00
c505d4c5-84f6-4d6e-b404-ff8a42ce627e	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-2.jpg	anh	\N	Ảnh tổng thể từ cổng chính — https://drive.google.com/file/d/1XEGLmD_uKLpld54SqXqLXZK5SuoLGYBZ/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.181605+00	2026-09-21 07:18:50.181605+00
73169d4a-bcc1-445d-a05f-38ed34c3c18c	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-20.pdf	ban_ve	\N	Sơ đồ mặt bằng đại đình — https://drive.google.com/file/d/1l_TI-z9SzyXmiqs9TkOsiv0u2Z9Il7ae/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.183733+00	2026-09-21 07:18:50.183733+00
7a1e7abc-2bbe-4ab2-9cfa-9266135b9f53	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-21.pdf	ban_ve	\N	Sơ đồ mặt bằng nhà kho — https://drive.google.com/file/d/1G7nIhnaGKjhVcyiWaILFEuCXW3RPraYz/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.186607+00	2026-09-21 07:18:50.186607+00
cbb3d8e5-10ac-4292-8250-ce4e848e9550	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-22.pdf	ban_ve	\N	Sơ đồ kết cấu đại đình — https://drive.google.com/file/d/1Eyxq8ym3VrlSLTkCpfbyQ8opuASPd38a/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.188719+00	2026-09-21 07:18:50.188719+00
107a3605-7a9d-4d04-9cae-acf40d414095	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-23.pdf	ban_ve	\N	Sơ đồ kết cấu nhà kho — https://drive.google.com/file/d/1H8IsR89XXJ2ZKvTum2heWYxqnibzwGt0/view?usp=drive_link	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.19162+00	2026-09-21 07:18:50.19162+00
5aba3d3d-9df6-4c26-a9a5-0cbb6c1a062f	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-24.jpg	anh	\N	Ảnh trong nhà — https://drive.google.com/file/d/1PPVHDhuO29rvO7TOvq_PSR-VFZ91USjG/view?usp=drive_link	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.193733+00	2026-09-21 07:18:50.193733+00
42b72060-32b4-499e-9a7b-72b3aa261162	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-25.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1Cb5_qNJP670ntUPnenND60Xk6ae6yHzz/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.196615+00	2026-09-21 07:18:50.196615+00
e6d5cc9c-456f-47fb-9fa6-f2cef3560271	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-26.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1tkpI7PHvlgDMOU-WVC7tiBNdVnw2zZE9/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.198746+00	2026-09-21 07:18:50.198746+00
06b969ca-4c3e-4052-806b-3b6c06807c09	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-27.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1hnhoJtW9FFNV7O51rcP1aRTBZMGI4sDy/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.201626+00	2026-09-21 07:18:50.201626+00
6a2c3c22-d59b-40b3-bfa2-f4624ac432d0	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-28.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/18OGet_H3KJgzfDXMJKRS1nLTC671KPmF/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.203738+00	2026-09-21 07:18:50.203738+00
cd502325-7b48-4ea1-ad8f-86a743dc1405	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-29.jpg	anh	\N	Kết cấu ảnh — https://drive.google.com/file/d/1AImvU9Kj7N2WJz0RtPAHzY58tD1J3dHV/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.206634+00	2026-09-21 07:18:50.206634+00
e9722b96-bae9-434c-b394-515f662b4bd8	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-3.jpg	anh	\N	Cấu trúc chung — https://drive.google.com/file/d/1fyw2pNjaXua-nn_Yufu4fZmYwuLzBhSM/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.208757+00	2026-09-21 07:18:50.208757+00
44919b5a-66bf-4167-a2b8-1a041fd11c25	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-30.jpg	anh	\N	Chân tảng ảnh — https://drive.google.com/file/d/1Ro7zeH-2Carii4ciQun0drCkx4CX1R2I/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.211621+00	2026-09-21 07:18:50.211621+00
57209c2f-5ae3-4784-82f3-e54522cd6278	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-31.jpg	anh	\N	Chân tảng ảnh — https://drive.google.com/file/d/15ePZ6k2vWjX5mHnncNAjhoU43WCOEB33/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.213765+00	2026-09-21 07:18:50.213765+00
78606a44-365b-4fcc-9215-965a6bcabe87	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-4.jpg	anh	\N	Cấu trúc chung — https://drive.google.com/file/d/14xQbxGDj53h_6Ru4ecDLeF3jlV_AkeVg/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.216627+00	2026-09-21 07:18:50.216627+00
b86f27a2-c20b-4285-80ab-6473eac07801	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-5.jpg	anh	\N	Cấu trúc chung — https://drive.google.com/file/d/1hEZoXvMKknoFjkSXWf6IRK1r56hl7o_o/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.218801+00	2026-09-21 07:18:50.218801+00
109b3165-e851-4ef7-adff-a49021ed857e	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-6.pdf	ban_ve	\N	Tổng mặt bằng — https://drive.google.com/file/d/17oVhtATrZ1lmdIq8KYBRHBNDMS3cusjs/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.221656+00	2026-09-21 07:18:50.221656+00
cb883687-ed96-4434-8f7f-be98d132c7c9	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-7.jpg	anh	\N	Cảm nhận của người quan sát về không gian khuôn viên — https://drive.google.com/file/d/1vS2PMSkSwXjZur-FQoFKmf2zaRtEi0WN/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.223749+00	2026-09-21 07:18:50.223749+00
96bc8394-afcf-43cf-8c30-90f6fb0e5d0e	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-8.jpg	anh	\N	Mặt đứng, mặt bên công trình — https://drive.google.com/file/d/1Fr_YjifwQ928Z8DkDSSZf0iDuAo4w1zg/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.226654+00	2026-09-21 07:18:50.226654+00
5d93b1d0-c2b6-42fe-8318-5f1777b6b775	/phu-vinh/heritage-buildings/dinh-phu-vinh-22295a63-9.jpg	anh	\N	Mặt đứng, mặt bên công trình — https://drive.google.com/file/d/1x_sTTuPg5K0dKIGC8lWdU2qwfyLcdHjX/view?usp=sharing	heritage_buildings	f5cc6df5-789e-4e33-a718-02219cf0c184	2026-09-21 07:18:50.228798+00	2026-09-21 07:18:50.228798+00
972fbd52-9b1d-486c-8d6f-a79069bf1345	/phu-vinh/decorative/cac-hinh-tuong-linh-hoa-ca-hoa-rong-cay-co-hoa-rong-6db86046-1.jpg	anh	\N	https://drive.google.com/file/d/1KFvX6PbmSBJwh3smivHNiDbPAN5C_ifH/view?usp=sharing	decorative_art_items	8a369ac0-fa49-4280-8041-8a90bde57eb8	2026-09-21 07:18:50.23167+00	2026-09-21 07:18:50.23167+00
e663a83e-bb30-45e5-9a00-b8b27ff2ff76	/phu-vinh/decorative/tuong-thanh-than-trong-den-mieu-dao-quan-hoi-quan-b15dac6b-1.jpg	anh	\N	https://drive.google.com/file/d/1TOoy9dOzqpqCgegESzq8kuK5fWojN5lD/view?usp=sharing	decorative_art_items	4d5f257c-05b9-46ce-b9c0-549a9ccc940e	2026-09-21 07:18:50.235775+00	2026-09-21 07:18:50.235775+00
8e30dd53-1d32-4f03-a17a-07ba926c906e	/phu-vinh/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-cb4cadb9-1.jpg	anh	\N	https://drive.google.com/file/d/13P30onRzwpjKz5ZroiJDzhS_BL7PJ6EX/view?usp=sharing	decorative_art_items	b19aba5a-2eb8-4fce-8eb8-1d0b20680c03	2026-09-21 07:18:50.238643+00	2026-09-21 07:18:50.238643+00
2705d208-d58d-4503-a113-82380504e5ea	/phu-vinh/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-4cd4e215-1.jpg	anh	\N	https://drive.google.com/file/d/19Mu7L-_OokrP4FZ5uXih_kBopm4SMAxM/view?usp=sharing	decorative_art_items	79c561bb-5836-47d8-93c6-78b66e5c27f2	2026-09-21 07:18:50.241701+00	2026-09-21 07:18:50.241701+00
3568cfb1-c5bb-43cd-b202-b86b76b470f6	/phu-vinh/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-dce06542-1.jpg	anh	\N	https://drive.google.com/file/d/1CpOWrWlV_MdqQlq41K6Lzzo5fqJTXHfE/view?usp=sharing	decorative_art_items	e6d50393-3c4d-4355-ad5e-5bca06e1a083	2026-09-21 07:18:50.244756+00	2026-09-21 07:18:50.244756+00
842c3552-22be-4cd9-9d74-64c3f6729b06	/phu-vinh/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-438b3549-1.jpg	anh	\N	https://drive.google.com/file/d/1rkqcTwv26fsTDcaWBj2iFnzDnLJtvIwC/view?usp=drive_link	decorative_art_items	b04f6782-3d82-40cb-9c31-289d10e5de16	2026-09-21 07:18:50.250677+00	2026-09-21 07:18:50.250677+00
bd39156d-3684-42be-8661-59b7e1ef1f2a	/phu-vinh/decorative/do-tu-khi-huong-an-kham-ngai-bai-vi-815ec1d9-1.jpg	anh	\N	https://drive.google.com/file/d/1DpZcsTTOMh1wNeXVQHPlyF4qA0a5tYE1/view?usp=sharing	decorative_art_items	a47ac85e-9d9f-4c61-9384-b6377eb9965c	2026-09-21 07:18:50.253724+00	2026-09-21 07:18:50.253724+00
6cfb24b4-c3c0-4bc9-a636-fbd7eb81e4ad	/cu-da/heritage-buildings/nha-ong-mao-d1bb8b84-5.jpg	panorama	\N	Ảnh các góc chính — Ảnh góc chính 360	heritage_buildings	3ee3bd85-6227-4c96-ba05-ff8b2b74034d	2026-09-21 07:19:37.213151+00	2026-09-21 07:19:37.213151+00
89bac6c0-522b-47e8-a3b6-5de911ed62c3	/phu-vinh/decorative/do-trang-tri-tho-tu-gan-tren-bo-khung-kien-truc-hoanh-phi-cuon-thu-cau-doi-cua-vong-thieu-chau-y-mon-e9217b60-1.jpg	anh	\N	https://drive.google.com/file/d/1iiixBOetAX6S0PwcUPtVX29Es2q-HfZb/view?usp=sharing	decorative_art_items	73aa0396-7312-46ec-aacc-6dcd3c3fcac0	2026-09-21 07:18:50.247782+00	2026-09-21 14:17:50.394222+00
21202036-7ae8-49ff-9dac-ee6e1ac3e388	/uoc-le/heritage-buildings/nha-cu-kha-3-44000000-11.jpg	anh	\N	Mái_cấu tạo — Mái	heritage_buildings	44000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.721045+00	2026-09-21 14:17:50.394222+00
a57d6d9b-b0a9-4eb3-a0fb-283f6ada46c5	/cu-da/heritage-buildings/chua-cu-da-linh-minh-tu-4f9067b2-29.png	anh	\N	Chân tảng ảnh — Chân tảng	heritage_buildings	414cdd05-ffeb-4ea2-b5f4-3c4caa9b0c02	2026-09-21 07:18:48.390652+00	2026-09-21 14:17:50.394222+00
bd5ebc28-6308-40b8-aaf3-6baf56fcdad5	/cu-da/decorative/do-te-khi-bat-huong-dinh-mam-bong-dai-do-chap-kich-lo-bo-lac-chau-phong-chau-02e6073b-1.jpg	anh	\N	Bát hương	decorative_art_items	d474c8c4-7e3a-4f4a-8e15-13db1453ac6b	2026-09-21 07:18:48.634753+00	2026-09-21 14:17:50.394222+00
05a99b8b-2c5e-48b8-8cf1-5c63978eb7a0	/ha-thai/heritage-buildings/nha-co-afe0acd9-13.jpg	anh	\N	Ảnh các góc chính	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.93076+00	2026-09-21 14:17:50.394222+00
0e4dd81d-fccb-4c3b-a568-50feae11c89f	/lang-chuong/sites/gieng-xom-8-trung-khu-106ce802-1.jpg	panorama	\N	\N	sites	106ce802-8e72-434c-9868-3d31349edf42	2026-09-21 02:54:20.619076+00	2026-09-21 08:08:41.780335+00
54362989-823f-48da-8b0b-5c45dbc28170	/lang-chuong/sites/diem-xom-2-thon-lien-tan-d30f9f94-1.jpg	panorama	\N	\N	sites	d30f9f94-feed-4c29-9d7d-9eae85b19a33	2026-09-21 02:54:20.639087+00	2026-09-21 08:08:41.780335+00
e246ec92-0dcf-4cc1-966c-9358f1a0d225	/lang-chuong/sites/duong-chinh-1d8169b9-1.jpg	panorama	\N	\N	sites	1d8169b9-ba0f-4f00-b00a-eee0a512c7ad	2026-09-21 02:54:20.645148+00	2026-09-21 08:08:41.780335+00
b5a03a49-a17b-4093-922b-d8c74da96fa9	/lang-chuong/sites/duong-nhanh-ngo-d5b7ab2f-1.jpg	panorama	\N	\N	sites	d5b7ab2f-ca77-44f3-abfc-bbf37260bc50	2026-09-21 02:54:20.647107+00	2026-09-21 08:08:41.780335+00
87a842a9-8588-452a-a36e-7e4abfd06e56	/lang-chuong/sites/duong-theo-vat-lieu-495a71f9-1.jpg	panorama	\N	\N	sites	495a71f9-99a3-418f-98ad-eff84975c53f	2026-09-21 02:54:20.649062+00	2026-09-21 08:08:41.780335+00
f49a3f27-4ce9-4269-8741-47e820f7f93b	/lang-chuong/sites/den-quan-trung-e39832de-1.jpg	panorama	\N	\N	sites	e39832de-c992-4295-b9e4-302aff37cbca	2026-09-21 02:54:20.653173+00	2026-09-21 08:08:41.780335+00
c8f339e6-0529-472d-9237-b099b18bff1d	/lang-chuong/sites/den-thuong-60353b9d-1.jpg	panorama	\N	\N	sites	60353b9d-c4e4-4d1e-a186-5b75ba80984a	2026-09-21 02:54:20.655127+00	2026-09-21 08:08:41.780335+00
c1df5703-d8dd-4049-b76c-0ffd049eead2	/phu-vinh/sites/chua-co-ngong-41033f55-1.jpg	panorama	\N	Ảnh chùa Cổ Ngỗng	sites	41033f55-90ea-4539-aba1-1ea4ed330048	2026-09-21 02:54:20.769842+00	2026-09-21 08:08:41.780335+00
0711e7d6-28f5-4a4b-8f5e-18a7bf9a53d0	/phu-vinh/sites/chua-ha-phu-vinh-f15021e9-1.jpg	panorama	\N	Ảnh Chùa Hạ Phú Vinh	sites	f15021e9-5cee-4574-8b56-6d22a288dcf1	2026-09-21 02:54:20.777172+00	2026-09-21 08:08:41.780335+00
c8c95e67-c125-49a4-9dec-70fd3e85a14d	/phu-vinh/sites/cho-f06f841f-1.jpg	panorama	\N	Ảnh chợ hiện tại	sites	f06f841f-b468-4f92-b6c6-72dd66815c99	2026-09-21 02:54:20.779115+00	2026-09-21 08:08:41.780335+00
c9d8bc31-098f-4a29-b31c-f395e856a46e	/phu-vinh/sites/quan-8987a84a-1.jpg	panorama	\N	Quán	sites	8987a84a-b2d7-4423-86b9-94d27953c155	2026-09-21 02:54:20.791137+00	2026-09-21 08:08:41.780335+00
4ea27482-0697-410f-9f0f-f82330802d3a	/phu-vinh/sites/dinh-lang-7cf72fe0-1.jpg	panorama	\N	Ảnh đình làng	sites	7cf72fe0-3aa2-4c0e-9c57-e926d04db3ba	2026-09-21 02:54:20.793174+00	2026-09-21 08:08:41.780335+00
8b053f5c-329a-4bd6-b9bb-54ea8886e6c3	/phu-vinh/sites/duong-chinh-a8c52c9f-1.jpg	panorama	\N	Ảnh đường chính	sites	a8c52c9f-dd7e-4ae6-904b-d65e844579c6	2026-09-21 02:54:20.795115+00	2026-09-21 08:08:41.780335+00
ba9b0df5-8b3f-432f-9963-9d2e2173b826	/phu-vinh/sites/dat-nong-nghiep-d49c5ca9-1.jpg	panorama	\N	Hình ảnh	sites	d49c5ca9-4e36-4c36-b31d-417f813d6dcc	2026-09-21 02:54:20.801053+00	2026-09-21 08:08:41.780335+00
64d344bc-9fac-4674-a66e-0868395e7f09	/uoc-le/sites/cong-lang-uoc-le-1.jpg	panorama	\N	Ảnh cổng mặt ngoài làng	sites	20000000-0000-0000-0000-000000000001	2026-09-21 02:54:18.88913+00	2026-09-21 08:08:41.780335+00
2ecabcc9-3df5-4426-b069-fe888ad9984d	/uoc-le/sites/nha-tho-giao-ho-1.jpg	panorama	\N	Nhà thờ giáo họ	sites	20000000-0000-0000-0000-000000000014	2026-09-21 02:54:18.908095+00	2026-09-21 08:08:41.780335+00
fe96039f-825a-4456-b898-36e3dcac45b7	/ha-thai/heritage-buildings/nha-co-afe0acd9-26.jpg	panorama	\N	Ảnh trong nhà	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.965791+00	2026-09-21 08:08:41.780335+00
66e3b24a-a9fc-4a51-98aa-af1e0ddc8854	/ha-thai/heritage-buildings/nha-co-afe0acd9-27.jpg	panorama	\N	Ảnh trong nhà	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.968646+00	2026-09-21 08:08:41.780335+00
18c1b255-3494-49b7-b685-0faf66f6b626	/lang-cuu/heritage-buildings/nha-tay-0b7290de-1.jpg	panorama	\N	Ảnh tổng thể từ cổng chính — ảnh từ cổng chính	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.288522+00	2026-09-21 08:08:41.780335+00
b5ef489e-538a-42a3-97d0-02f84ee7908a	/lang-cuu/heritage-buildings/nha-tay-0b7290de-2.jpg	panorama	\N	Ảnh tổng thể từ cổng chính — ảnh các công trình	heritage_buildings	8ee6fb23-a886-441f-8cd0-ea80804b6e9a	2026-09-21 07:18:49.316607+00	2026-09-21 08:08:41.780335+00
8478ac6e-6539-420b-9789-b0408d0b090a	/lang-cuu/heritage-buildings/nha-bac-tu-cb7c90d6-1.jpg	panorama	\N	Ảnh tổng thể từ cổng chính	heritage_buildings	d9f3b97b-8d01-4ea2-afa7-4b0e4d6b8460	2026-09-21 07:18:49.339692+00	2026-09-21 08:08:41.780335+00
b0a88fce-ccfd-4497-8712-f7591a83fb77	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-1.jpg	panorama	\N	Ảnh tổng thể từ cổng chính	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.388789+00	2026-09-21 08:08:41.780335+00
470509a8-de9a-4f74-80c6-321ae267aacb	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-13.jpg	panorama	\N	Hình ảnh hiên — ảnh dọc theo hiên	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.398614+00	2026-09-21 08:08:41.780335+00
3172f3ae-7066-498f-aeb3-bdecb56166ad	/lang-cuu/heritage-buildings/nha-tho-ho-tran-715f4f9c-2.jpg	panorama	\N	Ảnh tổng thể từ cổng chính	heritage_buildings	909dd7d6-0c65-4f11-bedf-c6fecd4f9198	2026-09-21 07:18:49.415755+00	2026-09-21 08:08:41.780335+00
1d968ff3-daf8-4fb1-90eb-feee58ed8969	/lang-chuong/heritage-buildings/dinh-lang-chuong-da2779ab-4.jpg	panorama	\N	Cảm nhận của người quan sát về không gian khuôn viên — ảnh khuôn viên đình làng chuông	heritage_buildings	e92783f4-ea38-4375-9555-6751b3ac9129	2026-09-21 07:18:49.733615+00	2026-09-21 08:08:41.780335+00
216ebb0e-3106-4f93-a86c-9da442d5cd71	/uoc-le/sites/chua-sung-phuc-24.jpg	anh	\N	Ảnh trong nhà — Thượng điện,	sites	20000000-0000-0000-0000-000000000003	2026-09-21 02:54:19.022148+00	2026-09-21 08:08:41.780335+00
4296bf1a-976a-4137-bc27-ee9fdeabf631	/ha-thai/heritage-buildings/nha-co-afe0acd9-3.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 và ảnh chụp) — Bản vẽ	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:48.975638+00	2026-09-21 08:08:41.780335+00
e367907b-efde-4a10-ac99-fe0227bb6697	/ha-thai/heritage-buildings/nha-co-afe0acd9-4.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 và ảnh chụp)	heritage_buildings	5b72fa35-638b-44c6-ab02-3947ba5a6102	2026-09-21 07:18:49.000669+00	2026-09-21 08:08:41.780335+00
808fb8b8-c553-4dc5-8475-c1ad5dac3ace	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-2.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 độ, các góc nhìn)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.04266+00	2026-09-21 08:08:41.780335+00
8dc90346-8673-4d65-84ca-042afc4ef056	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-3.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 độ, các góc nhìn)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.069655+00	2026-09-21 08:08:41.780335+00
dcacd1de-a5ee-487b-b243-dca63c35e38f	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-4.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 độ, các góc nhìn)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.096644+00	2026-09-21 08:08:41.780335+00
89921f06-1d59-4f21-8343-95f8c90aa321	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-5.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 độ, các góc nhìn)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.123667+00	2026-09-21 08:08:41.780335+00
5c39edb3-ea54-4287-8db6-a587effd0dfa	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-6.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 độ, các góc nhìn)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.12671+00	2026-09-21 08:08:41.780335+00
9d428e5b-5a4a-4c4b-af2f-e5979934f38b	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-7.jpg	anh	\N	Ảnh tổng thể từ cổng chính ( Ảnh 360 độ, các góc nhìn)	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.128633+00	2026-09-21 08:08:41.780335+00
7e360000-0000-4360-8000-000000000001	/uoc-le/sites/duong-gach-kha-dep-1.jpg	panorama	\N	Ảnh 360	sites	20000000-0000-0000-0000-000000000018	2026-09-21 08:08:41.780335+00	2026-09-21 08:14:24.147938+00
3244d378-89be-47ab-be36-754d3338bf97	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-33.jpg	anh	\N	Nền (vật liệu): Lát gạch đỏ 30x30	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.07872+00	2026-09-21 14:17:50.394222+00
b6e6ea68-00ad-4919-9602-703137ea84f0	/ha-thai/heritage-buildings/dinh-ha-thai-con-co-ten-goi-la-dinh-ba-lay-09758e11-34.jpg	anh	\N	Nền (cách lát): Lát vuông, lát so le	heritage_buildings	2113eaa5-1727-4f3c-9f78-f2a426fda3d9	2026-09-21 07:18:49.081639+00	2026-09-21 14:17:50.394222+00
07c229c6-a401-4b11-a4df-e7c942a562b4	/ha-thai/decorative/vi-noc-gian-bien-bbd2f4b0-1.jpg	anh	\N	\N	decorative_art_items	e29b62b5-afff-467e-95ba-69968914723b	2026-09-21 07:18:49.14278+00	2026-09-21 14:17:50.394222+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.schema_migrations (filename, applied_at) FROM stdin;
000_migration_ledger.sql	2026-09-23 15:48:24.986299+00
001_schema_alignment.sql	2026-09-23 15:48:25.086563+00
002_seed_villages.sql	2026-09-23 15:48:25.195771+00
003_seed_heritage_buildings.sql	2026-09-23 15:48:25.320261+00
004_seed_sites.sql	2026-09-23 15:48:25.433859+00
005_seed_decorative_art_items.sql	2026-09-23 15:48:25.553648+00
006_seed_heritage_building_technical_details.sql	2026-09-23 15:48:25.672037+00
007_seed_craft_products.sql	2026-09-23 15:48:25.801187+00
008_seed_craft_products_internal.sql	2026-09-23 15:48:25.915643+00
009_seed_history_stories.sql	2026-09-23 15:48:26.045368+00
010_seed_intangible_heritage_items.sql	2026-09-23 15:48:26.153581+00
011_seed_media.sql	2026-09-23 15:48:26.266161+00
012_link_media.sql	2026-09-23 15:48:26.373071+00
013_cleanup_placeholder_media.sql	2026-09-23 15:48:26.484366+00
014_fix_non_panorama_media_kind.sql	2026-09-23 15:48:26.591161+00
015_sites_position_and_footprint.sql	2026-09-23 15:48:26.698135+00
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.sites (id, village_id, kind, position_lat, position_lng, boundary, name, category, sub_category, short_description, light_count_25m, history_culture_note, cover_media_id, panorama_media_id, heritage_building_id, created_at, updated_at, boundary_source, boundary_updated_at) FROM stdin;
20000000-0000-0000-0000-000000000014	00000000-0000-0000-0000-000000000001	area	20.826472	105.809778	[[20.8265272, 105.8096575], [20.8264833, 105.8096548], [20.8264206, 105.8096575], [20.8263492, 105.8096722], [20.8262401, 105.8101537], [20.8264018, 105.8102194], [20.8264194, 105.8101389], [20.8264407, 105.810045], [20.8265046, 105.8098506], [20.826556, 105.809758], [20.8265723, 105.8097044]]	Nhà Thờ Giáo Họ	Di tích tín ngưỡng	\N	Nhà thờ giáo họ, nơi sinh hoạt tôn giáo của cộng đồng Công giáo trong làng.	\N	\N	82f45ce3-22ee-47cb-a429-2ef5bc2e8663	2ecabcc9-3df5-4426-b069-fe888ad9984d	\N	2026-09-21 02:53:49.164654+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
20000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000001	area	20.827225	105.810244	[[20.8275851, 105.8100688], [20.8274949, 105.8099682], [20.8271878, 105.8097844], [20.8270887, 105.8099414], [20.827011, 105.8101761], [20.826996, 105.8102351], [20.8272692, 105.8104402], [20.8274722, 105.8102101]]	Đình làng Ước Lễ	Di tích tín ngưỡng	\N	Nơi thờ Thành hoàng làng, diễn ra các lễ hội và sinh hoạt cộng đồng truyền thống.	\N	\N	56ddf93d-ef63-4ecb-afa2-de94ab1ec154	621b3b73-f88e-45c8-920a-3f40f3ebc847	\N	2026-09-21 02:53:32.060957+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
20000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	point	20.8265	105.8115	\N	Cổng làng Ước Lễ	Di tích kiến trúc	\N	\N	\N	\N	a4a8dec6-1cb3-4773-83a9-d4e78363abdc	64d344bc-9fac-4674-a66e-0868395e7f09	\N	2026-09-21 02:53:32.060957+00	2026-09-22 08:59:02.093015+00	\N	\N
e689ba8b-cf6e-4826-a469-dfc732526f3b	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.905378	105.865474	\N	Ao	Mặt nước	\N	\N	\N	\N	262c9215-cc46-4ac6-9201-1874ce1f195f	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
20000000-0000-0000-0000-000000000008	00000000-0000-0000-0000-000000000001	point	20.824306	105.813056	\N	Cổng Sau Làng Ước Lễ	Di tích kiến trúc	\N	Cổng sau của làng, lối ra vào phụ bên cạnh cổng chính (Cổng làng Ước Lễ).	\N	\N	dcef4a11-b1a1-4594-a986-0bcc12fdd03e	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:54:19.057131+00	\N	\N
20000000-0000-0000-0000-000000000011	00000000-0000-0000-0000-000000000001	point	20.826306	105.811333	\N	Điếm Tuần	Công trình công cộng	\N	Điếm tuần (chốt canh gác) cổ của làng, gắn với hoạt động tuần phòng truyền thống.	\N	\N	7d76273a-9d01-4547-9c6b-e56cf24d0f26	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:54:19.057131+00	\N	\N
20000000-0000-0000-0000-000000000009	00000000-0000-0000-0000-000000000001	point	20.826333	105.812278	\N	Nhà Dân	Nhà cổ	\N	Nhà dân trong khu dân cư truyền thống của làng.	\N	\N	\N	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:53:49.164654+00	\N	\N
20000000-0000-0000-0000-000000000015	00000000-0000-0000-0000-000000000001	point	20.826806	105.811083	\N	Ngõ 3	Cảnh quan	\N	Ngõ xóm số 3 trong làng, một trong các tuyến đường nội bộ mang đặc trưng làng cổ.	\N	\N	\N	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:53:49.164654+00	\N	\N
20000000-0000-0000-0000-000000000017	00000000-0000-0000-0000-000000000001	point	20.82725	105.810537	\N	Điểm chưa đặt tên (gần đình)	Cảnh quan	\N	Điểm ghi nhận trên bản đồ khảo sát, chưa xác định tên/công năng cụ thể, nằm gần đình làng.	\N	\N	\N	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:53:49.164654+00	\N	\N
b22e7458-33f4-46d7-a833-fa949d15fed0	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.708413265372698	105.89088423009412	[[20.7084526, 105.8908511], [20.7084062, 105.8908163], [20.7083685, 105.8909155], [20.7084175, 105.8909383]]	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	86b9092e-0d1d-4190-a79d-ee32fa175ee9	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:41:04.693831+00	kml	2026-09-22 09:41:04.693831+00
20000000-0000-0000-0000-000000000005	00000000-0000-0000-0000-000000000001	area	20.826231	105.810776	[[20.826209, 105.810158], [20.826909, 105.810558], [20.826709, 105.811358], [20.825809, 105.811258], [20.825509, 105.810458]]	Khu làng cổ	Quần thể di sản	\N	Cụm nhà cổ, ngõ xóm lát gạch nghiêng và không gian kiến trúc truyền thống vùng đồng bằng sông Hồng.	\N	\N	30000000-0000-0000-0000-000000000005	\N	\N	2026-09-21 02:53:32.064886+00	2026-09-22 02:21:13.897573+00	seed	\N
c28846f5-ea72-460b-aa45-d9c3d3bb15a6	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.908979	105.867907	\N	Cây cổ thụ	Cây	\N	\N	\N	\N	0ce8f1c8-2771-45ae-968b-46011d0b2db4	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
20000000-0000-0000-0000-000000000004	00000000-0000-0000-0000-000000000001	point	20.826889	105.812278	\N	Giếng Ngõ Phát	Cảnh quan	\N	Giếng nước cổ gắn với đời sống sinh hoạt lâu đời của người dân trong làng.	\N	\N	fd26ab91-dbaa-4c84-9279-d080ed2db325	\N	\N	2026-09-21 02:53:32.060957+00	2026-09-21 02:54:19.057131+00	\N	\N
f700864d-34e3-4f85-b121-bacc5a117937	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.905378	105.865474	\N	Sông - bến đò/ thuyền	Mặt nước	\N	\N	10	\N	\N	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 02:54:19.88338+00	\N	\N
7ca23109-cf2c-4020-97da-ba3c67033918	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.906198	105.866174	\N	Giếng_Miếu Nghè	Mặt nước	\N	\N	\N	\N	def1e6a8-a209-44ff-bb7d-76087784a6f3	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
4c9de4f0-3b78-4ad2-b856-a6b635f3514b	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.70865	105.88935	\N	Đường chính	Giao thông	\N	\N	\N	\N	9fd27d6d-2756-4269-9cbb-e17ca3473cd0	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
7d904c2e-ee19-480f-a93a-62c2f2810b6a	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.708038	105.89195	\N	Đường gạch	Giao thông	\N	\N	\N	\N	db0525b9-a1d8-48bc-86e7-6626a62dd105	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
aca31262-bb0a-47ee-8543-b7b8003ead58	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.708113	105.891659	\N	Đường nửa đá nửa gạch	Giao thông	\N	\N	\N	\N	229f8640-291a-4335-aa99-218c5cce3a00	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
9b2adb32-b607-419d-a5c3-69894a2d5c66	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.70842	105.89017	\N	Đường đá	Giao thông	\N	\N	\N	\N	f38b80ce-065b-4e82-95b6-4b1953786d21	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
d30f9f94-feed-4c29-9d7d-9eae85b19a33	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.82906	105.75746	[[20.8291071, 105.7574265], [20.8290231, 105.7574346], [20.8290106, 105.7575244], [20.8290983, 105.7575258]]	Điếm xóm 2 thôn Liên Tân	Di tích tín ngưỡng	\N	\N	\N	\N	\N	54362989-823f-48da-8b0b-5c45dbc28170	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.206463+00	kml	2026-09-22 09:41:04.324841+00
e39832de-c992-4295-b9e4-302aff37cbca	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.83334	105.76584	[[20.8336856, 105.7656679], [20.8335803, 105.7656384], [20.8332394, 105.7655285], [20.8331742, 105.7657538], [20.8335527, 105.7661615]]	Đền Quán Trung	Di tích tín ngưỡng	\N	\N	\N	\N	\N	f49a3f27-4ce9-4269-8741-47e820f7f93b	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.215065+00	kml	2026-09-22 09:41:04.324841+00
20000000-0000-0000-0000-000000000021	00000000-0000-0000-0000-000000000001	point	20.826742	105.811062	\N	Ngõ nhà đẹp	Cảnh quan	\N	Ngõ xóm có kiến trúc nhà đẹp, đáng chú ý trong khảo sát bản đồ làng.	\N	\N	\N	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:53:49.164654+00	\N	\N
20000000-0000-0000-0000-000000000022	00000000-0000-0000-0000-000000000001	point	20.827057	105.811544	\N	Nhà cổ số 4	Nhà cổ	\N	Nhà cổ số 4 theo đánh số khảo sát, còn giữ kiến trúc truyền thống.	\N	\N	\N	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:53:49.164654+00	\N	\N
20000000-0000-0000-0000-000000000023	00000000-0000-0000-0000-000000000001	point	20.827482	105.811424	\N	Nhà có cổng cổ	Nhà cổ	\N	Nhà dân có cổng cổ, một trong các điểm kiến trúc cổng nhà đáng chú ý của làng.	\N	\N	\N	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-21 02:53:49.164654+00	\N	\N
21000000-0000-0000-0000-000000000002	01000000-0000-0000-0000-000000000001	point	20.931994	105.796477	\N	Đường nhánh/ngõ	Cảnh quan	\N	Làng có 16 ngõ xóm, đường làng, đường xóm lát gạch vỉa nghiêng, dài nhỏ hẹp vuông góc đâm ra bờ sông. Đầu ngõ thường là bến sông.	\N	\N	\N	4fb5a9b5-3760-4c29-9b7a-6142fc416ba4	\N	2026-09-21 02:53:49.357745+00	2026-09-21 08:08:56.675239+00	\N	\N
05777db9-c92b-4da6-9f66-2833674f6ad5	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.8271	105.76814	[[20.8271252, 105.7681026], [20.8270481, 105.7681367], [20.827092, 105.7682065], [20.8271546, 105.7681743]]	Điếm Ngõa Kiều	Di tích tín ngưỡng	\N	\N	\N	\N	16e8ca41-23b3-4bd5-993b-030c112a4e59	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.217925+00	kml	2026-09-22 09:41:04.324841+00
50800f73-2fe4-483f-8b4a-4177688cd00a	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.83159	105.76333	[[20.8317508, 105.7633363], [20.8316042, 105.76328], [20.8315628, 105.7634436], [20.8316756, 105.7634865]]	Nhà thờ họ	Di tích tín ngưỡng	\N	\N	\N	\N	\N	44959b58-3307-4e48-8635-086b74b9378b	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.246039+00	kml	2026-09-22 09:41:04.324841+00
20000000-0000-0000-0000-000000000020	00000000-0000-0000-0000-000000000001	area	20.826024	105.812371	[[20.8261829, 105.812419], [20.8259937, 105.8122178], [20.825852, 105.8124016], [20.825951, 105.8124914], [20.826035, 105.8125987]]	Nhà Bà Vân siêu cổ	Nhà cổ	\N	Nhà cổ của gia đình bà Vân, được ghi nhận là một trong những nhà rất cổ còn lại trong làng.	\N	\N	c7a18111-2948-4765-aa00-82aa8388c477	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
21000000-0000-0000-0000-000000000016	01000000-0000-0000-0000-000000000001	area	20.932312	105.797834	[[20.93247, 105.7978243], [20.9322783, 105.7977398], [20.9322307, 105.7978511], [20.9324286, 105.7979343]]	Nhà cổ ông Giao	Nhà cổ	\N	Nhà cổ của ông Vũ Ngọc Giao.	\N	\N	42bbdf20-e577-4df1-9f59-ab78dccb2cf7	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
21000000-0000-0000-0000-000000000015	01000000-0000-0000-0000-000000000001	area	20.932271	105.797935	[[20.9323987, 105.7979225], [20.9322307, 105.7978511], [20.9321482, 105.7980419], [20.9323511, 105.7981049]]	Nhà cổ 31	Nhà cổ	\N	Nhà cổ số 31 theo đánh số khảo sát của làng Cự Đà.	\N	\N	0b29a4d9-8ed0-4cbd-a8ac-ea45578640fd	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
21000000-0000-0000-0000-000000000014	01000000-0000-0000-0000-000000000001	area	20.934744	105.799083	[[20.9350075, 105.7990891], [20.9349925, 105.799002], [20.9348873, 105.7989966], [20.9348747, 105.7989322], [20.934802, 105.7989657], [20.9346567, 105.7990166], [20.9347144, 105.799132]]	Nhà thờ họ	Di tích tín ngưỡng	\N	Nhà thờ họ Trịnh Giáp Thượng, Trịnh Giáp Hạ, Vũ Giáp Nam.	\N	\N	d3cd9de7-6642-487b-816e-c877ca52833d	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
21000000-0000-0000-0000-000000000009	01000000-0000-0000-0000-000000000001	area	20.935161	105.80002	[[20.9349042, 105.7996564], [20.9349067, 105.7998804], [20.9347026, 105.7998764], [20.93471, 105.7999266], [20.9347814, 105.8000701], [20.9347661, 105.8002377], [20.9350493, 105.8003873], [20.9350919, 105.8002894], [20.9351834, 105.800321], [20.9352034, 105.8002593], [20.9354151, 105.8003451], [20.9355616, 105.7997577], [20.935463, 105.7997272], [20.9351499, 105.7996682]]	Chùa Cự Đà	Di tích tín ngưỡng	\N	Chùa Cự Đà, nằm trong cụm cảnh quan chùa - miếu - sông - giếng của làng.	\N	\N	5b3324ed-e842-417d-bc18-1ae6b715f7d9	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
616bf014-5516-44ce-80c3-7d52190f1da3	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.8236	105.77252	[[20.8240714, 105.7719345], [20.8234547, 105.7721329], [20.8235901, 105.7729001], [20.8243271, 105.772825]]	Đất nông nghiệp	Cây	\N	\N	\N	\N	e47c7239-1603-4f24-941d-786d4ee79c58	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:41:04.324841+00	kml	2026-09-22 09:41:04.324841+00
21000000-0000-0000-0000-000000000001	01000000-0000-0000-0000-000000000001	point	20.93105	105.797169	\N	Đường chính	Cảnh quan	\N	Đường chính của làng Cự Đà.	\N	\N	3caacaa5-6908-4892-94a1-bde20cb29d03	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000003	01000000-0000-0000-0000-000000000001	point	20.933549	105.798093	\N	Đường làng gắn với hoạt động sản xuất (miến)	Làng nghề	\N	Đoạn đường làng gắn với hoạt động sản xuất miến, một trong hai nghề truyền thống chính của làng (miến, tương).	\N	\N	8525b395-195f-47a6-8bba-bf6c9099de73	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000004	01000000-0000-0000-0000-000000000001	point	20.934205	105.79866	\N	Đình làng Cự Đà	Di tích tín ngưỡng	\N	Đình làng Cự Đà.	\N	\N	f9c7156a-f2c7-440a-8848-b87c41c553f4	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000005	01000000-0000-0000-0000-000000000001	point	20.934584	105.801517	\N	Cổng làng Cự Đà	Di tích kiến trúc	\N	Trước làng có 3 cổng, hiện cổng trước và cổng sau đã bị phá hủy, chỉ còn lại cổng giữa làng (cùng chòi canh và không gian mặt nước xung quanh).	\N	\N	fa634fd2-81bd-4196-84c8-f8e084f2f3be	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
20000000-0000-0000-0000-000000000018	00000000-0000-0000-0000-000000000001	point	20.826235	105.812898	\N	Đường gạch khá đẹp	Cảnh quan	\N	Đoạn đường lát gạch còn giữ được nét kiến trúc làng cổ.	\N	\N	\N	7e360000-0000-4360-8000-000000000001	\N	2026-09-21 02:53:49.164654+00	2026-09-21 08:08:56.675239+00	\N	\N
21000000-0000-0000-0000-000000000006	01000000-0000-0000-0000-000000000001	point	20.934632	105.799064	\N	Cột cờ	Di tích kiến trúc	\N	Cột cờ của làng Cự Đà.	\N	\N	5cf40a81-63e5-4284-933b-6572e13d64f3	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000010	01000000-0000-0000-0000-000000000001	point	20.934568	105.800004	\N	Giếng	Cảnh quan	\N	Giếng nước của làng Cự Đà, nằm gần khu vực chùa.	\N	\N	a5e67258-f93b-4288-834f-1cac764e02aa	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000011	01000000-0000-0000-0000-000000000001	point	20.932499	105.798092	\N	Cổng xóm Hiếu Đễ	Di tích kiến trúc	\N	Một trong các cổng xóm của làng Cự Đà (cùng với cổng xóm Quang Trung 1, Quang Trung 2, Lễ Nghĩa).	\N	\N	94e97152-6bda-4806-abc7-b2b41461ad42	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000012	01000000-0000-0000-0000-000000000001	point	20.933069	105.798287	\N	Cổng xóm Quang Trung	Di tích kiến trúc	\N	Cổng xóm Quang Trung của làng Cự Đà.	\N	\N	8559ce87-68a6-4412-bc7f-09cf07d61c89	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000013	01000000-0000-0000-0000-000000000001	point	20.93215	105.798013	\N	Cổng xóm - đường làng - nhà cổ	Di tích kiến trúc	\N	Cụm cổng xóm, đường làng và nhà cổ được ghi nhận cùng vị trí trong khảo sát bản đồ làng.	\N	\N	b20a2743-7e10-4842-9c5c-95b3f61984bd	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000019	01000000-0000-0000-0000-000000000001	point	20.934781	105.799733	\N	Cây nhãn	Cảnh quan	\N	Cây nhãn cổ của làng Cự Đà.	\N	\N	b66e95d3-8f5e-42c4-b6e2-0e87c10b83e2	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000020	01000000-0000-0000-0000-000000000001	point	20.934704	105.799775	\N	Cây muỗm	Cảnh quan	\N	Cây muỗm cổ của làng Cự Đà.	\N	\N	e2cf5a74-a0c2-4e72-91db-c0770ff91203	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000021	01000000-0000-0000-0000-000000000001	point	20.934704	105.799775	\N	Cây Nhãn 2	Cảnh quan	\N	Cây nhãn thứ hai được ghi nhận trong khảo sát bản đồ làng (cùng vị trí ghim với Cây muỗm trong file nguồn).	\N	\N	6487981d-5192-46ab-85ba-2838d8f812c9	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000022	01000000-0000-0000-0000-000000000001	point	20.934537	105.801427	\N	Quán ăn	Công trình công cộng	\N	Quán ăn của làng Cự Đà.	\N	\N	b8c5f58f-4a6f-437c-9d01-eba2701205ea	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
21000000-0000-0000-0000-000000000023	01000000-0000-0000-0000-000000000001	point	20.934705	105.800086	\N	Quán nước	Công trình công cộng	\N	Quán nước của làng Cự Đà.	\N	\N	830630d3-7b6e-4126-a5de-be10ff15e872	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-21 02:54:18.738473+00	\N	\N
c5d4ef45-3210-49b0-8f2e-7fbaeaebd61e	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.901443	105.865894	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	\N	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 02:54:19.88338+00	\N	\N
d7830180-f2a8-4ebf-b0f9-0c20543696f6	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.90205	105.866111	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	\N	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 02:54:19.88338+00	\N	\N
d6765528-4c3b-43fe-b26f-e31973f6dd64	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.902838	105.866499	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	\N	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 02:54:19.88338+00	\N	\N
f2f810ef-9a50-4fab-9101-e206e07f9393	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.903645	105.866822	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	\N	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 02:54:19.88338+00	\N	\N
fb4d84be-8723-4a04-be99-22d6651a40b5	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.904575	105.867237	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	\N	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 02:54:19.88338+00	\N	\N
20000000-0000-0000-0000-000000000006	00000000-0000-0000-0000-000000000001	area	20.82448	105.811627	[[20.824609, 105.811058], [20.825009, 105.811658], [20.824409, 105.812158], [20.823909, 105.811558]]	Khu làng nghề giò chả	Làng nghề	\N	Cụm xưởng sản xuất giò chả truyền thống, nơi khách có thể tham quan quy trình chế biến.	\N	\N	53ab9052-d037-4ee2-8693-bddca638db5f	\N	\N	2026-09-21 02:53:32.064886+00	2026-09-22 02:21:13.897573+00	seed	\N
21000000-0000-0000-0000-000000000007	01000000-0000-0000-0000-000000000001	area	20.934771	105.799912	[[20.9349067, 105.7998804], [20.9347026, 105.7998764], [20.9347098, 105.799918], [20.9347814, 105.8000714], [20.9349127, 105.8000561]]	Miếu Cự Đà	Di tích tín ngưỡng	\N	Miếu của làng Cự Đà.	\N	\N	25a5f282-0398-409d-8cb3-eca7c38bbb3c	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
21000000-0000-0000-0000-000000000008	01000000-0000-0000-0000-000000000001	area	20.934738	105.799838	[[20.9349042, 105.7996564], [20.9347102, 105.7996561], [20.934685, 105.7997227], [20.9347026, 105.7998764], [20.9349067, 105.7998804]]	Đàn Xã tắc	Di tích tín ngưỡng	\N	Đàn Xã tắc của làng Cự Đà, nằm gần Miếu Cự Đà.	\N	\N	e21516c2-d281-41dd-8cd1-bd81a2242e68	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
21000000-0000-0000-0000-000000000018	01000000-0000-0000-0000-000000000001	area	20.931987	105.797602	[[20.9321299, 105.7975815], [20.9319746, 105.7975117], [20.9319245, 105.7976351], [20.9320723, 105.7977102]]	Nhà cổ 216	Nhà cổ	\N	Nhà cổ số 216 theo đánh số khảo sát của làng Cự Đà.	\N	\N	3f6916bf-46ea-4718-827d-e6be12f0dbd8	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
21000000-0000-0000-0000-000000000017	01000000-0000-0000-0000-000000000001	area	20.931945	105.797863	[[20.9320222, 105.7978642], [20.9318543, 105.7977999], [20.9317992, 105.7979273], [20.9319746, 105.7979863]]	Nhà cổ cụ Mão	Nhà cổ	\N	Nhà cổ của cụ (ông) Đinh Văn Mão.	\N	\N	e4a074a8-916e-41da-91e1-58236c64ab5b	\N	\N	2026-09-21 02:53:49.357745+00	2026-09-22 09:41:03.564472+00	kml	2026-09-22 09:41:03.564472+00
d813ed0d-366c-4aff-b7b0-033dad2906d4	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.9011793	105.8691984	[[20.9010773, 105.8691295], [20.9010861, 105.8693173], [20.9013257, 105.8693115], [20.9013304, 105.8692462], [20.9014055, 105.8692448], [20.901398, 105.8691469], [20.9013304, 105.8691563], [20.9013254, 105.8691094], [20.9012189, 105.8691054], [20.9011161, 105.8691107]]	Đình làng	Công trình công cộng	\N	\N	\N	\N	86b37b71-bca1-426e-b33c-ea2e00bd7895	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
4182fd39-6d5e-4a40-b050-4f141bc860a4	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.9051203	105.8668491	[[20.9050809, 105.8666389], [20.9049143, 105.8668843], [20.9052237, 105.867052], [20.9053077, 105.866832]]	Văn chỉ	Công trình công cộng	\N	\N	\N	\N	e3737f63-a8e2-4779-9c54-3f65c4959c75	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
3b890288-8a15-4484-a53f-444775d8fd20	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.900917	105.869563	[[20.9009392, 105.8694976], [20.9008929, 105.8695244], [20.9009455, 105.8696156], [20.9009945, 105.869584]]	Miếu	Công trình công cộng	\N	\N	\N	\N	d716fedd-81ac-4975-93e4-e1fc6a8a258f	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
c7ed2238-2c52-42ce-af48-c0dd241e6ef3	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.9021227	105.8682171	[[20.9021225, 105.8681289], [20.9019784, 105.8681477], [20.9019997, 105.8683167], [20.9021538, 105.8682832]]	Nhà thờ họ	Công trình công cộng	\N	\N	\N	\N	20a3f59d-6a00-447d-af52-abb96e8dec13	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
1d8169b9-ba0f-4f00-b00a-eee0a512c7ad	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.82881	105.76242	\N	Đường chính	Giao thông	\N	\N	\N	\N	\N	e246ec92-0dcf-4cc1-966c-9358f1a0d225	\N	2026-09-21 02:54:20.083289+00	2026-09-21 08:08:56.675239+00	\N	\N
d5b7ab2f-ca77-44f3-abfc-bbf37260bc50	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.829	105.76212	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	\N	b5a03a49-a17b-4093-922b-d8c74da96fa9	\N	2026-09-21 02:54:20.083289+00	2026-09-21 08:08:56.675239+00	\N	\N
495a71f9-99a3-418f-98ad-eff84975c53f	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.829	105.76212	\N	Đường theo vật liệu	Giao thông	\N	\N	\N	\N	\N	87a842a9-8588-452a-a36e-7e4abfd06e56	\N	2026-09-21 02:54:20.083289+00	2026-09-21 08:08:56.675239+00	\N	\N
f8687aff-58a8-4df9-bdb1-7fa8db6417d1	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.9011602	105.8696279	[[20.9012425, 105.8693748], [20.9009419, 105.8694794], [20.9009945, 105.869584], [20.9010421, 105.8695666], [20.9010947, 105.8697262], [20.9010371, 105.869761], [20.9012288, 105.8699997], [20.9013553, 105.8699273], [20.9013177, 105.86982], [20.9015107, 105.8697583], [20.9014092, 105.8695666], [20.9013102, 105.8695491], [20.9012588, 105.8694848]]	Chùa Phúc Thái	Công trình công cộng	\N	\N	\N	\N	ea96239d-b238-4bb5-95c8-841ef0617ece	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
6e5fc28f-9e4f-4290-8801-e97581ef232f	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.9003941	105.8655111	[[20.9008606, 105.8655808], [20.9008593, 105.8655593], [20.9004171, 105.8653877], [20.9003682, 105.8655835], [20.9002993, 105.8655634], [20.9003469, 105.8659188], [20.9006789, 105.8660569], [20.9006877, 105.8659952], [20.9007679, 105.8660234]]	Chùa Duyên Trường	Công trình công cộng	\N	\N	\N	\N	6b745826-fcad-476b-b4be-14a7dc65ea55	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
225152ae-cf96-485a-8fb4-5956bbd9bcff	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.8301389	105.76175	[[20.8309873, 105.7614763], [20.8309071, 105.7614307], [20.8303606, 105.7612751], [20.8302829, 105.7612965], [20.8302052, 105.7616721], [20.8299821, 105.7616211], [20.8299369, 105.7617606], [20.8299545, 105.7617981], [20.8299119, 105.7618464], [20.8299018, 105.7619135], [20.8299219, 105.7620181], [20.8300222, 105.7620637], [20.8302277, 105.7621334], [20.8306038, 105.7621924], [20.8306213, 105.7620932], [20.8306489, 105.7620717], [20.830689, 105.7619886], [20.8307391, 105.7619886], [20.8309146, 105.7620288], [20.8310024, 105.7615782]]	Chùa	Di tích tín ngưỡng	\N	\N	\N	\N	\N	c1623f5b-1ecc-483d-8a66-ce205a146a44	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.209138+00	kml	2026-09-22 09:41:04.324841+00
67a60076-5af3-4f6c-89d8-69e21342b36d	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.82896	105.75708	[[20.8292111, 105.7571434], [20.8288501, 105.7570415], [20.8288902, 105.7574867], [20.8290156, 105.7573955], [20.829161, 105.7574224]]	Lũy tre	Cây	\N	\N	\N	\N	d50bdba5-0f4e-48ae-bd56-5f910abe054c	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:41:04.324841+00	kml	2026-09-22 09:41:04.324841+00
5ebaa055-99e0-4897-97c3-0170cbb6d381	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.82528	105.76135	[[20.8253882, 105.7612013], [20.825229, 105.7612174], [20.8252252, 105.7612563], [20.8251989, 105.761259], [20.8251939, 105.7615769], [20.8253217, 105.7615809], [20.8253267, 105.7613583], [20.8253894, 105.7613435]]	Nhà cổ	Nhà cổ	\N	\N	\N	\N	a1192cf2-e61d-44da-bfc2-45f0805381ab	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.220884+00	kml	2026-09-22 09:41:04.324841+00
2d807452-23ae-46f0-9d24-753bea18f1f1	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.70461	105.88849	[[20.7050456, 105.8881426], [20.7050506, 105.8880621], [20.7049578, 105.8880299], [20.704727, 105.8879709], [20.7044861, 105.8879468], [20.7044635, 105.8882284], [20.7043657, 105.8882552], [20.7043456, 105.8884188], [20.7042804, 105.888443], [20.7042754, 105.8885878], [20.7044108, 105.8886415], [20.7047571, 105.8886737], [20.7048374, 105.8887193], [20.704885, 105.8886844], [20.7049879, 105.8884913], [20.7050381, 105.8883223]]	Chùa	Di tích tín ngưỡng	\N	\N	\N	\N	a67f6532-b995-49fc-80f0-a66839742da5	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:58:24.223007+00	kml	2026-09-22 09:41:04.693831+00
8322ba72-4b66-4d0d-911b-61ea10332a97	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.82921	105.76127	\N	Chợ - Chùa	Di tích tín ngưỡng	\N	\N	\N	\N	\N	66fed655-b83e-4ad1-abeb-7367e15922b9	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.248927+00	\N	\N
5e1d7cfb-ad82-4bc9-99ab-dee66e8f0911	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.8291667	105.7608611	\N	Chợ	Công trình công cộng	\N	\N	\N	\N	1e748c5f-e8ea-4a62-bc1e-0c48a73aeb27	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.251026+00	\N	\N
bffd491e-5b22-49d1-b77b-377edd25664a	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.8241944	105.7727778	\N	Cổng làng	Công trình công cộng	\N	\N	\N	\N	c8d93c56-1c23-4c10-a631-d588f40108d4	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.253916+00	\N	\N
106ce802-8e72-434c-9868-3d31349edf42	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.83105	105.76204	\N	Giếng xóm 8 Trung Khu	Mặt nước	\N	\N	\N	\N	\N	0e4dd81d-fccb-4c3b-a568-50feae11c89f	\N	2026-09-21 02:54:20.083289+00	2026-09-21 08:08:56.675239+00	\N	\N
a8c52c9f-dd7e-4ae6-904b-d65e844579c6	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.932731	105.652192	\N	Đường chính	Giao thông	\N	\N	\N	\N	\N	8b053f5c-329a-4bd6-b9bb-54ea8886e6c3	\N	2026-09-21 02:54:20.183232+00	2026-09-21 08:08:56.675239+00	\N	\N
d49c5ca9-4e36-4c36-b31d-417f813d6dcc	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.929908	105.648962	\N	Đất nông nghiệp	Cây	\N	\N	\N	\N	\N	ba9b0df5-8b3f-432f-9963-9d2e2173b826	\N	2026-09-21 02:54:20.183232+00	2026-09-21 08:08:56.675239+00	\N	\N
72157e2d-8d22-4022-b4be-18e3b63f3e4f	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.901426	105.865912	\N	Cổng làng	Công trình công cộng	\N	\N	\N	\N	61f18571-1927-44be-853a-1219cc51cd6d	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
4b9b87fb-0c41-43b4-81a5-38678458a9db	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.90104	105.868522	\N	Cổng xóm Chu My	Công trình công cộng	\N	\N	\N	\N	d4c826dd-3d14-4a7e-b55a-3dc813678dab	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
6940e1f3-7220-4ad7-b51e-98b86692df7c	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.900852	105.869467	\N	Cổng xóm Mỹ Lộc	Công trình công cộng	\N	\N	\N	\N	f61a2137-8f23-4c95-b6e2-d0ff46885dff	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
9ec04fb9-9aef-4c12-9f47-bfc19872c0b2	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.8248611	105.7638333	\N	Giếng - sân - miếu/ban thờ	Mặt nước	\N	\N	\N	\N	1f7b9db3-50b4-41b4-8617-5b53f7bcba73	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-21 07:36:47.329081+00	\N	\N
fafa82e9-5d72-42aa-a059-1cdcce1ba4ea	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.82997	105.76195	\N	Giếng chùa Chuông	Mặt nước	\N	\N	\N	\N	634d87dc-ac9f-4927-a015-d6246fedbf35	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-21 07:36:47.329081+00	\N	\N
de1a0d7d-37f8-4134-b172-1a739c3fa419	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.82485	105.76383	\N	Giếng đền Ông	Mặt nước	\N	\N	\N	\N	d2b35ee0-8d60-4e0e-a09f-c716becbdc2e	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-21 07:36:47.329081+00	\N	\N
c1ed694a-3a3d-4eab-bd63-18c619cd15be	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.929834	105.651204	\N	Giếng	Mặt nước	\N	\N	\N	\N	67358cdb-545f-46c7-92a3-d2fddd14eef3	\N	\N	2026-09-21 02:54:20.183232+00	2026-09-21 07:36:47.425372+00	\N	\N
d3802314-f819-40eb-9447-8d6f23b2a7b6	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.9330857	105.6495636	\N	Nhà cổ Hoàng Hạnh	Nhà ở	\N	\N	\N	\N	210eb910-2ec4-46fa-bcb4-b8fba1ab6228	\N	\N	2026-09-21 02:54:20.183232+00	2026-09-21 07:36:47.425372+00	\N	\N
b7a1677b-f9ea-4a8d-9d1d-5c73ab4ba178	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.9331838	105.6550042	\N	Nhà cổ Nguyễn Hữu Kí	Nhà ở	\N	\N	\N	\N	759452b0-acd1-4cfa-ba1a-52079677487b	\N	\N	2026-09-21 02:54:20.183232+00	2026-09-21 07:36:47.425372+00	\N	\N
2fb52b97-503f-4f3f-8ed0-26595709db20	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.933313	105.649686	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	addb9cd5-c3dd-46ab-b851-d76864947c1f	\N	\N	2026-09-21 02:54:20.183232+00	2026-09-21 07:36:47.425372+00	\N	\N
6b618c65-7d7c-4287-accc-1845babb35cc	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.931248	105.649379	\N	Đường theo vật liệu	Giao thông	\N	\N	\N	\N	66fac027-8aa7-444d-a5cc-b881b610019a	\N	\N	2026-09-21 02:54:20.183232+00	2026-09-21 07:36:47.425372+00	\N	\N
5b519f6e-5d64-4d9b-9623-cb4e78f666cb	8216fe86-f66d-4b19-904b-cbdee0bf1eba	point	20.933209	105.654957	\N	Nhà cổ Nguyễn Hưu Bật	Nhà ở	\N	\N	\N	\N	9f2d3c5d-aae2-4861-ace5-9942fbc36fbc	\N	\N	2026-09-21 02:54:20.183232+00	2026-09-21 07:36:47.425372+00	\N	\N
c2b27d51-0c70-452a-b018-45cf6d7e9c56	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.900121	105.869208	\N	Cổng Đình	Công trình công cộng	\N	\N	\N	\N	1690a67a-0dc8-41f6-849d-3cbd1393ea06	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
a2c635e8-d3df-455e-bd55-f9aaa9e75507	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.908365	105.867581	\N	Giếng_Miếu Trình	Mặt nước	\N	\N	\N	\N	34aca392-9c7b-4801-a445-9f363be35a8d	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
9c831ce5-2e1e-4468-b09c-27ee3a032d5a	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.900985	105.869229	\N	Giếng_Đình Hạ Thái	Mặt nước	\N	\N	\N	\N	992068a5-554f-4066-a9d9-5436bb984fde	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
5d6055d9-7ed7-4889-baf6-60b590360815	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.90453	105.8674	\N	Kênh mương thủy lợi	Mặt nước	\N	\N	\N	\N	a0383b4a-1dcf-4bea-bd13-00bad51a4a90	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
78cb2d2e-69b3-42f3-8b28-5c5b9031961f	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.83304	105.76194	[[20.8331144, 105.7618976], [20.8329439, 105.7618439], [20.8329314, 105.7618761], [20.8328737, 105.7622892], [20.8327258, 105.7629275], [20.8328436, 105.7629597], [20.8329489, 105.762662]]	Nhà thờ	Di tích tín ngưỡng	\N	\N	\N	\N	3f338c54-0f5c-41ad-a8a4-5194337626b9	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.199154+00	kml	2026-09-22 09:41:04.324841+00
1c2471bb-ae76-43fa-a3bf-97fdd76e5ce4	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.82406	105.77167	[[20.8242188, 105.7716964], [20.8241988, 105.7716187], [20.8241775, 105.771624], [20.8241662, 105.771565], [20.8241474, 105.7715208], [20.8240559, 105.771569], [20.8239569, 105.7716227], [20.8239782, 105.7717769]]	Văn chỉ	Di tích tín ngưỡng	\N	\N	\N	\N	7dfaff17-7e72-4741-b443-1432363ec8ad	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.203078+00	kml	2026-09-22 09:41:04.324841+00
b052b7f7-f771-4f18-8457-f4acc92c9b8d	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.8292222	105.7612778	[[20.8298089, 105.7613433], [20.8295582, 105.7612252], [20.8291446, 105.7611019], [20.8290643, 105.7614559], [20.8297312, 105.7616249]]	Đình làng	Di tích tín ngưỡng	\N	\N	\N	\N	f5860608-9c86-490f-a9bb-5e7d307ce66c	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.212157+00	kml	2026-09-22 09:41:04.324841+00
15d48e54-3790-4900-9e87-df730349392f	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.8292222	105.7612778	\N	Đình - Không gian mở (ao, sông, đồng ruộng,…) - Cây đa/đề/si	Di tích tín ngưỡng	\N	\N	\N	\N	c293eb2f-0f84-464d-a29d-1ae0d36cfab9	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.256048+00	\N	\N
b008170d-a82b-4604-9220-5cc6f0f9e2a7	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.9020783	105.8659023	\N	Quán nước	Tiện ích du lịch	\N	\N	\N	\N	5f0d6299-5902-4943-a95e-3b61778c8cc4	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
743a1c86-b0f5-4d4b-a6d8-ed2fe6444edc	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.904621	105.864434	\N	Sông Tô Lịch	Mặt nước	\N	\N	\N	\N	e1cbd163-b746-4aa9-90ad-8ebb5a16f4b6	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
2edf0cc8-fdba-44ff-b83c-5aea246a11b9	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.900975	105.86924	\N	Đình - Không gian mở (ao, sông, đồng ruộng,…) - Cây đa/đề/si	Công trình công cộng	\N	\N	6	Thần phả ghi lại rằng: trước đây vùng đất này hoang vu, cây cối um tùm và dân cư thưa thớt. Lúc đó trong rừng có một con hổ dữ, dân làng gọi là hổ lang thường tìm về bắt người và gia súc ăn thịt. Không thể thu phục được con hổ đã thành tinh này nên hàng năm dân làng đành phải cống nạp cho hổ một người vào ngày 10/11. Trong làng có bà Lạy, một người đàn bà không chồng, không con, thấu hiểu nỗi đau và mất mát của dân làng, bà đã tự nguyện dâng mình cho hổ với mong muốn việc cống nạp này sẽ chấm dứt. Lời khấn cầu nguyện của bà trước trời đất có vẻ linh thiêng và ứng nghiệm, bởi kể từ ngày 10/11 năm đó khi hổ đến vồ bà Lạy và đưa đi mất, người dân không còn thấy hổ quay lại quấy phá nữa. Để tưởng nhớ công ơn của bà, người dân đã xây miếu thờ, sau này bà được tôn làm thành hoàng làng và miếu đó trở thành đình làng Hạ Thái và lấy ngày 10/11 hàng năm là ngày hội làng truyền thống. Đình làng Hạ Thái còn liên quan đến quan võ thời Lê Bùi Sĩ Lương (1544-1597), ông làm đến chức Thái sư kiêm Điện Tiền Chỉ Huy Sứ. Là người thông minh văn võ song toàn, ông có công lớn trong phò Lê, diệt Mạc. Khi đến Hạ Thái, nhận thấy vùng đất nơi này có thế rồng chầu hổ phục, ông đã chọn Hạ Thái để lập gia trang và dạy dân lập nghiệp, vì vậy sau khi mất, ông cũng được tôn là Thành hoàng làng. Lễ hội làng Hạ Thái diễn ra từ ngày 9 đến 11/11 âm lịch hàng năm và thu hút được đông đảo du khách thập phương về tham dự.	1b9c9a9e-97f4-4e42-b816-85c40412a28c	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
297a57a6-4bcc-40fd-8b3b-761f984ff0fd	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.902029	105.866041	\N	Đường chính — Vạn Thọ	Giao thông	\N	\N	\N	\N	3f75ada5-555a-459b-a039-ac3136240c67	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
f27421bb-5b83-4c77-acdc-7d3c68f220af	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.905234	105.865395	\N	Đường chính — Đường Thái Bình	Giao thông	\N	\N	\N	\N	72aed6c4-fcd3-4b88-b18f-a21a436ccf05	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
50cc1810-1a41-4d00-9bf6-d12465585123	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.900851	105.865889	\N	Đường chính — Đường Tràng Hạ	Giao thông	\N	\N	\N	\N	adf2d286-d5c4-4c55-9426-6f4744c30236	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
0556a156-a3e3-4d29-8885-91ac17dcecb9	fdd98e46-3b65-490d-aadc-dbb90eab321d	point	20.900913	105.865586	\N	Đường nhánh/ngõ	Giao thông	\N	\N	\N	\N	a6a5b60c-12a8-471d-9939-8f73a88303fc	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-21 07:36:47.142683+00	\N	\N
0b8904ea-3cca-4609-9d61-fdeb8c753881	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.70798	105.89152	\N	Cây cổ thụ giữa làng	Cây	\N	\N	\N	\N	03a0d2b3-7628-42c8-8307-c8615744fdb1	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
2c84ff41-5bbe-4314-b600-a89f0735e9d0	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.708618	105.889015	\N	Cây cổ thụ đầu làng	Cây	\N	\N	\N	\N	269fbf49-6a9b-45f0-a0c9-8dce7ee0f658	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
66cf0b99-c24b-447c-b3f4-7d2d2a506cb7	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.70773	105.88983	\N	Ao	Mặt nước	\N	\N	\N	\N	20ef360d-5048-4662-94a5-cffb58cbacd7	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
03111ee1-5fca-41d0-888e-9bb7f58a31b2	c33319de-4845-41bf-94c1-3fa501e5e867	point	20.70866	105.88913	\N	Đình - Không gian mở (ao, sông, đồng ruộng,…) - Cây đa/đề/si	Giao thông	\N	\N	\N	Đầu thế kỷ XVI	a7f493a7-e3b5-4ef3-8cbe-c8cdeb131034	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-21 07:36:47.237447+00	\N	\N
d198a4db-d65d-4136-88d7-fe4692f03199	09ee09b0-41f2-429c-a515-0cd2592edc44	point	20.8291944	105.75675	\N	Sông	Mặt nước	\N	\N	\N	\N	ce895417-c8e4-4dee-b152-d9eb0fc65c69	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-21 07:36:47.329081+00	\N	\N
0d0db01e-2bbf-4d28-a289-c9c2bdc9a3c7	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.9052558	105.8654909	[[20.9055504, 105.8658328], [20.9055682, 105.8658089], [20.9054126, 105.8656049], [20.9052948, 105.8654734], [20.9050793, 105.8652991], [20.9048012, 105.8658221], [20.9052647, 105.8661842]]	Miếu Nghè	Công trình công cộng	\N	\N	\N	\N	3785f9a9-cd3d-44a6-a248-4175442e51f5	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
cb162594-8acc-419f-8e48-2ccf168f6288	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.900687	105.870672	[[20.9007107, 105.8705404], [20.9005027, 105.8707093], [20.9005591, 105.8707992], [20.9005466, 105.8708247], [20.9005742, 105.8708622], [20.9008147, 105.8706758]]	Nhà cổ bà Dịp	Nhà ở	\N	\N	\N	\N	3779a55e-746f-4ef5-b475-25d38eda93c0	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
889cf51e-4283-401e-bef4-78bef4e0f992	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.70822	105.89377	[[20.7082548, 105.8937378], [20.7081469, 105.8937553], [20.7081507, 105.8938049], [20.7082561, 105.8937995]]	Cổng làng	Giao thông	\N	\N	\N	\N	ec76f089-54fe-4c6f-8729-d46ff4826859	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:41:04.693831+00	kml	2026-09-22 09:41:04.693831+00
ceb78e41-82e6-4d87-8155-7ea70ec1a83e	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.8248611	105.7638333	[[20.8248946, 105.7635494], [20.8245938, 105.7636058], [20.8245512, 105.7636433], [20.8246063, 105.763941], [20.8249347, 105.7638552], [20.8249448, 105.7638284]]	Đền Ông	Di tích tín ngưỡng	\N	\N	\N	\N	f00dc361-ab8f-4d6a-b253-71689346e8fd	\N	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.190117+00	kml	2026-09-22 09:41:04.324841+00
60353b9d-c4e4-4d1e-a186-5b75ba80984a	09ee09b0-41f2-429c-a515-0cd2592edc44	area	20.82704	105.76013	[[20.8277575, 105.7598515], [20.8269853, 105.7596262], [20.8263085, 105.7595082], [20.8263137, 105.7598172], [20.8263736, 105.759932], [20.8263034, 105.7601948], [20.8264951, 105.7603759], [20.8270505, 105.7604148], [20.8277424, 105.7602753], [20.8277675, 105.7601787]]	Đền Thượng	Di tích tín ngưỡng	\N	\N	\N	\N	\N	c8f339e6-0529-472d-9237-b099b18bff1d	\N	2026-09-21 02:54:20.083289+00	2026-09-22 09:58:24.196394+00	kml	2026-09-22 09:41:04.324841+00
1cc62aa3-f869-4470-92fe-2a4d62c366a8	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.70868	105.88979	[[20.7088699, 105.8903892], [20.7088197, 105.8903785], [20.7087858, 105.8904804], [20.708836, 105.8905072]]	Nhà thờ họ	Di tích tín ngưỡng	\N	\N	\N	\N	0cefd584-c02c-432c-a4fe-76884a397ccc	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:58:24.225875+00	kml	2026-09-22 09:41:04.693831+00
60217152-a88b-4f05-8ee9-593985d9fb23	fdd98e46-3b65-490d-aadc-dbb90eab321d	area	20.9087768	105.867805	[[20.9088795, 105.8677606], [20.9088394, 105.8677418], [20.9088194, 105.8677941], [20.9088645, 105.8678155]]	Miếu Trình	Công trình công cộng	\N	\N	\N	\N	ea6dc5d0-8601-40b5-ac9a-3aee5b66605e	\N	\N	2026-09-21 02:54:19.88338+00	2026-09-22 09:41:03.931269+00	kml	2026-09-22 09:41:03.931269+00
53fa7c45-dac2-49cc-a4c1-11f6a7db5c24	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.70866	105.88913	[[20.7086716, 105.8892546], [20.7085349, 105.8891741], [20.708501, 105.8892733], [20.7085349, 105.8892908], [20.708516, 105.8893458], [20.7085813, 105.8893793], [20.7085988, 105.8893323], [20.7086327, 105.8893498]]	Đình làng	Di tích tín ngưỡng	\N	\N	\N	\N	ea3bae9b-e217-4b55-add3-166056567e72	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:58:24.233+00	kml	2026-09-22 09:41:04.693831+00
010f644d-0f9d-4977-b357-138f306501e2	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.70774	105.89141	[[20.7080701, 105.8914797], [20.7080149, 105.8914314], [20.7077213, 105.8912785], [20.7077289, 105.8911873], [20.7076737, 105.8911363], [20.7075633, 105.8915145], [20.707774, 105.8915896], [20.7079973, 105.8916299]]	Giếng	Mặt nước	\N	\N	\N	\N	2b8f688c-dea2-4876-94b7-132e89f3e5a3	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:41:04.693831+00	kml	2026-09-22 09:41:04.693831+00
78ba5481-fe5f-41a4-b64c-ca81e771ce53	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.708126	105.891735	[[20.7082153, 105.8919965], [20.7081513, 105.8919804], [20.7081425, 105.8920475], [20.7082103, 105.8920703]]	Nhà Tây	Nhà cổ	\N	\N	\N	\N	71d61460-8d41-4597-83dd-a6d57ee2c834	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:58:24.228018+00	kml	2026-09-22 09:41:04.693831+00
20000000-0000-0000-0000-000000000003	00000000-0000-0000-0000-000000000001	area	20.827972	105.811889	[[20.8282476, 105.8113132], [20.8281662, 105.8113789], [20.8281348, 105.8113749], [20.828096, 105.8114151], [20.8280784, 105.8114312], [20.8281072, 105.811462], [20.828091, 105.8114755], [20.8280784, 105.8115479], [20.8280183, 105.811623], [20.8280333, 105.8117236], [20.8279568, 105.8118174], [20.8279067, 105.8118845], [20.8279681, 105.8119368], [20.8280308, 105.8119663], [20.8281135, 105.8119797], [20.8281712, 105.811922], [20.8282113, 105.8118805], [20.8282514, 105.8118805], [20.8283968, 105.8119462], [20.8284457, 105.8119529], [20.8284921, 105.8118764], [20.8285497, 105.8117745], [20.8285372, 105.8116592], [20.8285121, 105.8115707], [20.8284607, 105.8114312], [20.8283993, 105.8113802], [20.8283354, 105.8113239], [20.828279, 105.8112944]]	Chùa Sùng Phúc	Di tích tín ngưỡng	\N	Ngôi chùa cổ của làng, điểm sinh hoạt Phật giáo và tham quan văn hóa tâm linh.	\N	\N	a9a973fe-725d-4eec-b818-22e86127d74b	fa2eb908-9ea5-4743-ab85-6038e85d3099	44000000-0000-0000-0000-000000000002	2026-09-21 02:53:32.060957+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
6e4bdb96-4631-4af9-80d2-ff2a3f29bf8c	c33319de-4845-41bf-94c1-3fa501e5e867	area	20.70818	105.89277	[[20.7084718, 105.8903259], [20.7083939, 105.8903203], [20.7083726, 105.8904611], [20.7084566, 105.8904799]]	Nhà cổ bác Tứ	Nhà cổ	\N	\N	\N	\N	d899e960-389d-4472-a9b1-922ee984db1b	\N	\N	2026-09-21 02:54:19.981247+00	2026-09-22 09:58:24.230928+00	kml	2026-09-22 09:41:04.693831+00
8987a84a-b2d7-4423-86b9-94d27953c155	8216fe86-f66d-4b19-904b-cbdee0bf1eba	area	20.932659	105.65099	[[20.9322295, 105.6509892], [20.9322245, 105.6514224], [20.9327982, 105.6514774], [20.9328117, 105.6508899]]	Quán	Di tích tín ngưỡng	\N	\N	15	\N	\N	c9d8bc31-098f-4a29-b31c-f395e856a46e	\N	2026-09-21 02:54:20.183232+00	2026-09-22 09:58:24.234987+00	kml	2026-09-22 09:41:05.058931+00
7cf72fe0-3aa2-4c0e-9c57-e926d04db3ba	8216fe86-f66d-4b19-904b-cbdee0bf1eba	area	20.93417	105.651406	[[20.9337181, 105.6511925], [20.9337043, 105.6513856], [20.9337644, 105.6513923], [20.933787, 105.6514044], [20.9338797, 105.6516056], [20.9339912, 105.6516793], [20.9341177, 105.6517035], [20.9342066, 105.6517008], [20.9343431, 105.6516418], [20.9344671, 105.6515788], [20.9344684, 105.6514929], [20.9344809, 105.6513709], [20.9344697, 105.6512877], [20.9344258, 105.6511912], [20.9343569, 105.6510866], [20.9342479, 105.6510437], [20.9341427, 105.6510893], [20.9338734, 105.651163]]	Đình làng	Di tích tín ngưỡng	\N	\N	\N	\N	\N	4ea27482-0697-410f-9f0f-f82330802d3a	\N	2026-09-21 02:54:20.183232+00	2026-09-22 09:58:24.236898+00	kml	2026-09-22 09:41:05.058931+00
f15021e9-5cee-4574-8b56-6d22a288dcf1	8216fe86-f66d-4b19-904b-cbdee0bf1eba	area	20.933464	105.648107	[[20.9335845, 105.6478903], [20.9335327, 105.647881], [20.9332421, 105.6479856], [20.9332294, 105.6480065], [20.9332563, 105.648192], [20.93325, 105.6482148], [20.9333214, 105.6482269], [20.9334229, 105.6482135], [20.9334392, 105.6482551], [20.9335193, 105.6482336], [20.9336684, 105.6481464], [20.9336446, 105.6480633]]	Chùa Hạ Phú Vinh	Di tích tín ngưỡng	\N	\N	\N	\N	\N	0711e7d6-28f5-4a4b-8f5e-18a7bf9a53d0	\N	2026-09-21 02:54:20.183232+00	2026-09-22 09:58:24.238864+00	kml	2026-09-22 09:41:05.058931+00
41033f55-90ea-4539-aba1-1ea4ed330048	8216fe86-f66d-4b19-904b-cbdee0bf1eba	area	20.930722	105.6494877	[[20.9307362, 105.6494351], [20.9306285, 105.6493761], [20.9305809, 105.6495169], [20.9306798, 105.6495585]]	Chùa Cổ Ngỗng	Di tích tín ngưỡng	\N	\N	\N	\N	\N	c1df5703-d8dd-4049-b76c-0ffd049eead2	\N	2026-09-21 02:54:20.183232+00	2026-09-22 09:58:24.240986+00	kml	2026-09-22 09:41:05.058931+00
f06f841f-b468-4f92-b6c6-72dd66815c99	8216fe86-f66d-4b19-904b-cbdee0bf1eba	area	20.932581	105.651633	[[20.9326738, 105.6515667], [20.9322253, 105.6515144], [20.9322116, 105.6516713], [20.9326625, 105.6517196]]	Chợ	Công trình công cộng	\N	\N	10	\N	\N	c8c95e67-c125-49a4-9dec-70fd3e85a14d	\N	2026-09-21 02:54:20.183232+00	2026-09-22 09:58:24.243882+00	kml	2026-09-22 09:41:05.058931+00
20000000-0000-0000-0000-000000000007	00000000-0000-0000-0000-000000000001	area	20.824639	105.811861	[[20.8250506, 105.81205], [20.8247886, 105.8116624], [20.8244677, 105.8118958], [20.8245793, 105.8120513], [20.8246282, 105.8121103], [20.82482, 105.8123249]]	Chùa Hậu	Di tích tín ngưỡng	\N	Ngôi chùa của làng, nằm ở phía sau khu dân cư, phân biệt với Chùa Sùng Phúc.	\N	\N	9b8404b3-a7ca-4dd9-9391-1587f4ff914d	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
20000000-0000-0000-0000-000000000016	00000000-0000-0000-0000-000000000001	area	20.827222	105.810694	[[20.8271744, 105.8106108], [20.8271443, 105.8106617], [20.8272609, 105.8107395], [20.8273386, 105.8106134], [20.8272547, 105.8105276]]	Đền Chợ	Di tích tín ngưỡng	\N	Đền nằm gần khu vực chợ làng.	\N	\N	eb9d5804-4e9f-4d10-807b-556e71f48d01	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
20000000-0000-0000-0000-000000000010	00000000-0000-0000-0000-000000000001	area	20.823861	105.810306	[[20.8239786, 105.8102268], [20.8238833, 105.8100994], [20.823783, 105.8099491], [20.8236615, 105.8099974], [20.8236878, 105.8101503], [20.8238294, 105.8103381]]	Quán Mới	Công trình công cộng	\N	Quán của làng, điểm sinh hoạt cộng đồng.	\N	\N	3722c3ba-14ac-4d31-a7cb-7df911859b6f	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
20000000-0000-0000-0000-000000000013	00000000-0000-0000-0000-000000000001	area	20.826417	105.809639	[[20.8264089, 105.8095829], [20.826365, 105.8095668], [20.8263425, 105.8096392], [20.8264064, 105.8096325]]	Đền Ngõ Họ	Di tích tín ngưỡng	\N	Đền nhỏ nằm trong ngõ họ của làng.	\N	\N	67c7c406-61ae-4d0e-b09f-7f560a3cf4b7	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-23 14:21:45.081329+00	kml	2026-09-23 14:21:45.081329+00
20000000-0000-0000-0000-000000000012	00000000-0000-0000-0000-000000000001	area	20.826139	105.810306	[[20.8262705, 105.8102431], [20.82609, 105.8102069], [20.8260386, 105.8104121], [20.8261151, 105.8104322], [20.8261088, 105.8104631], [20.8262781, 105.8104564], [20.8262906, 105.810274], [20.8262693, 105.8102659]]	Nhà Cổ (nhà Cụ Sẩm)	Nhà cổ	\N	Nhà cổ của gia đình cụ Sẩm, một trong những nhà cổ còn giữ được kiến trúc truyền thống.	\N	\N	0fe8039c-8f53-4083-b526-e479013bdd1a	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
20000000-0000-0000-0000-000000000019	00000000-0000-0000-0000-000000000001	area	20.826252	105.813035	[[20.8264462, 105.8129236], [20.8263103, 105.8127932], [20.8261999, 105.8129407], [20.8261861, 105.8130279], [20.8262783, 105.8131221]]	Nhà cổ khum biếc tên	Nhà cổ	\N	Nhà cổ được ghi nhận trong khảo sát bản đồ làng.	\N	\N	f2d88db7-929d-49fa-8c06-27f0b30f0002	\N	\N	2026-09-21 02:53:49.164654+00	2026-09-23 15:33:16.213384+00	kml	2026-09-23 15:33:16.213384+00
\.


--
-- Data for Name: villages; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.villages (id, name, aliases, admin_location, google_maps_link, founded_period, brand_identity, name_meaning, main_occupations, natural_features, site_selection_history, morphology_description, morphology_diagram_media_id, created_at, updated_at, slug, cover_media_id) FROM stdin;
01000000-0000-0000-0000-000000000001	Làng Cự Đà	{"làng Ngô Khê"}	xã Bình Minh, Hà Nội (trước là xã Cự Khê, huyện Thanh Oai, Hà Nội)	\N	TK1	\N	tên Ngô Khê: Ngô là vùng đất mà họ NGô sinh sống, Khê theo tiếng Hán là Khe lạch. Có học giả lại cho rằng Ngô trong Ngô Khê là để chỉ cây duối, cây vông, nhũng loại cây mọc rất nhiều trong làng. \nTK17 đổi tên làng Cự Đà, tên gọi làng cũ của họ Trịnh ở THanh Hóa	{"nghề làm miến","nghề làm tương"}	Làng chạy dài ven sông Nhuệ	Nằm ở vị trí thuận lợi cho giao thông đường thủy, phát triển hoạt động giao lưu buôn bán với kinh thành và các vùng khác. Cự Đà cách con đường Thiên lý Tây đạo chạy từ vùng núi phía Tây qua huyện Chương Đức về vùng đồng bằng 5km (theo sách "Lư sử điển yếu điều lệ" (1974))	Cấu trúc của ngôi làng theo hình lược, bám ven sông Nhuệ. Từ đường làng lớn tỏa ra hàng chục con ngõ đâm ngang, hẹp, lát gạch đỏ. Cổng ngõ nào cũng chạy ra đến bờ sông với những thềm gạch vươn tận mép ước. Quy hoạch tự nhiên của làng đúng theo mô hình “nhất cận thị, nhì cận giang” điển hình cho làng Việt cổ vừa nông nghiệp, vừa thương mại.	\N	2026-09-21 02:53:49.354+00	2026-09-25 15:13:18.902718+00	cu-da	aef52a73-4dde-4edf-9c54-e08ba739d014
fdd98e46-3b65-490d-aadc-dbb90eab321d	Làng Hạ Thái	{"Cự Tràng (tên cũ)","Đông Thái (tên cũ)"}	Xã Hồng Vân, Hà Nội	\N	Khoảng thế kỷ XVII (nghề sơn) / Thế kỷ XVIII (làng)	Làng nghề sơn mài truyền thống Hạ Thái - Điểm du lịch làng nghề.	"Hạ Thái" có nghĩa là "vùng đất thấp, bình yên và thái bình".	{"Nghề sơn mài truyền thống (từ sơn son thiếp vàng sang sơn mài mỹ nghệ","sản xuất tranh và đồ gia dụng xuất khẩu)."}	Địa hình bằng phẳng, nằm trong vùng khí hậu nhiệt đới gió mùa, có sông Tô Lịch chảy qua.	Nằm ở vùng đồng bằng bồi tụ, ven sông Tô Lịch, thuận lợi giao thông đường thủy và gần các trục giao thông quan trọng (QL1A, đường sắt Bắc Nam, đường cao tốc Pháp Vân - Cầu Giẽ).	Cấu trúc "Xương cá hội tụ". Các trục ngõ nhánh đổ về trục đường chính hướng ra đình làng và khu không gian sản xuất chung ven trục lộ lớn.	\N	2026-09-21 02:54:19.878+00	2026-09-23 15:44:23.168018+00	ha-thai	\N
c33319de-4845-41bf-94c1-3fa501e5e867	Làng Cựu	{}	Xã Chuyên Mỹ, TP. Hà Nội (trước xã Vân Từ, huyện Phú Xuyên, TP. Hà Nội)	\N	khoảng thế kỷ XIII	Làng nghề may Comple - Veston, Làng biệt thự Pháp cổ	Tên gọi Làng Cựu mang ý nghĩa gốc là "Kẻ Cựu", dùng để chỉ vùng đất cổ kính, lâu đời.	{"Trước đây","người dân trong làng chủ yếu làm nông và làm may Comple - Veston. Những năm gần đây","người dân làm nhiều các nghề khác nhau: nông nghiệp","may mặc","dày da","buôn bán...."}	Địa hình đồng chiêm trũng: Xưa kia, làng tọa lạc trên một vùng đồng chiêm trũng thuộc phía Tây Nam huyện Phú Xuyên, mỗi năm chỉ cấy được một vụ lúa. Địa hình này khiến khu vực phía Nam của đường làng chính trước đây thường xuyên bị ngập nước vào mùa nước lên. Phải đến những năm 1960, nhờ sự biến đổi của chế độ thủy văn, làng mới không còn bị ngập nữa. Làng được bao bọc xung quanh bởi hệ thống đồng ruộng rộng lớn. Cảnh quan cánh đồng lúa xanh mướt hay vàng ươm vào mùa gặt không chỉ tạo nên khung cảnh yên bình tiêu biểu của làng quê mà còn là nguồn cung cấp thực phẩm chính cho người dân.	Làng được xây dựng trên một gò đất cao của vùng đồng chiêm trũng, mỗi năm làng chỉ cấy được một vụ lúa. Làng cũng được tiếp cận với 1 nhánh của sông Nhuệ (vị trí ao làng gần Đình hiện nay).	\N	\N	2026-09-21 02:54:19.976+00	2026-09-23 15:44:23.168018+00	lang-cuu	\N
00000000-0000-0000-0000-000000000001	Làng Ước Lễ	{"làng Chảy"}	xã Dân Hòa, Hà Nội (trước là xã Tân Ước, huyện Thanh Oai, Hà Nội)	\N	TK 16	Làng giò chả	Ước, Lễ là chữ dùng xuất phát từ lời của Khổng Tử (Bác học dĩ văn, ước chi dĩ lễ), ý nói muốn học rộng thì phải dựa vào văn (tức văn hoá); học đã rộng rồi thì phải chế định (Ước) bằng Lễ, ấy là điều cần thiết của người học rộng. Lấy Ước Lễ đặt tên làng thể hiện quan niệm trong cuộc sống phải luôn luôn giữ lễ.	{"Làm giò chả","làm nông"}	Làng có hệ thống cây xanh mặt nước bao quanh, không có các hộ chăn nuôi quy mô lớn cũng như hộ sản xuất quy mô lớn ảnh hưởng đến ô nhiễm môi trường	ngày xưa, ông Lữ Gia đánh trận thua, chạy về tới cây đa trước cổng làng đầu đã bị chém gần lìa, gặp một bà cụ người làng, hỏi: Người bị chém đứt đầu có sống được không? Bà cụ nói: Sống thế nào được. Ông bèn dứt đầu ra khỏi cổ rồi ngã xuống ngựa. Dân tôn ông làm Thành hoàng, thờ cúng ở đình cho đến nay.	Cấu trúc mạng lưới giao thông làng Ước Lễ là cấu trúc hình xương cá, đặc trưng cấu trúc làng truyền thống vùng đồng bằng Bắc Bộ. Đường làng chính đóng vai trò là trục xương sống kết nối tất cả các không gian trong làng; các công trình công cộng truyền thống nằm tại các vị trí quan trọng về mặt hình thái hình học trên đường làng chính.	\N	2026-09-21 02:53:32.052+00	2026-09-25 15:15:07.654908+00	lang-uoc-le	62c04f32-c0fa-4cfd-9e4a-6f6e8a6aee9a
09ee09b0-41f2-429c-a515-0cd2592edc44	Làng Chuông	{"Trang Thì Trung (hoặc trang Thời Trung): Đây là tên gọi ban đầu của làng từ thế kỷ thứ 8"}	Xã Thanh Oai, TP. Hà Nội (trước xã Phương Trung, huyện Thanh Oai, Hà Nội)	\N	thế kỷ thứ 8 (cụ thể là vào năm 791 - năm Tân Mùi)	Làng Nón	Từ "Chuông" không chỉ đơn thuần là tên làng mà còn mang ý nghĩa ngợi ca nghề truyền thống nơi đây. "Chuông" mang ý nghĩa chỉ chiếc nón đẹp, được làm công phu và tỉ mỉ như việc đúc chuông. Lời ca ngợi này được đúc kết qua câu đối cổ truyền lại: "Ngọn lá xuân phong khuôn khéo lựa / Sợi vàng tạo hóa nắn nên Chuông"	{"Việc làm nón được thực hiện 100% bằng tay","đòi hỏi sự khéo léo qua nhiều công đoạn phức tạp từ phơi",vò,"hơ diêm sinh","là phẳng lá cho đến lợp nón và thắt nón. Nón Chuông luôn nổi bật nhờ kết cấu chèn một lớp mo nang ở giữa hai lớp lá giúp nón cực kỳ bền chắc"}	Làng là nằm ven đê sông Đáy. Trước đây, làng sở hữu một hệ sinh thái tự nhiên phong phú với nhiều diện tích mặt nước, cây xanh và đa dạng các loài động vật. Làng có một hệ thống mặt nước tự nhiên rộng lớn bao gồm các ao hồ, kênh rạch và đặc biệt là rất nhiều chiếc giếng làng lớn với đường kính từ 15-18m. Hiện nay, do tốc độ xây dựng, lấn chiếm đất đai và mật độ dân cư gia tăng quá nhanh, hệ sinh thái cảnh quan tự nhiên của làng đã bị biến đổi và suy giảm nghiêm trọng về cả số lượng lẫn chất lượng.	Ngôi làng này đã tồn tại từ thời kỳ nước ta thuộc ách đô hộ của nhà Đường (năm 603-906). Tương truyền, làng từng có vai trò chiến lược quan trọng khi được danh tướng Phùng Hưng chọn làm nơi đóng đồn binh, cho binh lính nghỉ ngơi và luyện quân . Dọc theo dòng sông Đáy, từ bàn đạp là làng Chuông, nghĩa quân đã tiến qua Thạch Bích, Triều Khúc để đánh thẳng vào thành Tống Bình, lật đổ ách thống trị của nhà Đường và giành quyền tự chủ cho đất nước vào thế kỷ thứ VII	\N	\N	2026-09-21 02:54:20.078+00	2026-09-25 15:11:44.426653+00	lang-chuong	dd7c9441-08d8-4b32-bb3b-67674a8dca68
8216fe86-f66d-4b19-904b-cbdee0bf1eba	Làng Phú Vinh	{"Phú Hoa Trang (Trời phú cho dân có bàn tay lụa)"}	Xã Phú Nghĩa, TP Hà Nội (trước là xã Phú Nghĩa, huyện Chương Mỹ, thành phố Hà Nội)	https://www.google.com/maps/d/u/0/edit?mid=1xHfNYeAgUeXDI4Sof9d3GT669B_PDXY&usp=sharing	Từ năm 1700 (đầu TK 17)	Làng nghề mây tre đan truyền thống đã tồn tại và phát triển hơn 400 năm	Tên gọi ban đầu là làng Phú Hoa Trang (Trời phú cho dân có bàn tay lụa), vì người dân nơi đây có bàn tay khéo léo, điệu nghệ, giỏi đan lát mây tre.\nPhú Vinh (Lời chúc cát lành, biểu trưng cho sự giàu đẹp và vinh hiển)	{"Làng Phú Vinh được biết đến là nguồn cội của rất nhiều thế hệ nghệ nhân tài hoa từng làm ra nhiều sản phẩm mây tre đan độc đáo. Những người nghệ nhân có những kỹ năng","kỹ thuật đường đan tỉ mỉ","cầu kì","sản phẩm họ làm thường có hoa văn đan tết tinh xảo","độc đáo","mà người ta chỉ tìm thấy ở làng nghề Phú Vinh. Theo lịch sử hàng trăm năm của làng nghề","mây tre đan Phú Vinh luôn được nhiều người biết đến bởi giá trị truyền thống","cũng như tính nghệ thuật đỉnh cao qua sản phẩm của các nghệ nhân làng nghề."}	Làng Phú Vinh có bị trí thuận lợi đi qua một số tuyến quốc lộ và tỉnh lộ quan trọng thuận lợi cho việc tiếp cận của các đoàn khách du lịch. Về đặc điểm tự nhiên thì làng Phú Vinh nằm ở ven đê sông Đáy nên vốn có một hệ sinh thái trù phú và quỹ đất nông nghiệp và những cảnh quan nông nghiệp đặc trưng của làng ngoại thành Hà Nội. Đây cũng là một ưu điểm bổ trợ cho việc quy hoạch và phát triển các sản phẩm du lịch đến làng nghề. Ngày nay, tốc độ, mật độ xây dựng và cư trú của người dân gia tăng nhanh chóng và vì vậy lấn chiếm diện tích lớn của hệ sinh thái cảnh quan tự nhiên	\N	làng có hình dáng của một chiếc lá, được tạo hình rõ nét bởi một bên là sông Hồng và một bên đê bao quanh khép kín. Với trục chính chạy xuyên suốt từ đầu đến cuối làng, các ngõ song song tạo thành gân lá.	\N	2026-09-21 02:54:20.179+00	2026-09-25 15:14:42.195956+00	phu-vinh	6ee01a39-418e-4919-97b8-1d21f7d30dac
\.


--
-- Name: craft_products_internal craft_products_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.craft_products_internal
    ADD CONSTRAINT craft_products_internal_pkey PRIMARY KEY (id);


--
-- Name: craft_products_internal craft_products_internal_product_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.craft_products_internal
    ADD CONSTRAINT craft_products_internal_product_id_key UNIQUE (product_id);


--
-- Name: craft_products craft_products_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.craft_products
    ADD CONSTRAINT craft_products_pkey PRIMARY KEY (id);


--
-- Name: decorative_art_items decorative_art_items_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.decorative_art_items
    ADD CONSTRAINT decorative_art_items_pkey PRIMARY KEY (id);


--
-- Name: heritage_building_technical_details heritage_building_technical_details_building_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.heritage_building_technical_details
    ADD CONSTRAINT heritage_building_technical_details_building_id_key UNIQUE (building_id);


--
-- Name: heritage_building_technical_details heritage_building_technical_details_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.heritage_building_technical_details
    ADD CONSTRAINT heritage_building_technical_details_pkey PRIMARY KEY (id);


--
-- Name: heritage_buildings heritage_buildings_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.heritage_buildings
    ADD CONSTRAINT heritage_buildings_pkey PRIMARY KEY (id);


--
-- Name: history_stories history_stories_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.history_stories
    ADD CONSTRAINT history_stories_pkey PRIMARY KEY (id);


--
-- Name: intangible_heritage_items intangible_heritage_items_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.intangible_heritage_items
    ADD CONSTRAINT intangible_heritage_items_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (filename);


--
-- Name: sites sites_heritage_building_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_heritage_building_id_key UNIQUE (heritage_building_id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: villages uq_villages_slug; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT uq_villages_slug UNIQUE (slug);


--
-- Name: villages villages_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT villages_pkey PRIMARY KEY (id);


--
-- Name: idx_craft_products_village_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_craft_products_village_id ON public.craft_products USING btree (village_id);


--
-- Name: idx_decorative_art_items_building_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_decorative_art_items_building_id ON public.decorative_art_items USING btree (building_id);


--
-- Name: idx_heritage_buildings_village_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_heritage_buildings_village_id ON public.heritage_buildings USING btree (village_id);


--
-- Name: idx_history_stories_site_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_history_stories_site_id ON public.history_stories USING btree (site_id);


--
-- Name: idx_history_stories_village_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_history_stories_village_id ON public.history_stories USING btree (village_id);


--
-- Name: idx_intangible_heritage_items_village_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_intangible_heritage_items_village_id ON public.intangible_heritage_items USING btree (village_id);


--
-- Name: idx_media_owner; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_media_owner ON public.media USING btree (owner_entity_type, owner_entity_id);


--
-- Name: idx_sites_category; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_sites_category ON public.sites USING btree (category, sub_category);


--
-- Name: idx_sites_village_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_sites_village_id ON public.sites USING btree (village_id);


--
-- Name: idx_sites_with_boundary; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_sites_with_boundary ON public.sites USING btree (village_id) WHERE (boundary IS NOT NULL);


--
-- Name: craft_products_internal trg_craft_products_internal_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_craft_products_internal_updated_at BEFORE UPDATE ON public.craft_products_internal FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: craft_products trg_craft_products_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_craft_products_updated_at BEFORE UPDATE ON public.craft_products FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: decorative_art_items trg_decorative_art_items_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_decorative_art_items_updated_at BEFORE UPDATE ON public.decorative_art_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: heritage_building_technical_details trg_heritage_building_technical_details_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_heritage_building_technical_details_updated_at BEFORE UPDATE ON public.heritage_building_technical_details FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: heritage_buildings trg_heritage_buildings_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_heritage_buildings_updated_at BEFORE UPDATE ON public.heritage_buildings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: history_stories trg_history_stories_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_history_stories_updated_at BEFORE UPDATE ON public.history_stories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: intangible_heritage_items trg_intangible_heritage_items_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_intangible_heritage_items_updated_at BEFORE UPDATE ON public.intangible_heritage_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: media trg_media_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_media_updated_at BEFORE UPDATE ON public.media FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: sites trg_sites_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_sites_updated_at BEFORE UPDATE ON public.sites FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: villages trg_villages_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_villages_updated_at BEFORE UPDATE ON public.villages FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: craft_products_internal craft_products_internal_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.craft_products_internal
    ADD CONSTRAINT craft_products_internal_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.craft_products(id) ON DELETE CASCADE;


--
-- Name: craft_products craft_products_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.craft_products
    ADD CONSTRAINT craft_products_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.villages(id) ON DELETE CASCADE;


--
-- Name: decorative_art_items decorative_art_items_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.decorative_art_items
    ADD CONSTRAINT decorative_art_items_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.heritage_buildings(id) ON DELETE CASCADE;


--
-- Name: heritage_building_technical_details heritage_building_technical_de_floor_plan_drawing_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.heritage_building_technical_details
    ADD CONSTRAINT heritage_building_technical_de_floor_plan_drawing_media_id_fkey FOREIGN KEY (floor_plan_drawing_media_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: heritage_building_technical_details heritage_building_technical_detai_section_drawing_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.heritage_building_technical_details
    ADD CONSTRAINT heritage_building_technical_detai_section_drawing_media_id_fkey FOREIGN KEY (section_drawing_media_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: heritage_building_technical_details heritage_building_technical_details_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.heritage_building_technical_details
    ADD CONSTRAINT heritage_building_technical_details_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.heritage_buildings(id) ON DELETE CASCADE;


--
-- Name: heritage_buildings heritage_buildings_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.heritage_buildings
    ADD CONSTRAINT heritage_buildings_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.villages(id) ON DELETE CASCADE;


--
-- Name: history_stories history_stories_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.history_stories
    ADD CONSTRAINT history_stories_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: history_stories history_stories_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.history_stories
    ADD CONSTRAINT history_stories_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.villages(id) ON DELETE CASCADE;


--
-- Name: intangible_heritage_items intangible_heritage_items_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.intangible_heritage_items
    ADD CONSTRAINT intangible_heritage_items_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.villages(id) ON DELETE CASCADE;


--
-- Name: sites sites_cover_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_cover_media_id_fkey FOREIGN KEY (cover_media_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: sites sites_heritage_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_heritage_building_id_fkey FOREIGN KEY (heritage_building_id) REFERENCES public.heritage_buildings(id) ON DELETE SET NULL;


--
-- Name: sites sites_panorama_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_panorama_media_id_fkey FOREIGN KEY (panorama_media_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: sites sites_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.villages(id) ON DELETE CASCADE;


--
-- Name: villages villages_cover_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT villages_cover_media_id_fkey FOREIGN KEY (cover_media_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: villages villages_morphology_diagram_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT villages_morphology_diagram_media_id_fkey FOREIGN KEY (morphology_diagram_media_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO lang_uoc_le_readwrite;


--
-- Name: TABLE craft_products; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.craft_products TO lang_uoc_le_readwrite;


--
-- Name: TABLE craft_products_internal; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.craft_products_internal TO lang_uoc_le_readwrite;


--
-- Name: TABLE decorative_art_items; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.decorative_art_items TO lang_uoc_le_readwrite;


--
-- Name: TABLE heritage_building_technical_details; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.heritage_building_technical_details TO lang_uoc_le_readwrite;


--
-- Name: TABLE heritage_buildings; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.heritage_buildings TO lang_uoc_le_readwrite;


--
-- Name: TABLE history_stories; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.history_stories TO lang_uoc_le_readwrite;


--
-- Name: TABLE intangible_heritage_items; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.intangible_heritage_items TO lang_uoc_le_readwrite;


--
-- Name: TABLE media; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.media TO lang_uoc_le_readwrite;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.schema_migrations TO lang_uoc_le_readwrite;


--
-- Name: TABLE sites; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sites TO lang_uoc_le_readwrite;


--
-- Name: TABLE villages; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.villages TO lang_uoc_le_readwrite;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE admin IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO lang_uoc_le_readwrite;


--
-- PostgreSQL database dump complete
--

\unrestrict pDdIlPPWYPaESBu1PMHg9iV9Qn2Lcg1cinOc7sHRYzJS3Xuhj8ZcHdpqEbte9lx

